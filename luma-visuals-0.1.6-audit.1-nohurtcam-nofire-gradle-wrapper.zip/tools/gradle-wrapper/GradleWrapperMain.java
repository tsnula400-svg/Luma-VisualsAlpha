package org.gradle.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.Locale;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Minimal, source-available bootstrap compatible with the Gradle wrapper protocol:
 * reads gradle-wrapper.properties next to this JAR, downloads the distribution into
 * GRADLE_USER_HOME/wrapper/dists (same layout as the official wrapper), unzips it
 * and executes the distribution's gradle launcher with the original arguments.
 *
 * Built locally because this environment has no network access and no Gradle
 * installation to fetch the official gradle-wrapper.jar. To replace it with the
 * official binary, run once on any machine with network access:
 *   gradle wrapper --gradle-version 8.12
 * (or copy gradle-wrapper.jar from any Gradle 8.12 installation). The scripts
 * gradlew / gradlew.bat and gradle-wrapper.properties already match the official
 * Gradle 8.12 templates, so only this JAR file would be swapped.
 */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path jar = Path.of(GradleWrapperMain.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();
        Path propertiesPath = jar.resolveSibling("gradle-wrapper.properties");
        if (!Files.isRegularFile(propertiesPath)) {
            fail("gradle-wrapper.properties not found next to " + jar);
        }
        Properties props = new Properties();
        try (Reader reader = Files.newBufferedReader(propertiesPath, StandardCharsets.UTF_8)) {
            props.load(reader);
        }
        String distributionUrl = props.getProperty("distributionUrl");
        if (distributionUrl == null || distributionUrl.isBlank()) {
            fail("distributionUrl is missing in " + propertiesPath);
        }
        String gradleUserHome = System.getenv("GRADLE_USER_HOME");
        if (gradleUserHome == null || gradleUserHome.isBlank()) {
            gradleUserHome = Path.of(System.getProperty("user.home"), ".gradle").toString();
        }
        String zipName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
        String distName = zipName.endsWith(".zip") ? zipName.substring(0, zipName.length() - 4) : zipName;
        // Same per-distribution directory naming as the official wrapper: md5(distributionUrl).
        Path distDir = Path.of(gradleUserHome, "wrapper", "dists", distName, md5Hex(distributionUrl));
        Path okMarker = distDir.resolve(zipName + ".ok");
        Path gradleBin = findGradleLauncher(distDir);
        if (gradleBin == null || !Files.exists(okMarker)) {
            Files.createDirectories(distDir);
            Path zipTarget = distDir.resolve(zipName + ".part");
            try {
                download(distributionUrl, zipTarget, props.getProperty("networkTimeout"));
                unzip(zipTarget, distDir);
            } finally {
                Files.deleteIfExists(zipTarget);
            }
            gradleBin = findGradleLauncher(distDir);
            if (gradleBin == null) {
                fail("Downloaded distribution '" + distName + "' has no gradle launcher under " + distDir);
            }
            gradleBin.toFile().setExecutable(true);
            Files.writeString(okMarker, "ok\n", StandardCharsets.UTF_8);
        }
        runLauncher(gradleBin, args);
    }

    private static void download(String url, Path target, String networkTimeout) throws IOException, InterruptedException {
        System.out.println("Downloading " + url);
        System.out.println(" (to " + target + ")");
        HttpClient.Builder clientBuilder = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL);
        HttpRequest.Builder requestBuilder = HttpRequest.newBuilder(URI.create(url));
        if (networkTimeout != null && !networkTimeout.isBlank()) {
            try {
                requestBuilder.timeout(Duration.ofMillis(Long.parseLong(networkTimeout.trim())));
            } catch (NumberFormatException ignored) {
                // Unknown timeout format: use the JDK default.
            }
        }
        HttpResponse<InputStream> response;
        try {
            response = clientBuilder.build().send(requestBuilder.build(), HttpResponse.BodyHandlers.ofInputStream());
        } catch (Exception e) {
            fail("Could not download the Gradle distribution. Check your network connection.\nCause: " + e);
            return; // unreachable; fail() throws
        }
        if (response.statusCode() != 200) {
            fail("Could not download " + url + " (HTTP " + response.statusCode() + ")");
        }
        try (InputStream in = response.body()) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void unzip(Path zip, Path destination) throws IOException {
        try (ZipInputStream stream = new ZipInputStream(Files.newInputStream(zip))) {
            for (ZipEntry entry = stream.getNextEntry(); entry != null; entry = stream.getNextEntry()) {
                Path out = destination.resolve(entry.getName()).normalize();
                if (!out.startsWith(destination)) {
                    throw new IOException("Refusing to extract entry outside of the distribution directory: " + entry.getName());
                }
                if (entry.isDirectory()) {
                    Files.createDirectories(out);
                } else {
                    if (out.getParent() != null) {
                        Files.createDirectories(out.getParent());
                    }
                    Files.copy(stream, out, StandardCopyOption.REPLACE_EXISTING);
                }
                stream.closeEntry();
            }
        }
    }

    private static Path findGradleLauncher(Path distDir) throws IOException {
        if (!Files.isDirectory(distDir)) {
            return null;
        }
        boolean windows = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
        String launcher = windows ? "gradle.bat" : "gradle";
        try (var stream = Files.list(distDir)) {
            for (Path candidate : stream.filter(Files::isDirectory).toList()) {
                Path bin = candidate.resolve("bin").resolve(launcher);
                if (Files.isRegularFile(bin)) {
                    return bin;
                }
            }
        }
        return null;
    }

    private static void runLauncher(Path gradleBin, String[] args) throws IOException, InterruptedException {
        ProcessBuilder builder;
        if (gradleBin.getFileName().toString().endsWith(".bat")) {
            builder = new ProcessBuilder();
            builder.command().add("cmd");
            builder.command().add("/c");
            builder.command().add(gradleBin.toString());
            for (String arg : args) builder.command().add(arg);
        } else {
            builder = new ProcessBuilder();
            builder.command().add(gradleBin.toString());
            for (String arg : args) builder.command().add(arg);
        }
        builder.directory(Path.of("").toAbsolutePath().toFile());
        builder.inheritIO();
        System.exit(builder.start().waitFor());
    }

    private static String md5Hex(String text) throws Exception {
        byte[] digest = MessageDigest.getInstance("MD5").digest(text.getBytes(StandardCharsets.UTF_8));
        StringBuilder out = new StringBuilder(digest.length * 2);
        for (byte b : digest) {
            out.append(Character.forDigit((b >> 4) & 0xF, 16));
            out.append(Character.forDigit(b & 0xF, 16));
        }
        return out.toString();
    }

    private static void fail(String message) {
        System.err.println();
        System.err.println("ERROR: " + message);
        System.err.println();
        System.exit(1);
        throw new AssertionError("unreachable");
    }
}
