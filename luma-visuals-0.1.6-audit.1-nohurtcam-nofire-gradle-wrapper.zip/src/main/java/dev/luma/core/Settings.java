package dev.luma.core;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Properties;

/** No game dependencies. Values are validated at the file boundary. */
public final class Settings {
    public static final double MIN_SCALE=.85, MAX_SCALE=1.75;
    public int theme = 0;
 public final ViewModelConfig viewModel=new ViewModelConfig();
 /** Runtime-only preview, reset on screen removal. */
 public boolean viewModelPreview,previewSwing;public double previewProgress;
 public boolean customAccent=false,particleAccent=true;
 public int animationStyle=0;public int particleStyle=0;public int particleAmount=24;public int particleDirection=0;public double animationDuration=.28;public double animationIntensity=1;public double particleSpeed=1;public double particleSize=1.6;public double particleOpacity=.22;public double accentHue=.69;public double accentSaturation=.4;public double accentValue=1;public int particleColor=0xCFC8FF;
 public int accentColor(){return customAccent?AccentColor.rgb(accentHue,accentSaturation,accentValue):COLORS[theme];}
 /** Derive a legible foreground tint, while preserving the exact raw picker color. */
 public int uiAccentColor(){int rgb=accentColor();double r=((rgb>>16)&255)/255.0,g=((rgb>>8)&255)/255.0,b=(rgb&255)/255.0,v=.2126*r+.7152*g+.0722*b;return v<.6?Canvas.mix(rgb,0xFFFFFF,(.6-v)/(1-v))&0xFFFFFF:rgb;}
 public boolean animated(){return motion&&!reduced&&animationStyle!=5;}

    public boolean smoothScroll = true;
    public final HudConfig hud=new HudConfig();
    public boolean dropProtection=false, durabilityWarning=false, saturationEnabled=false;
    public boolean toolSafety=false;
    public int toolSafetyThreshold=100;
    public int durabilityThreshold=10;
    public double saturation=1;
    public String saturationStatus="Только мир. HUD и меню сохраняют свои цвета.";
    public boolean autoSprint = false, itemScroller = false, ratioEnabled = false, customSkinEnabled = false;
    public boolean noHurtCamera = false, noFireOverlay = false;
    /** 0 = aspect at native pixels, 1 = actual world framebuffer resolution. */
    public int ratioMode = 0, aspectPreset = 1, resolutionPreset = 2;
    /** Runtime status only; never persisted. */
    public String ratioStatus = "HUD и меню остаются чёткими";
    public double scale = 1, speed = 1, opacity = .96;
    public boolean efficientBackground = true;
    public boolean motion = true, proximity = true, hover = true;
    public boolean background = true, waves = true, rings = true, glow = true;
    public boolean scanlines = false, dots = false, dim = true, reduced = false;
    public static final int[] COLORS = {0xA599FF, 0xF291A5, 0x7DA8F7, 0x73CDAF, 0xE3C184, 0xC294E7};
    public static final String[] NAMES = {"Ирис", "Роза", "Лёд", "Мята", "Песок", "Орхидея"};
    public static double clamp(double v,double min,double max) {return Double.isFinite(v)?Math.max(min,Math.min(max,v)):min;}
    public void validate() {
        hud.validate();viewModel.validate();animationStyle=(int)clamp(animationStyle,0,5);particleStyle=(int)clamp(particleStyle,0,4);particleAmount=(int)clamp(particleAmount,0,64);particleDirection=(int)clamp(particleDirection,0,3);animationDuration=clamp(animationDuration,0.12,0.65);animationIntensity=clamp(animationIntensity,0,1);particleSpeed=clamp(particleSpeed,0.1,2);particleSize=clamp(particleSize,0.5,3);particleOpacity=clamp(particleOpacity,0.05,0.5);accentHue=clamp(accentHue,0,1);accentSaturation=clamp(accentSaturation,0,1);accentValue=clamp(accentValue,0,1);particleColor=(int)clamp(particleColor,0,16777215);toolSafetyThreshold=Math.max(1,Math.min(200,toolSafetyThreshold));durabilityThreshold=Math.max(1,Math.min(30,durabilityThreshold));saturation=clamp(saturation,0,1.5);
        theme=Math.max(0,Math.min(COLORS.length-1,theme));
        ratioMode=Math.max(0,Math.min(1,ratioMode));
        aspectPreset=Math.max(0,Math.min(RatioPresets.ASPECT_COUNT-1,aspectPreset));
        resolutionPreset=Math.max(0,Math.min(RatioPresets.RESOLUTION_COUNT-1,resolutionPreset));
        scale=clamp(scale,MIN_SCALE,MAX_SCALE);speed=clamp(speed,.35,1.8);opacity=clamp(opacity,.82,1);
    }
    public void reset() {
        customAccent=false;particleAccent=true;animationStyle=0;particleStyle=0;particleAmount=24;particleDirection=0;animationDuration=.28;animationIntensity=1;particleSpeed=1;particleSize=1.6;particleOpacity=.22;accentHue=.69;accentSaturation=.4;accentValue=1;particleColor=0xCFC8FF;theme=0;scale=1;speed=1;opacity=.96;efficientBackground=true;smoothScroll=true;
        motion=proximity=hover=background=waves=rings=glow=dim=true;
        scanlines=dots=reduced=false;
    }
    public static Settings load(Path path) throws IOException {
        Settings s=new Settings(); if(!Files.exists(path))return s;
        Properties p=new Properties();try(Reader r=Files.newBufferedReader(path,StandardCharsets.UTF_8)){p.load(r);}
        s.theme=(int)number(p,"theme",0);s.scale=number(p,"scale",1);s.speed=number(p,"speed",1);s.opacity=number(p,"opacity",.96);
        s.efficientBackground=bool(p,"efficientBackground",true);
        s.smoothScroll=bool(p,"smoothScroll",true);
        s.autoSprint=bool(p,"autoSprint",false);s.itemScroller=bool(p,"itemScroller",false);
        s.noHurtCamera=bool(p,"noHurtCamera",false);s.noFireOverlay=bool(p,"noFireOverlay",false);
        s.ratioEnabled=bool(p,"ratioEnabled",false);
        s.ratioMode=(int)number(p,"ratioMode",0);s.aspectPreset=(int)number(p,"aspectPreset",1);
        s.resolutionPreset=(int)number(p,"resolutionPreset",2);
        s.motion=bool(p,"motion",true);s.proximity=bool(p,"proximity",true);s.hover=bool(p,"hover",true);
        s.background=bool(p,"background",true);s.waves=bool(p,"waves",true);s.rings=bool(p,"rings",true);s.glow=bool(p,"glow",true);
        s.scanlines=bool(p,"scanlines",false);s.dots=bool(p,"dots",false);s.dim=bool(p,"dim",true);s.reduced=bool(p,"reduced",false);
        s.toolSafety=bool(p,"toolSafety",false);s.toolSafetyThreshold=(int)number(p,"toolSafetyThreshold",100);
        s.hud.load(p);s.dropProtection=bool(p,"dropProtection",false);s.durabilityWarning=bool(p,"durabilityWarning",false);
        s.durabilityThreshold=(int)number(p,"durabilityThreshold",10);s.saturationEnabled=bool(p,"saturationEnabled",false);s.saturation=number(p,"saturation",1);s.customSkinEnabled=bool(p,"customSkinEnabled",false);
        s.viewModel.load(p);s.animationStyle=(int)number(p,"animationStyle",0);s.particleStyle=(int)number(p,"particleStyle",0);s.particleAmount=(int)number(p,"particleAmount",24);s.particleDirection=(int)number(p,"particleDirection",0);s.animationDuration=number(p,"animationDuration",.28);s.animationIntensity=number(p,"animationIntensity",1);s.particleSpeed=number(p,"particleSpeed",1);s.particleSize=number(p,"particleSize",1.6);s.particleOpacity=number(p,"particleOpacity",.22);s.accentHue=number(p,"accentHue",.69);s.accentSaturation=number(p,"accentSaturation",.4);s.accentValue=number(p,"accentValue",1);s.particleColor=(int)number(p,"particleColor",0xCFC8FF);s.customAccent=bool(p,"customAccent",false);s.particleAccent=bool(p,"particleAccent",true);s.validate();return s;
    }
    private static double number(Properties p,String k,double fallback){
        try {double n=Double.parseDouble(p.getProperty(k,""));return Double.isFinite(n)?n:fallback;}catch(NumberFormatException e){return fallback;}
    }
    private static boolean bool(Properties p,String k,boolean fallback){
        String v=p.getProperty(k);return "true".equals(v)?true:"false".equals(v)?false:fallback;
    }
    public void save(Path path) throws IOException {
        validate();Properties p=new Properties();viewModel.save(p);p.setProperty("animationStyle",""+animationStyle);p.setProperty("particleStyle",""+particleStyle);p.setProperty("particleAmount",""+particleAmount);p.setProperty("particleDirection",""+particleDirection);p.setProperty("animationDuration",""+animationDuration);p.setProperty("animationIntensity",""+animationIntensity);p.setProperty("particleSpeed",""+particleSpeed);p.setProperty("particleSize",""+particleSize);p.setProperty("particleOpacity",""+particleOpacity);p.setProperty("accentHue",""+accentHue);p.setProperty("accentSaturation",""+accentSaturation);p.setProperty("accentValue",""+accentValue);p.setProperty("particleColor",""+particleColor);p.setProperty("customAccent",""+customAccent);p.setProperty("particleAccent",""+particleAccent);
        p.setProperty("toolSafety",""+toolSafety);p.setProperty("toolSafetyThreshold",""+toolSafetyThreshold);
        hud.save(p);p.setProperty("dropProtection",""+dropProtection);p.setProperty("durabilityWarning",""+durabilityWarning);
        p.setProperty("durabilityThreshold",""+durabilityThreshold);p.setProperty("saturationEnabled",""+saturationEnabled);p.setProperty("saturation",""+saturation);p.setProperty("format","1");
        p.setProperty("theme",""+theme);p.setProperty("scale",""+scale);p.setProperty("speed",""+speed);p.setProperty("opacity",""+opacity);
        p.setProperty("efficientBackground",""+efficientBackground);
        p.setProperty("smoothScroll",""+smoothScroll);
        p.setProperty("autoSprint",""+autoSprint);p.setProperty("itemScroller",""+itemScroller);
        p.setProperty("noHurtCamera",""+noHurtCamera);p.setProperty("noFireOverlay",""+noFireOverlay);
        p.setProperty("ratioEnabled",""+ratioEnabled);p.setProperty("ratioMode",""+ratioMode);
        p.setProperty("aspectPreset",""+aspectPreset);p.setProperty("resolutionPreset",""+resolutionPreset);
        p.setProperty("motion",""+motion);p.setProperty("proximity",""+proximity);p.setProperty("hover",""+hover);
        p.setProperty("background",""+background);p.setProperty("waves",""+waves);p.setProperty("rings",""+rings);p.setProperty("glow",""+glow);
        p.setProperty("scanlines",""+scanlines);p.setProperty("dots",""+dots);p.setProperty("dim",""+dim);p.setProperty("reduced",""+reduced);p.setProperty("customSkinEnabled",""+customSkinEnabled);
        Path dir=path.toAbsolutePath().getParent();Files.createDirectories(dir);
        Path tmp=Files.createTempFile(dir,"luma-",".tmp");
        try {
            try(Writer w=Files.newBufferedWriter(tmp,StandardCharsets.UTF_8)){p.store(w,"Luma Visuals / local client preferences");}
            try{Files.move(tmp,path,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
            catch(AtomicMoveNotSupportedException e){Files.move(tmp,path,StandardCopyOption.REPLACE_EXISTING);}
        }finally{Files.deleteIfExists(tmp);}
    }
}
