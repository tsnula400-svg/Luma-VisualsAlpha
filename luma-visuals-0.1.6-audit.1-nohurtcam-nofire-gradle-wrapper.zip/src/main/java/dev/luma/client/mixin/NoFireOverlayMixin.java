package dev.luma.client.mixin;
import dev.luma.client.LumaClient;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Screen-space fire overlay only. Burn time, fire damage, world fire blocks, particles and entity fire rendering stay vanilla. */
@Mixin(InGameOverlayRenderer.class)
public abstract class NoFireOverlayMixin {
    @Inject(method="renderFireOverlay",at=@At("HEAD"),cancellable=true)
    private static void luma$noFireOverlay(MatrixStack matrices,VertexConsumerProvider vertexConsumers,CallbackInfo ci){
        var s=LumaClient.settings;if(s!=null&&s.noFireOverlay)ci.cancel();
    }
}
