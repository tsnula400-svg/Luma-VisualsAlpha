# Текущие проверки

См. AUDIT_REPORT_RU.md: VERIFIED / BUILD / JAR / REMAINING.
Свежие логи: audit/current/. Историческая повторная проверка неизменённого входа: audit/baseline/.

Команды (в корне проекта):
```bash
python3 tools/test_build_guards.py
bash tools/check_core.sh
node tools/check_shader_webgl.cjs # отдельный SwiftShader surrogate, НЕ MobileGlues
# Только при наличии JDK 21, Gradle 8.12 и зависимостей:
gradle --no-daemon --no-build-cache --rerun-tasks clean build
python3 tools/verify_jar.py --jar build/libs/luma-visuals-0.1.6-audit.1.jar
```

Последние две команды здесь не выполнены: готового Fabric JAR нет.
