package dev.luma.core;
public final class AccentColor {
 private AccentColor(){}
 public static int rgb(double h,double s,double v){h=Settings.clamp(h,0,1)*6;s=Settings.clamp(s,0,1);v=Settings.clamp(v,0,1);int i=(int)Math.floor(h);double f=h-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);return switch(i%6){case 0->pack(v,t,p);case 1->pack(q,v,p);case 2->pack(p,v,t);case 3->pack(p,q,v);case 4->pack(t,p,v);default->pack(v,p,q);};}
 private static int pack(double r,double g,double b){return ((int)Math.round(r*255)<<16)|((int)Math.round(g*255)<<8)|(int)Math.round(b*255);}
 public static void fromRgb(int rgb,Settings s){double r=((rgb>>16)&255)/255.0,g=((rgb>>8)&255)/255.0,b=(rgb&255)/255.0,hi=Math.max(r,Math.max(g,b)),lo=Math.min(r,Math.min(g,b)),d=hi-lo;double h=d==0?0:hi==r?((g-b)/d)%6:hi==g?(b-r)/d+2:(r-g)/d+4;s.accentHue=(h/6+1)%1;s.accentSaturation=hi==0?0:d/hi;s.accentValue=hi;}
}
