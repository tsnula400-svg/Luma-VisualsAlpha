package dev.luma.core;

/** Aspect is independent of sampling resolution. Native means native in BOTH modes. */
public final class RatioPresets {
    private RatioPresets() {}
    private static final String[] ASPECT_NAMES={"Как экран", "4:3", "16:9", "16:10", "5:4", "1:1"};
    private static final double[] ASPECTS={0,4.0/3,16.0/9,16.0/10,5.0/4,1};
    private static final int[][] RESOLUTIONS={{640,480},{800,600},{1024,768},{1280,960},{1280,720},{1600,900},{1920,1080}};
    public static final int ASPECT_COUNT=ASPECTS.length, RESOLUTION_COUNT=RESOLUTIONS.length;
    public static String aspectName(int i){return ASPECT_NAMES[i];}
    public static String resolutionName(int i){return width(i)+"×"+height(i);}
    public static int width(int i){return RESOLUTIONS[i][0];}
    public static int height(int i){return RESOLUTIONS[i][1];}
    public static double desiredAspect(Settings s,double nativeAspect){
        if(!s.ratioEnabled)return nativeAspect;
        return s.aspectPreset==0?nativeAspect:ASPECTS[s.aspectPreset];
    }
    public static double projectionMultiplier(double originalAspect,double desiredAspect){
        return originalAspect>0&&desiredAspect>0&&Double.isFinite(originalAspect)&&Double.isFinite(desiredAspect)?originalAspect/desiredAspect:1;
    }
}
