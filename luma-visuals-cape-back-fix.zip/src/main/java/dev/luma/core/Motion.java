package dev.luma.core;
/** Shared, bounded UI interpolation; no springs, threads or GPU resources. */
public final class Motion {
    public static final double RESPONSE=18,EXIT_RESPONSE=24;
    private Motion(){}
    public static double delta(double seconds){return Double.isFinite(seconds)?Math.max(0,Math.min(.1,seconds)):0;}
    public static double damp(double value,double target,double rate,double seconds){
        if(!Double.isFinite(target))return Double.isFinite(value)?value:0;
        if(!Double.isFinite(value))return target;
        if(!Double.isFinite(seconds)||seconds<=0||!Double.isFinite(rate)||rate<=0)return value;
        return target+(value-target)*Math.exp(-rate*seconds);
    }
    public static double approach(double value,double target,double rate,double seconds,boolean animate){
        if(!animate)return target;double v=damp(value,target,rate,delta(seconds));return Math.abs(v-target)<.0001?target:v;
    }
    public static double easeOut(double value){double t=Settings.clamp(value,0,1);return 1-(1-t)*(1-t)*(1-t);}
    public static double stagger(double elapsed,int index,boolean animate){return animate?easeOut((elapsed-Math.min(4,Math.max(0,index))*.022)/.22):1;}
    public static double panelScale(double openness){return .97+.03*Settings.clamp(openness,0,1);}
    public static double panelSlide(double openness){return 12*(1-Settings.clamp(openness,0,1));}
    /** Opening/closing presentation selected by Settings.animationStyle; the shared damped `open` value still drives timing. */
    public static double styleAlpha(int style,double openness){
        double t=Settings.clamp(openness,0,1);
        return switch(style){case 1->t*t;case 2->Settings.clamp(t*1.4,0,1);case 3,4->Settings.clamp(t*1.8,0,1);case 5->1;default->easeOut(t);};
    }
    public static double styleScale(int style,double openness,double intensity){
        double k=1-Settings.clamp(openness,0,1),i=Settings.clamp(intensity,0,1);
        return switch(style){case 1,2,5->1;case 3->1-.28*i*k;case 4->1+.22*i*k;default->1-.06*i*k;};
    }
    public static double styleSlide(int style,double openness,double intensity){
        double k=1-Settings.clamp(openness,0,1),i=Settings.clamp(intensity,0,1);
        return switch(style){case 0->38*k*i;case 2->96*k*i;default->0;};
    }
    public static double styleContentSlide(int style,double blend,boolean leaving,double intensity){
        double k=1-Settings.clamp(blend,0,1),i=Settings.clamp(intensity,0,1),direction=leaving?-1:1;
        return switch(style){case 1,3,5->0;case 2->direction*46*k*i;case 4->direction*8*k*i;default->direction*18*k*i;};
    }
    /** Channels are allocated once per existing control, not boxed every frame. */
    public static final class Values {
        private final double[] values={Double.NaN,Double.NaN,Double.NaN,Double.NaN};
        public double to(int channel,double target,double seconds,boolean animate,double initial){double v=values[channel];if(!Double.isFinite(v))v=initial;return values[channel]=approach(v,target,RESPONSE,seconds,animate);}
    }
    public static double proximity(double x,double y,double mx,double my,double radius){
        if(!Double.isFinite(radius)||radius<=0)return 0;double t=Settings.clamp(1-Math.hypot(x-mx,y-my)/radius,0,1);return t*t*(3-2*t);
    }
}
