package dev.luma.core;
/** Mutable renderer-owned result: no per-frame arrays or transform objects. */
public final class SwingTransform {
 public double x,y,z,pitch,yaw,roll,scale=1;
 public void evaluate(ViewModelConfig c,double progress,int side){double p=Settings.clamp(progress,0,1);if(p==0||p==1){x=y=z=pitch=yaw=roll=0;scale=1;return;}double arc=Math.sin(Math.PI*p),sweep=Math.sin(2*Math.PI*p),strength=c.strength(),position=c.swingStyle==5?c.positionInfluence:1,rotation=c.swingStyle==5?c.swingRotation:1;
 x=-side*.24*arc*strength*position;y=.12*sweep*strength*position;z=-.14*arc*strength*position;pitch=-55*arc*strength*rotation;yaw=side*18*sweep*strength*rotation;roll=-side*22*arc*strength*rotation;scale=1+(c.swingStyle==5?c.scaleInfluence:0)*arc;}
}
