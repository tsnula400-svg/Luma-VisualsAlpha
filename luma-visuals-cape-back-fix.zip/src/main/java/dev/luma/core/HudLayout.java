package dev.luma.core;
import java.util.*;
import static dev.luma.core.Canvas.*;
/** Shared HUD layout for Minecraft and software tests. All coordinates are physical pixels.
 * Orbit keeps each row together. Automatic positions are recalculated until the user drags.
 * No post-processing / framebuffer / custom shader is required by these HUD styles.
 */
public final class HudLayout {
    public record Equipment(String key,String label,int percent,boolean present){}
    public record Data(String[] values,List<Equipment> armor,List<Equipment> tools){}
    public record Box(int id,double x,double y,double w,double h){public boolean contains(double px,double py){return px>=x&&px<x+w&&py>=y&&py<y+h;}}
    public record ItemIcon(String key,double x,double y,double size){}
    private static final int[][] ROWS={{0,1,2,6},{3,4,5},{7,8}};
    private static final double FS=14,HEIGHT=30;
    private final HudConfig config;
    private final List<Box> boxes=new ArrayList<>(),groups=new ArrayList<>();
    private final List<ItemIcon> icons=new ArrayList<>();
    private final List<ItemIcon> iconView=Collections.unmodifiableList(icons);
    private final double[] visibility=new double[9],widths=new double[9],measured=new double[9];
    private List<Equipment> retainedArmor=List.of(),retainedTools=List.of();
    private double animatedScale;private boolean interactive;private int lastStyle=-1;
    private final Set<Integer> selected=new LinkedHashSet<>();
    private List<Box> dragStart=List.of(),groupStart=List.of();
    private double startX,startY;
    private int width,height;
    private boolean dragging,changed;
    public HudLayout(HudConfig config){this.config=config;}
    public List<Box> boxes(){return List.copyOf(boxes);}
    public List<ItemIcon> icons(){return iconView;}
    public boolean dragging(){return dragging;}
    public boolean takeChanged(){boolean c=changed;changed=false;return c;}
    public boolean allSelected(){return !boxes.isEmpty()&&boxes.stream().allMatch(b->selected.contains(b.id));}
    public void selectAll(){selected.clear();for(Box b:boxes)selected.add(b.id);}
    public void clearSelection(){selected.clear();}
    public void stop(){dragging=false;dragStart=List.of();groupStart=List.of();}
    private static int rowOf(int id){for(int row=0;row<ROWS.length;row++)for(int i:ROWS[row])if(i==id)return row;return 0;}
    public boolean click(double x,double y,boolean extend){
        if(!interactive)return false;
        for(int i=boxes.size()-1;i>=0;i--){Box b=boxes.get(i);if(!b.contains(x,y))continue;
            if(!selected.contains(b.id)){if(!extend)selected.clear();selected.add(b.id);}
            if(config.style==0)for(Box q:boxes)if(rowOf(q.id)==rowOf(b.id))selected.add(q.id);
            startX=x;startY=y;dragStart=boxes.stream().filter(q->selected.contains(q.id)).toList();
            groupStart=groups.stream().filter(g->dragStart.stream().anyMatch(q->rowOf(q.id)==g.id)).toList();dragging=true;return true;
        }if(!extend)selected.clear();return false;
    }
    public void move(double x,double y){
        if(!dragging||dragStart.isEmpty())return;
        List<Box> bounds=config.style==0?groupStart:dragStart;
        double minX=bounds.stream().mapToDouble(Box::x).min().orElse(0),minY=bounds.stream().mapToDouble(Box::y).min().orElse(0);
        double maxX=bounds.stream().mapToDouble(b->b.x+b.w).max().orElse(0),maxY=bounds.stream().mapToDouble(b->b.y+b.h).max().orElse(0);
        double dx=Settings.clamp(x-startX,-minX,width-maxX),dy=Settings.clamp(y-startY,-minY,height-maxY);
        for(Box b:dragStart){config.x[b.id]=(b.x+dx)/Math.max(1,width-b.w);config.y[b.id]=(b.y+dy)/Math.max(1,height-b.h);}
        for(Box g:groupStart){config.groupX[g.id]=(g.x+dx)/Math.max(1,width-g.w);config.groupY[g.id]=(g.y+dy)/Math.max(1,height-g.h);}
        config.placed=true;changed=true;
    }
    private boolean show(int id,Data data,boolean editing){return config.visible[id]&&(id<7||editing||!(id==7?data.armor:data.tools).isEmpty());}
    private String value(Data data,int id){return data.values!=null&&id<data.values.length&&data.values[id]!=null?data.values[id]:"—";}
    public void resetAnimation(){stop();Arrays.fill(visibility,0);Arrays.fill(widths,0);animatedScale=0;retainedArmor=List.of();retainedTools=List.of();boxes.clear();groups.clear();icons.clear();interactive=false;}
    public double visibility(int id){return visibility[id];}
    private List<Equipment> equipment(int id){return id==7?retainedArmor:retainedTools;}
    private double naturalWidth(Canvas c,Data data,int id){
        if(id<7)return 34+Math.min(id==3?210:id==0||id==5?168:116,c.textWidth(value(data,id),FS));
        List<Equipment> eq=equipment(id);
        if(eq.isEmpty())return 34+c.textWidth(id==7?"Нет брони":"Пустые руки",FS);double total=16;for(Equipment e:eq)total+=e.percent>=0?70:32;return total;
    }
    /** Static compatibility overload for existing layout/export callers. */
    public void render(Canvas c,int width,int height,Data data,int accent,boolean editing){render(c,width,height,data,accent,editing,0,false);}
    public void render(Canvas c,int width,int height,Data data,int accent,boolean editing,double elapsed,boolean animate){
        boolean resized=this.width!=width||this.height!=height;
        if(resized||lastStyle!=config.style||!editing)stop();this.width=width;this.height=height;lastStyle=config.style;interactive=editing;
        boxes.clear();groups.clear();icons.clear();if(width<32||height<32)return;
        double dt=Motion.delta(elapsed);boolean tween=animate&&!editing;
        if(!data.armor.isEmpty()||editing)retainedArmor=data.armor;if(!data.tools.isEmpty()||editing)retainedTools=data.tools;
        double scale=Settings.clamp(Math.min(width/1280.0,height/720.0),.55,2)*config.scale;
        animatedScale=animatedScale==0||resized?scale:Motion.approach(animatedScale,scale,Motion.RESPONSE,dt,tween);scale=animatedScale;
        double gap=config.style==0?1:8;
        for(int id=0;id<9;id++){
            boolean target=(config.enabled||editing)&&show(id,data,editing);
            visibility[id]=Motion.approach(visibility[id],target?1:0,Motion.RESPONSE,dt,tween);
            double desired=naturalWidth(c,data,id);
            widths[id]=widths[id]==0?desired:Motion.approach(widths[id],desired,Motion.RESPONSE,dt,tween&&!resized);measured[id]=widths[id];
        }
        // Fixed primitive state replaces per-row temporary lists and streams.
        double widest=1;
        for(int[] row:ROWS){double sum=0,last=0;for(int id:row)if(visibility[id]>.0001){sum+=(measured[id]+gap)*visibility[id];last=visibility[id];}widest=Math.max(widest,sum-gap*last);}
        scale=Math.min(scale,(width-24)/widest);double top=16*scale;
        for(int row=0;row<ROWS.length;row++){
            double rowWidth=0,rowAlpha=0,last=0;int count=0;
            for(int id:ROWS[row])if(visibility[id]>.0001){rowWidth+=(measured[id]+gap)*scale*visibility[id];rowAlpha=Math.max(rowAlpha,visibility[id]);last=visibility[id];count++;}
            if(count==0)continue;rowWidth-=gap*scale*last;
            double rowHeight=HEIGHT*scale,gx=(width-rowWidth)/2,gy=top;
            if(config.placed&&config.style==0){gx=config.groupX[row]*(width-rowWidth);gy=config.groupY[row]*(height-rowHeight);}
            else if(!config.placed){config.groupX[row]=gx/Math.max(1,width-rowWidth);config.groupY[row]=gy/Math.max(1,height-rowHeight);}
            groups.add(new Box(row,gx,gy,rowWidth,rowHeight*rowAlpha));
            if(config.style==0)c.round(gx,gy,rowWidth,rowHeight*rowAlpha,9*scale,alpha(0x101522,config.opacity*rowAlpha));
            double offset=0;int j=0;
            for(int id:ROWS[row]){
                double q=visibility[id];if(q<=.0001)continue;
                double localScale=scale*q,bw=measured[id],w=bw*localScale,x=gx+offset,y=gy+(rowHeight*rowAlpha-HEIGHT*localScale)/2;
                if(config.placed&&config.style!=0){x=config.x[id]*(width-w);y=config.y[id]*(height-HEIGHT*localScale);}
                else{config.x[id]=x/Math.max(1,width-w);config.y[id]=y/Math.max(1,height-HEIGHT*localScale);}
                x=Settings.clamp(x,0,width-w);y=Settings.clamp(y,0,height-HEIGHT*localScale);boxes.add(new Box(id,x,y,w,HEIGHT*localScale));
                c.push(x,y,localScale,q);
                if(config.style==0){if(j>0)c.line(0,9,0,21,1,alpha(0xB5C0DA,.18));}
                else if(config.style==1){
                    c.round(-.5,-.5,bw+1,HEIGHT+1,9.5,alpha(accent,.16));c.round(0,0,bw,HEIGHT,9,alpha(0x101522,config.opacity));
                    c.round(5,5,20,20,6,alpha(accent,.13));
                }else{
                    // Text-only design with a tiny accent marker. No filled panel.
                    c.round(0,9,2,12,1,accent);
                }
                if(id<7){
                    Icons.draw(c,glyph(id),10,8,14,accent);
                    String text=fit(c,value(data,id),bw-34,FS);
                    if(config.style==2)c.text(text,30,7,FS,0xE6000000);
                    c.text(text,29,6,FS,0xFFF2F4FC);
                }else{
                    List<Equipment> eq=equipment(id);
                    double fitScale=Math.min(1,bw/naturalWidth(c,data,id)),inset=HEIGHT*(1-fitScale)/2;
                    c.push(0,inset,fitScale,1);
                    if(eq.isEmpty()){
                        Icons.draw(c,id==7?"shield":"tool",10,8,14,accent);
                        c.text(id==7?"Нет брони":"Пустые руки",29,6,FS,0xFFB7BED0);
                    }
                    double ex=8;
                    for(Equipment e:eq){
                        icons.add(new ItemIcon(e.key,x+ex*localScale*fitScale,y+(inset+6*fitScale)*localScale,18*localScale*fitScale));
                        if(e.percent>=0){int color=e.percent<=10?0xFFFF9B92:0xFFE4EAF6;
                            if(config.style==2)c.text(e.percent+"%",ex+24,6,12,0xE6000000);
                            c.text(e.percent+"%",ex+23,5,12,color);
                            c.rect(ex+23,22,35,2,alpha(color,.20));c.rect(ex+23,22,35*Settings.clamp(e.percent/100.0,0,1),2,color);
                        }
                        ex+=e.percent>=0?70:32;
                    }
                    c.pop();
                }
                if(editing&&selected.contains(id)){
                    c.line(4,HEIGHT-1,bw-4,HEIGHT-1,1.5,accent);
                }
                c.pop();offset+=w+gap*localScale;j++;
            }
            top+=(rowHeight+7*scale)*rowAlpha;
        }
    }
    private static String glyph(int id){return switch(id){case 0->"person";case 1->"monitor";case 2->"signal";case 3->"compass";case 4->"speed";case 5->"server";case 6->"people";default->"check";};}
    public static String fit(Canvas c,String text,double width,double size){
        String s=text==null?"—":text;if(c.textWidth(s,size)<=width)return s;
        while(!s.isEmpty()&&c.textWidth(s+"…",size)>width)s=s.substring(0,s.offsetByCodePoints(s.length(),-1));
        return s.isEmpty()?"":s+"…";
    }
}
