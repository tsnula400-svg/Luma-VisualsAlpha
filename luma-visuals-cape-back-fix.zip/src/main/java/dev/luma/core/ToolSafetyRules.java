package dev.luma.core;
/** Pure rules: a low-durability tool may only go to an EMPTY main-inventory slot. */
public final class ToolSafetyRules {
    private ToolSafetyRules(){}
    public static int effectiveThreshold(int maximum,int configured){
        if(maximum<=1)return 0;
        // Never put away a new wooden/gold tool just because its total durability is below 100.
        return Math.min(Math.max(1,configured),Math.max(1,maximum/10));
    }
    public static boolean needsStash(boolean supported,int remaining,int maximum,int configured){
        return supported&&maximum>1&&remaining>=0&&remaining<=effectiveThreshold(maximum,configured);
    }
    public static int emptyMainSlot(boolean[] empty){
        if(empty==null||empty.length<36)return -1;
        for(int i=9;i<36;i++)if(empty[i])return i;
        return -1;
    }
}
