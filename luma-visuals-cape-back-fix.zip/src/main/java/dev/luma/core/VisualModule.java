package dev.luma.core;
/** Extension point for actual client-side visual features. No fake modules are registered. */
public abstract class VisualModule {
    private final String id, name;private boolean enabled;
    protected VisualModule(String id,String name){this.id=id;this.name=name;}
    public final String id(){return id;}public final String name(){return name;}
    public final boolean enabled(){return enabled;}
    public final void setEnabled(boolean value){if(enabled==value)return;enabled=value;if(value)onEnable();else onDisable();}
    protected void onEnable(){}protected void onDisable(){}
    public void tick(){}
}
