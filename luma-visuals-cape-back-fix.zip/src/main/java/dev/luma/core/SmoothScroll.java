package dev.luma.core;

/** No springs or overshoot; fractional wheel input accumulates in target space. */
public final class SmoothScroll {
    private double value,target,limit;
    public double value(){return value;}
    public double target(){return target;}
    public void bounds(double maximum){limit=Math.max(0,Double.isFinite(maximum)?maximum:0);value=Settings.clamp(value,0,limit);target=Settings.clamp(target,0,limit);}
    public void jump(double position){value=target=Settings.clamp(position,0,limit);}
    public void move(double delta,boolean smooth){if(!Double.isFinite(delta))return;target=Settings.clamp(target+delta,0,limit);if(!smooth)value=target;}
    public double update(double elapsed,boolean smooth){
        double dt=Double.isFinite(elapsed)?Math.max(0,elapsed):0;
        value=smooth?Motion.damp(value,target,18,dt):target;
        if(Math.abs(target-value)<.02)value=target;
        return value;
    }
}
