package dev.luma.client.mixin;
import dev.luma.client.DropSafety;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(HandledScreen.class)
public abstract class DropHandledMixin extends Screen {
    @Shadow protected Slot focusedSlot;
    @Shadow @Final protected ScreenHandler handler;
    protected DropHandledMixin(Text t){super(t);}
    @Inject(method="keyPressed",at=@At("HEAD"),cancellable=true) private void luma$protect(int key,int scan,int mods,CallbackInfoReturnable<Boolean> cir){
        if(client==null||client.player==null||!client.options.dropKey.matchesKey(key,scan)||focusedSlot==null||!focusedSlot.hasStack()||!handler.getCursorStack().isEmpty()||!focusedSlot.canTakeItems(client.player))return;
        if(!DropSafety.allow(handler,focusedSlot.id,focusedSlot.getStack(),Screen.hasControlDown()))cir.setReturnValue(true);
    }
    @Inject(method="render",at=@At("TAIL")) private void luma$target(DrawContext c,int x,int y,float delta,CallbackInfo ci){
        if(focusedSlot==null)DropSafety.reset();else DropSafety.inspect(handler,focusedSlot.id,focusedSlot.getStack());
    }
    @Inject(method="removed",at=@At("HEAD")) private void luma$clear(CallbackInfo ci){DropSafety.reset();}
}
