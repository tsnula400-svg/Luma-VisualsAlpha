package dev.luma.client.mixin;

import dev.luma.client.skin.CustomSkinManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hides the vanilla cape ONLY for the local player while the custom skin is active.
 * Scoped to {@code CapeFeatureRenderer} itself (mirrors the existing {@code PlayerRendererMixin}
 * scoping style) instead of a global player-render hook, so other players' vanilla capes -
 * and this player's own cape when the custom skin is OFF - are never touched.
 *
 * Reuses CustomSkinManager.isEnabledFor(state), the same local-player / spectator / OFF gate
 * already used by CustomSkinFeatureRenderer and PlayerRendererMixin, so the condition for
 * "cape hidden" always matches the condition for "custom skin drawn".
 *
 * NOTE: this sandbox has no Minecraft/Yarn jars or network access to verify the exact
 * mapped class/method name against Yarn 1.21.4+build.8 (see AUDIT_REPORT_RU.md: "NOT RUN").
 * CapeFeatureRenderer#render(MatrixStack, VertexConsumerProvider, int, PlayerEntityRenderState, float, float)
 * is written to match the same FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel>
 * signature already used by CustomSkinFeatureRenderer.render(...) in this codebase. Please
 * confirm the class name compiles/remaps against your Loom setup before shipping; if the cape
 * ever lived on a different class in your mappings, only the @Mixin target and import above
 * need to change - the gating logic stays the same.
 */
@Mixin(CapeFeatureRenderer.class)
public abstract class CapeFeatureRendererMixin {
    @Inject(
            method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FF)V",
            at = @At("HEAD"),
            cancellable = true)
    private void luma$hideVanillaCapeForCustomSkin(
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            PlayerEntityRenderState state,
            float limbAngle,
            float limbDistance,
            CallbackInfo ci) {
        // Only the local player, only while their custom skin is actually enabled/visible -
        // identical gate to CustomSkinFeatureRenderer, so other players' capes are untouched
        // and this player's cape comes back the instant the custom skin is turned OFF.
        if (CustomSkinManager.isEnabledFor(state)) {
            ci.cancel();
        }
    }
}
