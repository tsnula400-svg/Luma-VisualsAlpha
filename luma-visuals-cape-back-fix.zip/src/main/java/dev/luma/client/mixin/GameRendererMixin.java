package dev.luma.client.mixin;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import dev.luma.client.WorldResolution;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @WrapMethod(method="renderWorld")
    private void luma$worldPass(RenderTickCounter counter,Operation<Void> original){
        WorldResolution.begin();boolean completed=false;
        try{original.call(counter);completed=true;}
        finally{WorldResolution.end(completed);}
    }
    @Inject(method="getBasicProjectionMatrix",at=@At("RETURN"))
    private void luma$aspect(float fov,CallbackInfoReturnable<Matrix4f> cir){
        float multiplier=WorldResolution.projectionMultiplier();
        if(multiplier!=1){Matrix4f matrix=cir.getReturnValue();matrix.m00(matrix.m00()*multiplier);}
    }
}
