package dev.luma.client.mixin;
import dev.luma.client.LumaHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(ChatScreen.class)
public abstract class ChatScreenMixin extends Screen {
    protected ChatScreenMixin(Text t){super(t);}
    @Inject(method="render",at=@At("TAIL")) private void luma$toolbar(DrawContext c,int x,int y,float d,CallbackInfo ci){LumaHud.toolbar(c);}
    @Inject(method="mouseClicked",at=@At("HEAD"),cancellable=true) private void luma$click(double x,double y,int b,CallbackInfoReturnable<Boolean> cir){if(LumaHud.click(x,y,b))cir.setReturnValue(true);}
    @Override public boolean mouseDragged(double x,double y,int b,double dx,double dy){return LumaHud.drag(x,y,b)||super.mouseDragged(x,y,b,dx,dy);}
    @Override public boolean mouseReleased(double x,double y,int b){return (b==0&&LumaHud.release())||super.mouseReleased(x,y,b);}
    @Inject(method="removed",at=@At("HEAD")) private void luma$save(CallbackInfo ci){LumaHud.release();}
}
