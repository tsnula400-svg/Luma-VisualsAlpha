package dev.luma.client.mixin;

import dev.luma.client.LumaClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Uses vanilla eligibility; does not change speed, packets, or sprint-stop rules. */
@Mixin(ClientPlayerEntity.class)
public abstract class AutoSprintMixin {
    @Shadow private boolean canStartSprinting(){throw new AssertionError();}
    @Inject(method="tickMovement",at=@At("TAIL"))
    private void luma$autoSprint(CallbackInfo ci){
        MinecraftClient client=MinecraftClient.getInstance();
        ClientPlayerEntity player=(ClientPlayerEntity)(Object)this;
        if(LumaClient.settings==null||!LumaClient.settings.autoSprint||client.currentScreen!=null
            ||client.world==null||client.player!=player||!player.isAlive()||player.hasVehicle()
            ||player.isSpectator()||player.input==null||player.input.playerInput.sneak()
            ||!player.input.hasForwardMovement()||player.isUsingItem())return;
        if(canStartSprinting())player.setSprinting(true);
    }
}
