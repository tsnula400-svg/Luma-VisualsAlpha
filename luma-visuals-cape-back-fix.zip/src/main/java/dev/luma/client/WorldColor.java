package dev.luma.client;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;
import dev.luma.core.Settings;
import java.nio.ByteBuffer;
import org.lwjgl.BufferUtils;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.*;
import net.minecraft.client.render.*;
import net.minecraft.util.Identifier;
import org.lwjgl.opengl.*;
/** Reusable colour copy, after Ratio's full world pass and before GUI. No per-frame framebuffer allocation; draw submission remains Minecraft-owned. */
public final class WorldColor {
    private static final ShaderProgramKey KEY=new ShaderProgramKey(Identifier.of("luma","core/saturation"),VertexFormats.POSITION,Defines.EMPTY);
    private static final class Target extends Framebuffer {Target(){super(false);}}
    private static Target copy;private static double reportedAmount=Double.NaN;private static int failures;private static final int MAX_FAILURES=3;private static final ByteBuffer colorMask=BufferUtils.createByteBuffer(4);
    private static final int[] viewport=new int[4],scissorBox=new int[4];
    private static final boolean ALTERNATE=FabricLoader.getInstance().isModLoaded("iris")||FabricLoader.getInstance().isModLoaded("vulkanmod")||FabricLoader.getInstance().isModLoaded("optifabric")||FabricLoader.getInstance().isModLoaded("canvas");
    public static void apply(){
        var c=MinecraftClient.getInstance();var s=LumaClient.settings;
        if(s==null||!s.saturationEnabled||c.world==null){release();return;}
        double amount=Settings.clamp(s.saturation,0,1.5);if(Math.abs(amount-1)<.00001){s.saturationStatus="100% · исходные цвета · проход отключён";release();return;}
        if(ALTERNATE){s.saturationStatus="Недоступно с Iris / Vulkan / альтернативным рендером";release();return;}
        RenderSystem.assertOnRenderThread();Framebuffer main=c.getFramebuffer();int w=main.textureWidth,h=main.textureHeight;if(w<1||h<1)return;
        int read=GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING),draw=GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        GL11.glGetIntegerv(GL11.GL_VIEWPORT,viewport);
        GL11.glGetIntegerv(GL11.GL_SCISSOR_BOX,scissorBox);
        boolean blend=GL11.glIsEnabled(GL11.GL_BLEND),depth=GL11.glIsEnabled(GL11.GL_DEPTH_TEST),cull=GL11.glIsEnabled(GL11.GL_CULL_FACE),scissor=GL11.glIsEnabled(GL11.GL_SCISSOR_TEST),depthMask=GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        ShaderProgram oldShader=RenderSystem.getShader();int oldTexture=RenderSystem.getShaderTexture(0);
        int activeTexture=GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE),program=GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
        GlStateManager._activeTexture(GL13.GL_TEXTURE0);int boundTexture=GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
        colorMask.clear();GL11.glGetBooleanv(GL11.GL_COLOR_WRITEMASK,colorMask);
        boolean red=colorMask.get(0)!=0,green=colorMask.get(1)!=0,blue=colorMask.get(2)!=0,alpha=colorMask.get(3)!=0;
        int priorError=GL11.glGetError();if(priorError!=GL11.GL_NO_ERROR)LumaClient.LOG.debug("GL error before color pass: {}",priorError);
        try{
            ShaderProgram shader=c.getShaderLoader().getOrCreateProgram(KEY);
            if(shader==null||shader.getUniform("LumeSaturation")==null)throw new IllegalStateException("Saturation shader unavailable");
            if(copy==null||copy.textureWidth!=w||copy.textureHeight!=h){release();copy=new Target();copy.resize(w,h);copy.beginWrite(true);copy.checkFramebufferStatus();}
            RenderSystem.disableScissor();RenderSystem.colorMask(true,true,true,true);
            RenderSystem.disableBlend();RenderSystem.disableDepthTest();RenderSystem.depthMask(false);RenderSystem.disableCull();
            // Snapshot pass: identity amount (1.0) copies the scene texture without glBlitFramebuffer, which is the
            // fragile path on MobileGlues / OpenGL ES 3.x (format and multisample resolve mismatches fail silently).
            copy.beginWrite(true);
            if(GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER)!=GL30.GL_FRAMEBUFFER_COMPLETE)throw new IllegalStateException("Incomplete color framebuffer");
            draw(shader,main.getColorAttachment(),1f);
            if(GL11.glGetError()!=GL11.GL_NO_ERROR)throw new IllegalStateException("Color copy rejected by renderer");
            // Colour pass: the snapshot is sampled back into the main target with the selected amount.
            main.beginWrite(true);
            draw(shader,copy.getColorAttachment(),(float)amount);
            if(GL11.glGetError()!=GL11.GL_NO_ERROR)throw new IllegalStateException("Color draw rejected by renderer");
            failures=0;
            if(reportedAmount!=amount){reportedAmount=amount;s.saturationStatus="Цветовой проход · "+Math.round(amount*100)+"% · HUD без изменений";LumaClient.LOG.info("LUME color pass submitted: amount={}, size={}x{}, sourceFbo={}, copyFbo={}, renderer={}",amount,w,h,main.fbo,copy.fbo,GL11.glGetString(GL11.GL_RENDERER));}
        }catch(RuntimeException ex){
            reportedAmount=Double.NaN;LumaClient.LOG.warn("World colour pass failed (attempt {})",++failures,ex);
            // A single transient GL/state error must not silently kill the feature; only a repeatable failure disables it.
            if(failures>=MAX_FAILURES){s.saturationEnabled=false;s.saturationStatus="Эффект отключён: ошибка цветокоррекции";LumaClient.save();}
            else s.saturationStatus="Ошибка цветового прохода · повторная попытка";
        }
        finally{
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,read);GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER,draw);RenderSystem.viewport(viewport[0],viewport[1],viewport[2],viewport[3]);
            if(blend)RenderSystem.enableBlend();else RenderSystem.disableBlend();if(depth)RenderSystem.enableDepthTest();else RenderSystem.disableDepthTest();
            if(cull)RenderSystem.enableCull();else RenderSystem.disableCull();RenderSystem.depthMask(depthMask);
            if(scissor)RenderSystem.enableScissor(scissorBox[0],scissorBox[1],scissorBox[2],scissorBox[3]);else RenderSystem.disableScissor();
            RenderSystem.colorMask(red,green,blue,alpha);RenderSystem.setShaderTexture(0,oldTexture);
            GlStateManager._activeTexture(GL13.GL_TEXTURE0);GlStateManager._bindTexture(boundTexture);GlStateManager._activeTexture(activeTexture);
            if(oldShader==null)RenderSystem.clearShader();else RenderSystem.setShader(oldShader);GlStateManager._glUseProgram(program);
        }
    }
    /** One full-screen triangle through the shared saturation program; amount 1.0 is an exact copy (shader identity). */
    private static void draw(ShaderProgram shader,int texture,float amount){
        RenderSystem.setShader(shader);RenderSystem.setShaderTexture(0,texture);shader.addSamplerTexture("Sampler0",texture);shader.getUniform("LumeSaturation").set(amount);
        BufferBuilder buffer=Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES,VertexFormats.POSITION);
        buffer.vertex(-1,-1,0);buffer.vertex(3,-1,0);buffer.vertex(-1,3,0);BufferRenderer.drawWithGlobalProgram(buffer.end());
    }
    public static void release(){reportedAmount=Double.NaN;if(copy==null)return;Target old=copy;copy=null;
        int read=GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING),draw=GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING),id=old.fbo;
        try{old.delete();}finally{GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,read==id?0:read);GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER,draw==id?0:draw);}
    }
}
