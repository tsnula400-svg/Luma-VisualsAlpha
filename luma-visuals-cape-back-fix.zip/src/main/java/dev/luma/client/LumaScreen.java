package dev.luma.client;

import dev.luma.core.Menu;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class LumaScreen extends Screen {
    private final Menu menu=new Menu(LumaClient.settings);
    private long lastFrame=System.nanoTime(),saveAt;
    public LumaScreen(){super(Text.literal("LUME VISUALS"));}
    private double pixelRatio(){return client==null?1:client.getWindow().getScaleFactor();}
    @Override public boolean shouldPause(){return false;}
    // We deliberately do not call the vanilla background / blur pipeline.
    // Native world stays visible beneath our own user-adjustable overlay.
    @Override public void renderBackground(DrawContext c,int mx,int my,float delta){}
    @Override public void render(DrawContext context,int mx,int my,float delta){
        long now=System.nanoTime();double seconds=(now-lastFrame)/1_000_000_000.0;lastFrame=now;
        try(MinecraftCanvas canvas=new MinecraftCanvas(context,textRenderer)){
            double ratio=pixelRatio();
            canvas.push(0,0,1/ratio,1);
            try{menu.render(canvas,client.getWindow().getFramebufferWidth(),client.getWindow().getFramebufferHeight(),mx*ratio,my*ratio,seconds);}
            finally{canvas.pop();}
        }
        if(menu.takeChanged())saveAt=System.currentTimeMillis()+350;
        if(menu.takeHudRequested()&&client!=null){LumaClient.save();client.setScreen(new LumaHudScreen(this));return;}
        if(menu.closed()&&client!=null)client.setScreen(null);
    }
    @Override public void tick(){
        if(saveAt!=0&&System.currentTimeMillis()>=saveAt){saveAt=0;if(LumaClient.save())menu.saved();else menu.saveError();}
    }
    @Override public void close(){menu.requestClose();}
    @Override public void removed(){LumaClient.settings.viewModelPreview=false;LumaClient.settings.previewSwing=false;LumaClient.save();menu.release();}
    @Override public boolean mouseClicked(double x,double y,int button){return menu.click(x*pixelRatio(),y*pixelRatio(),button);}
    @Override public void mouseMoved(double x,double y){menu.move(x*pixelRatio(),y*pixelRatio());}
    @Override public boolean mouseDragged(double x,double y,int button,double dx,double dy){if(button==0){menu.move(x*pixelRatio(),y*pixelRatio());return true;}return false;}
    @Override public boolean mouseScrolled(double x,double y,double horizontalAmount,double verticalAmount){return menu.scroll(x*pixelRatio(),y*pixelRatio(),verticalAmount);}
    @Override public boolean mouseReleased(double x,double y,int button){menu.release();return true;}
    @Override public boolean keyPressed(int key,int scan,int mods){
        if(LumaClient.ratioResetKey.matchesKey(key,scan)){LumaClient.resetRatio();return true;}
        if(LumaClient.menuKey.matchesKey(key,scan)){menu.requestClose();return true;}
        return menu.key(key,(mods&GLFW.GLFW_MOD_CONTROL)!=0,(mods&GLFW.GLFW_MOD_SHIFT)!=0)||super.keyPressed(key,scan,mods);
    }
    @Override public boolean charTyped(char ch,int mods){return menu.character(ch);}
}
