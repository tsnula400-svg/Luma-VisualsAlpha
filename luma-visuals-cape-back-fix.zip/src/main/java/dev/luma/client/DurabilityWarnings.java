package dev.luma.client;
import dev.luma.core.DurabilityLatch;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import java.util.*;
public final class DurabilityWarnings {
    private static final DurabilityLatch latch=new DurabilityLatch();private static Object player;private static int ticks;
    private record Identity(Object item,Object components){}
    public static void tick(){var c=MinecraftClient.getInstance();
        if(c.player!=player){player=c.player;latch.clear();}
        if(c.player==null||!LumaClient.settings.durabilityWarning){latch.clear();return;}
        if(++ticks%10!=0)return;List<String> warnings=new ArrayList<>();
        inspect("head",c.player.getEquippedStack(EquipmentSlot.HEAD),warnings);inspect("chest",c.player.getEquippedStack(EquipmentSlot.CHEST),warnings);
        inspect("legs",c.player.getEquippedStack(EquipmentSlot.LEGS),warnings);inspect("feet",c.player.getEquippedStack(EquipmentSlot.FEET),warnings);
        inspect("main",c.player.getMainHandStack(),warnings);inspect("off",c.player.getOffHandStack(),warnings);
        if(!warnings.isEmpty())c.player.sendMessage(Text.literal("Luma · Скоро сломается: "+String.join(" · ",warnings)),true);
    }
    private static void inspect(String slot,ItemStack stack,List<String> warnings){
        if(stack.isEmpty()||!stack.isDamageable()){latch.update(slot,null,0,0,0);return;}
        ItemStack identity=stack.copy();identity.setDamage(0);identity.setCount(1);
        int left=stack.getMaxDamage()-stack.getDamage();
        if(latch.update(slot,new Identity(identity.getItem(),identity.getComponents()),left,stack.getMaxDamage(),LumaClient.settings.durabilityThreshold))warnings.add(stack.getName().getString()+" ("+left+")");
    }
}
