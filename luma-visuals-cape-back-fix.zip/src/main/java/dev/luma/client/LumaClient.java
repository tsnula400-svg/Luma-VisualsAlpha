package dev.luma.client;

import dev.luma.client.skin.CustomSkinManager;
import dev.luma.core.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.nio.file.Path;

public final class LumaClient implements ClientModInitializer {
    public static final Logger LOG=LoggerFactory.getLogger("Luma");
    public static final ModuleRegistry MODULES=new ModuleRegistry();
    private static final Path CONFIG=FabricLoader.getInstance().getConfigDir().resolve("luma-visuals.properties");
    public static Settings settings;
    public static KeyBinding menuKey,ratioResetKey;
    @Override public void onInitializeClient(){
        try{settings=Settings.load(CONFIG);}catch(IOException|IllegalArgumentException e){settings=new Settings();LOG.warn("Cannot read Luma preferences; using defaults",e);}
        menuKey=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.luma.menu",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_RIGHT_SHIFT,"category.luma"));
        ratioResetKey=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.luma.ratio_reset",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_F8,"category.luma"));
        LumaHud.initialize();
        CustomSkinManager.registerModelLayer();
        ClientLifecycleEvents.CLIENT_STOPPING.register(client->{WorldResolution.release();WorldColor.release();});
        ClientTickEvents.END_CLIENT_TICK.register(client->{
            LumaHud.tick();DropSafety.tick();ToolSafety.tick();DurabilityWarnings.tick();
            while(menuKey.wasPressed())if(client.currentScreen==null&&client.world!=null)client.setScreen(new LumaScreen());
            while(ratioResetKey.wasPressed())resetRatio();
            if(client.world!=null)MODULES.tick();else {MODULES.disableAll();WorldResolution.release();WorldColor.release();}
        });
        LOG.info("LUME VISUALS version={}, commit={}, sourceSha256={}. Right Shift opens the menu in a world.",BuildInfo.VERSION,BuildInfo.COMMIT,BuildInfo.SOURCE);
    }
    public static void resetRatio(){
        settings.ratioEnabled=false;settings.ratioStatus="Обычный мир восстановлен";WorldResolution.release();save();
    }
    public static boolean save(){
        try{settings.save(CONFIG);return true;}catch(IOException e){LOG.error("Cannot save Luma preferences",e);return false;}
    }
}
