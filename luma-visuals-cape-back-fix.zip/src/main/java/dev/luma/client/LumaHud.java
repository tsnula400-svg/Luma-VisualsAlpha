package dev.luma.client;
import dev.luma.core.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.minecraft.util.Identifier;
import java.util.*;
public final class LumaHud {
    private static HudLayout layout;
    private static final Map<String,ItemStack> items=new HashMap<>();
    private static HudLayout.Data data=new HudLayout.Data(new String[]{"—","— FPS","— ms","X — Y — Z —","0.0 б/с","—","— онлайн"},List.of(),List.of());
    private static long lastFrame;
    private static Object lastWorld;private static double px,pz,speed;private static long ticks;
    private static HudLayout engine(){if(layout==null)layout=new HudLayout(LumaClient.settings.hud);return layout;}
    public static void initialize(){HudLayerRegistrationCallback.EVENT.register(layers->layers.attachLayerBefore(IdentifiedLayer.CHAT,Identifier.of("luma","hud"),LumaHud::render));}
    public static void tick(){
        var c=MinecraftClient.getInstance();
        if(c.player==null||c.world==null){lastWorld=null;speed=0;items.clear();if(layout!=null)layout.resetAnimation();lastFrame=0;return;}
        if(lastWorld!=c.world){items.clear();if(layout!=null)layout.resetAnimation();lastFrame=0;lastWorld=c.world;px=c.player.getX();pz=c.player.getZ();speed=0;}
        if(c.isPaused())return;
        double dx=c.player.getX()-px,dz=c.player.getZ()-pz;px=c.player.getX();pz=c.player.getZ();double instant=Math.hypot(dx,dz)*20;
        speed=instant>100?0:Motion.damp(speed,instant,12,.05);
        if(++ticks%5!=0)return;
        var network=c.getNetworkHandler();var entry=network==null?null:network.getPlayerListEntry(c.player.getUuid());
        String ping=c.isInSingleplayer()?"Локально":entry==null?"— ms":entry.getLatency()+" ms";
        String server=c.isInSingleplayer()?"Одиночная игра":c.getCurrentServerEntry()==null?"Сервер":c.getCurrentServerEntry().name;
        String[] values={c.player.getName().getString(),c.getCurrentFps()+" FPS",ping,
            "X "+c.player.getBlockX()+"  Y "+c.player.getBlockY()+"  Z "+c.player.getBlockZ(),String.format(Locale.ROOT,"%.1f б/с",speed),server,
            (network==null?1:network.getPlayerList().size())+" онлайн"};
        // Retain six bounded icon keys while outgoing cards shrink.
        List<HudLayout.Equipment> armor=new ArrayList<>(),tools=new ArrayList<>();
        add(armor,"head",c.player.getEquippedStack(EquipmentSlot.HEAD));add(armor,"chest",c.player.getEquippedStack(EquipmentSlot.CHEST));
        add(armor,"legs",c.player.getEquippedStack(EquipmentSlot.LEGS));add(armor,"feet",c.player.getEquippedStack(EquipmentSlot.FEET));
        add(tools,"main",c.player.getMainHandStack());add(tools,"off",c.player.getOffHandStack());
        data=new HudLayout.Data(values,List.copyOf(armor),List.copyOf(tools));
    }
    private static void add(List<HudLayout.Equipment> list,String key,ItemStack stack){if(stack.isEmpty())return;
        items.put(key,stack.copy());int percent=stack.isDamageable()?(int)Math.ceil(100.0*(stack.getMaxDamage()-stack.getDamage())/stack.getMaxDamage()):-1;
        list.add(new HudLayout.Equipment(key,stack.getName().getString(),percent,true));
    }
    private static void render(DrawContext c,RenderTickCounter counter){
        var mc=MinecraftClient.getInstance();if(mc.player==null||mc.options.hudHidden||mc.currentScreen instanceof LumaHudScreen){lastFrame=0;return;}
        long now=System.nanoTime();double elapsed=lastFrame==0?0:(now-lastFrame)/1_000_000_000.0;lastFrame=now;
        double ratio=mc.getWindow().getScaleFactor();int w=mc.getWindow().getFramebufferWidth(),h=mc.getWindow().getFramebufferHeight();boolean editing=mc.currentScreen instanceof ChatScreen;
        try(MinecraftCanvas canvas=new MinecraftCanvas(c,mc.textRenderer)){canvas.push(0,0,1/ratio,1);try{engine().render(canvas,w,h,data,0xFF000000|LumaClient.settings.uiAccentColor(),editing,elapsed,LumaClient.settings.animated());}finally{canvas.pop();}}
        for(HudLayout.ItemIcon icon:engine().icons()){
            ItemStack stack=items.get(icon.key());if(stack==null)continue;
            c.getMatrices().push();try{c.getMatrices().translate(icon.x()/ratio,icon.y()/ratio,0);float s=(float)(icon.size()/16/ratio);c.getMatrices().scale(s,s,1);c.drawItem(stack,0,0);}finally{c.getMatrices().pop();}
        }
        c.draw();
    }
    private static double toolbarScale(){var w=MinecraftClient.getInstance().getWindow();return Settings.clamp(w.getFramebufferWidth()/1280.0,.6,1.5);}
    public static void toolbar(DrawContext c){var mc=MinecraftClient.getInstance();if(mc.options.hudHidden)return;double r=mc.getWindow().getScaleFactor(),s=toolbarScale(),x=mc.getWindow().getFramebufferWidth()-292*s-8;
        try(MinecraftCanvas canvas=new MinecraftCanvas(c,mc.textRenderer)){canvas.push(x/r,8/r,s/r,1);try{int a=0xFF000000|LumaClient.settings.uiAccentColor();canvas.round(0,0,292,32,8,0xEE111624);canvas.text(engine().allSelected()?"Снять выбор":"Выбрать все",10,6,15,a);canvas.line(151,6,151,26,1,0xFF4C5167);canvas.text("Сброс позиций",164,6,15,0xFFE9ECF8);}finally{canvas.pop();}}
    }
    public static boolean click(double x,double y,int button){var mc=MinecraftClient.getInstance();if(button!=0||mc.options.hudHidden)return false;double r=mc.getWindow().getScaleFactor();
        if(y>=mc.getWindow().getScaledHeight()-16)return false;double px=x*r,py=y*r,s=toolbarScale(),tx=mc.getWindow().getFramebufferWidth()-292*s-8;
        if(px>=tx&&px<tx+292*s&&py>=8&&py<8+32*s){if(px<tx+151*s){if(engine().allSelected())engine().clearSelection();else engine().selectAll();}else{engine().stop();LumaClient.settings.hud.resetPositions();LumaClient.save();}return true;}
        return engine().click(px,py,Screen.hasShiftDown());
    }
    public static boolean drag(double x,double y,int button){if(button!=0||!engine().dragging())return false;double r=MinecraftClient.getInstance().getWindow().getScaleFactor();engine().move(x*r,y*r);return true;}
    public static boolean release(){boolean active=engine().dragging();engine().stop();if(engine().takeChanged())LumaClient.save();return active;}
}
