package dev.luma.client.skin;

import dev.luma.client.LumaClient;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.Identifier;

/** Local cosmetic only. Never replaces a player renderer, profile or network skin. */
public final class CustomSkinManager {
    public static final EntityModelLayer LAYER = new EntityModelLayer(Identifier.of("luma", "custom_player"), "main");
    public static final Identifier SKIN_TEXTURE = Identifier.of("luma", "textures/entity/custom_skin.png");
    public static final Identifier PARTS_TEXTURE = Identifier.of("luma", "textures/entity/custom_skin_parts.png");
    public static final Identifier GLOW_TEXTURE = Identifier.of("luma", "textures/entity/custom_skin_glow.png");
    public static final RenderLayer MAIN_LAYER = RenderLayer.getEntityCutoutNoCull(PARTS_TEXTURE);
    public static final RenderLayer GLOW_LAYER = RenderLayer.getEyes(GLOW_TEXTURE);

    private CustomSkinManager() {}

    public static void registerModelLayer() {
        EntityModelLayerRegistry.registerModelLayer(LAYER, CustomSkinModel::getTexturedModelData);
        // Fabric's helper can add features without calling protected addFeature externally.
        // Both wide and slim player renderers, including resource reloads, use this event.
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, context) -> {
            if (renderer instanceof PlayerEntityRenderer playerRenderer) {
                helper.register(new CustomSkinFeatureRenderer(playerRenderer, context.getPart(LAYER)));
            }
        });
    }

    public static boolean isEnabled() {
        return LumaClient.settings != null && LumaClient.settings.customSkinEnabled;
    }

    public static boolean isEnabledFor(PlayerEntityRenderState state) {
        var player = MinecraftClient.getInstance().player;
        return isEnabled() && player != null && !state.spectator && state.id == player.getId();
    }

    /** First-person arm rendering does not receive a PlayerEntityRenderState in 1.21.4. */
    public static boolean isFirstPersonEnabled() {
        var player = MinecraftClient.getInstance().player;
        return isEnabled() && player != null && !player.isSpectator();
    }
}
