package dev.luma.client;
import dev.luma.core.DoublePress;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
/** Fresh hardware presses only. Intercepts vanilla requests; never sends its own drop packet. */
public final class DropSafety {
    private static final DoublePress confirmation=new DoublePress();
    private static long serial,lastAttempt=-1;private static boolean down;private static long notifiedSerial=-1;
    private static Object owner;private static int slot=-1;private static boolean entire;private static ItemStack snapshot=ItemStack.EMPTY;
    private static int selected=-1;private static Object screen,player;
    public static void key(int key,int scan,int action){var c=MinecraftClient.getInstance();if(!c.options.dropKey.matchesKey(key,scan))return;
        if(action==GLFW.GLFW_RELEASE)down=false;else if(action==GLFW.GLFW_PRESS&&!down){down=true;serial++;}
    }
    public static void reset(){confirmation.clear();owner=null;snapshot=ItemStack.EMPTY;slot=-1;}
    public static void tick(){var c=MinecraftClient.getInstance();int current=c.player==null?-1:c.player.getInventory().selectedSlot;
        if(player!=c.player||screen!=c.currentScreen||selected!=current||LumaClient.settings==null||!LumaClient.settings.dropProtection)reset();
        if(!c.isWindowFocused()){down=false;reset();}
        player=c.player;screen=c.currentScreen;selected=current;
    }
    public static void inspect(Object context,int id,ItemStack stack){if(owner!=null&&(context!=owner||id!=slot||!ItemStack.areEqual(snapshot,stack)))reset();}
    public static boolean allow(Object context,int id,ItemStack stack,boolean all){
        if(LumaClient.settings==null||!LumaClient.settings.dropProtection||stack.isEmpty())return true;
        if(serial<=0||serial<=lastAttempt)return false;lastAttempt=serial;
        boolean same=owner==context&&slot==id&&entire==all&&ItemStack.areEqual(snapshot,stack);
        boolean allowed=confirmation.attempt(serial,System.nanoTime(),same);
        if(allowed){owner=null;snapshot=ItemStack.EMPTY;return true;}
        owner=context;slot=id;entire=all;snapshot=stack.copy();
        var c=MinecraftClient.getInstance();if(c.player!=null&&notifiedSerial!=serial){notifiedSerial=serial;
            String key=c.options.dropKey.getBoundKeyLocalizedText().getString();
            c.player.sendMessage(Text.literal("Luma: ещё раз "+(all?"Ctrl + ":"")+key+" за 0,5 с — "+(all?"выбросить стак":"выбросить предмет")),true);
        }return false;
    }
}
