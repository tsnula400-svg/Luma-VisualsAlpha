package dev.luma.client;

import dev.luma.core.Canvas;
import dev.luma.core.UiFont;
import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import java.util.ArrayDeque;

/** Version-specific adapter, Yarn 1.21.4+build.8. Geometry uses POSITION_COLOR. */
public final class MinecraftCanvas implements Canvas,AutoCloseable {
    private record Transform(double x,double y,double s,double alpha){}
    private final ArrayDeque<Transform> stack=new ArrayDeque<>();
    private Transform t=new Transform(0,0,1,1);
    private final DrawContext context;
    private final double pixelsPerGui;
    private final int previousTexture;
    private record Label(String text,double x,double y,double size,int col){}
    private record Clip(double x,double y,double right,double bottom){}
    private final ArrayList<Label> labels=new ArrayList<>(64);
    private final ArrayDeque<Clip> clips=new ArrayDeque<>();
    private static final Identifier ATLAS=Identifier.of("luma","textures/font/ui-atlas.png");
    private static final double[] CX=new double[33],CY=new double[33],RX=new double[40],RY=new double[40];
    static {
        for(int i=0;i<=32;i++){CX[i]=Math.cos(i*Math.PI*2/32);CY[i]=Math.sin(i*Math.PI*2/32);}
        for(int i=0;i<40;i++){double a=Math.PI+(i/10)*Math.PI/2+(i%10)/9.0*Math.PI/2;RX[i]=Math.cos(a);RY[i]=Math.sin(a);}
    }
    private BufferBuilder buffer;
    private final boolean blend,depth,cull;
    private final int srcRgb,dstRgb,srcAlpha,dstAlpha;
    private final ShaderProgram previousShader;
    private final float[] previousColor;
    private int clipDepth;
    public MinecraftCanvas(DrawContext context,TextRenderer font){
        this.context=context;pixelsPerGui=MinecraftClient.getInstance().getWindow().getScaleFactor();previousTexture=RenderSystem.getShaderTexture(0);context.draw();
        blend=GL11.glIsEnabled(GL11.GL_BLEND);depth=GL11.glIsEnabled(GL11.GL_DEPTH_TEST);cull=GL11.glIsEnabled(GL11.GL_CULL_FACE);
        srcRgb=GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);dstRgb=GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        srcAlpha=GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);dstAlpha=GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        previousShader=RenderSystem.getShader();previousColor=RenderSystem.getShaderColor().clone();
        setup();
    }
    private void setup(){RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();RenderSystem.disableDepthTest();RenderSystem.disableCull();RenderSystem.setShaderColor(1,1,1,1);}
    @Override public void push(double x,double y,double scale,double alpha){stack.push(t);t=new Transform(t.x+x*t.s,t.y+y*t.s,t.s*scale,t.alpha*alpha);}
    @Override public void pop(){t=stack.pop();}
    private int color(int argb){return ((int)(((argb>>>24)&255)*t.alpha)<<24)|(argb&0xFFFFFF);}
    private boolean visible(double x,double y,double w,double h){
        if(t.alpha<.001)return false;if(clips.isEmpty())return true;
        Clip c=clips.peek();double sx=t.x+x*t.s,sy=t.y+y*t.s;
        return sx+w*t.s>=c.x&&sx<=c.right&&sy+h*t.s>=c.y&&sy<=c.bottom;
    }
    private void vertex(double x,double y,int argb){
        if(buffer==null){setup();RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);buffer=Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES,VertexFormats.POSITION_COLOR);}
        buffer.vertex(context.getMatrices().peek().getPositionMatrix(),(float)(t.x+x*t.s),(float)(t.y+y*t.s),0).color(color(argb));
    }
    private void tri(double x1,double y1,double x2,double y2,double x3,double y3,int col){vertex(x1,y1,col);vertex(x2,y2,col);vertex(x3,y3,col);}
    @Override public void rect(double x,double y,double w,double h,int col){if(w<=0||h<=0||!visible(x,y,w,h))return;tri(x,y,x+w,y,x+w,y+h,col);tri(x,y,x+w,y+h,x,y+h,col);}
    @Override public void gradient(double x,double y,double w,double h,int first,int last,boolean vertical){if(w<=0||h<=0||!visible(x,y,w,h))return;int tl=first,tr=vertical?first:last,br=last,bl=vertical?last:first;vertex(x,y,tl);vertex(x+w,y,tr);vertex(x+w,y+h,br);vertex(x,y,tl);vertex(x+w,y+h,br);vertex(x,y+h,bl);}
    @Override public void circle(double x,double y,double r,int col){
        if(r<=0||!visible(x-r,y-r,r*2,r*2))return;int n=32;double aa=.8/Math.max(.01,t.s*pixelsPerGui);
        for(int i=0;i<n;i++){
            double a=i*Math.PI*2/n,b=(i+1)*Math.PI*2/n;
            double x1=x+CX[i]*r,y1=y+CY[i]*r,x2=x+CX[i+1]*r,y2=y+CY[i+1]*r;
            tri(x,y,x1,y1,x2,y2,col);
            double ox1=x+CX[i]*(r+aa),oy1=y+CY[i]*(r+aa),ox2=x+CX[i+1]*(r+aa),oy2=y+CY[i+1]*(r+aa);
            vertex(x1,y1,col);vertex(ox1,oy1,col&0xFFFFFF);vertex(ox2,oy2,col&0xFFFFFF);
            vertex(x1,y1,col);vertex(ox2,oy2,col&0xFFFFFF);vertex(x2,y2,col);
        }
    }
    @Override public void round(double x,double y,double w,double h,double r,int col){
        if(w<=0||h<=0||!visible(x-2,y-2,w+4,h+4))return;r=Math.min(r,Math.min(w,h)/2);
        if(r<=0){rect(x,y,w,h,col);return;}double aa=.8/Math.max(.01,t.s*pixelsPerGui);
        for(int i=0;i<40;i++){
            int j=(i+1)%40,ci=i/10,cj=j/10;
            double cxi=(ci==0||ci==3)?x+r:x+w-r,cyi=ci<2?y+r:y+h-r,cxj=(cj==0||cj==3)?x+r:x+w-r,cyj=cj<2?y+r:y+h-r;
            double px=cxi+RX[i]*r,py=cyi+RY[i]*r,qx=cxj+RX[j]*r,qy=cyj+RY[j]*r;
            double opx=cxi+RX[i]*(r+aa),opy=cyi+RY[i]*(r+aa),oqx=cxj+RX[j]*(r+aa),oqy=cyj+RY[j]*(r+aa);
            tri(x+w/2,y+h/2,px,py,qx,qy,col);
            vertex(px,py,col);vertex(opx,opy,col&0xFFFFFF);vertex(oqx,oqy,col&0xFFFFFF);
            vertex(px,py,col);vertex(oqx,oqy,col&0xFFFFFF);vertex(qx,qy,col);
        }
    }
    @Override public void glow(double x,double y,double radius,int rgb,double strength){
        if(radius<=0||!visible(x-radius,y-radius,radius*2,radius*2))return;
        // Non-overlapping radial mesh; each covered pixel is blended once.
        for(int band=0;band<8;band++){
            double r0=radius*band/8,r1=radius*(band+1)/8;
            int c0=Canvas.alpha(rgb,strength*.75*Math.pow(1-band/8.0,2)),c1=Canvas.alpha(rgb,strength*.75*Math.pow(1-(band+1)/8.0,2));
            for(int i=0;i<32;i++){
                double ax=x+CX[i]*r0,ay=y+CY[i]*r0,bx=x+CX[i]*r1,by=y+CY[i]*r1,cx=x+CX[i+1]*r1,cy=y+CY[i+1]*r1,dx=x+CX[i+1]*r0,dy=y+CY[i+1]*r0;
                vertex(ax,ay,c0);vertex(bx,by,c1);vertex(cx,cy,c1);
                if(band>0){vertex(ax,ay,c0);vertex(cx,cy,c1);vertex(dx,dy,c0);}
            }
        }
    }
    @Override public void line(double x1,double y1,double x2,double y2,double width,int col){
        double len=Math.hypot(x2-x1,y2-y1);if(len<.0001)return;
        double nx=-(y2-y1)/len*width/2,ny=(x2-x1)/len*width/2;
        tri(x1+nx,y1+ny,x2+nx,y2+ny,x2-nx,y2-ny,col);
        tri(x1+nx,y1+ny,x2-nx,y2-ny,x1-nx,y1-ny,col);
    }
    @Override public void clip(double x,double y,double w,double h){
        flushLayer();double x1=t.x+x*t.s,y1=t.y+y*t.s,x2=t.x+(x+w)*t.s,y2=t.y+(y+h)*t.s;
        if(!clips.isEmpty()){Clip old=clips.peek();x1=Math.max(x1,old.x);y1=Math.max(y1,old.y);x2=Math.min(x2,old.right);y2=Math.min(y2,old.bottom);}
        clips.push(new Clip(x1,y1,x2,y2));
        context.enableScissor((int)Math.floor(x1),(int)Math.floor(y1),(int)Math.ceil(x2),(int)Math.ceil(y2));clipDepth++;
    }
    @Override public void unclip(){flushLayer();context.disableScissor();clips.pop();clipDepth--;}
    @Override public void text(String s,double x,double y,double size,int col){
        if(s.isEmpty()||((color(col)>>>24)&255)<1||!visible(x,y-3,UiFont.width(s,size),size*1.4))return;
        labels.add(new Label(s,t.x+x*t.s,t.y+y*t.s,size*t.s,color(col)));
    }
    @Override public double textWidth(String s,double size){return UiFont.width(s,size);}
    private void glyphVertex(BufferBuilder b,double x,double y,double u,double v,int col){
        b.vertex(context.getMatrices().peek().getPositionMatrix(),(float)x,(float)y,0).texture((float)u,(float)v).color(col);
    }
    private void flushLabels(){
        if(labels.isEmpty())return;setup();RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);RenderSystem.setShaderTexture(0,ATLAS);
        BufferBuilder b=Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_TEXTURE_COLOR);
        for(Label label:labels){
            // Follow fractional slide/scale positions; the existing atlas uses linear sampling.
            double cursor=label.x,baseline=label.y+label.size;
            for(int i=0;i<label.text.length();){
                int cp=label.text.codePointAt(i);i+=Character.charCount(cp);UiFont.Glyph g=UiFont.glyph(cp,label.size*pixelsPerGui);double k=label.size/g.em();
                if(g.width()>0){
                    double x=cursor+g.left()*k,y=baseline+g.top()*k,w=g.width()*k,h=g.height()*k;
                    double u=g.x()/(double)UiFont.WIDTH,v=g.y()/(double)UiFont.HEIGHT,ur=(g.x()+g.width())/(double)UiFont.WIDTH,vb=(g.y()+g.height())/(double)UiFont.HEIGHT;
                    glyphVertex(b,x,y,u,v,label.col);glyphVertex(b,x,y+h,u,vb,label.col);glyphVertex(b,x+w,y+h,ur,vb,label.col);glyphVertex(b,x+w,y,ur,v,label.col);
                }
                cursor+=UiFont.glyph(cp).advance()*label.size/UiFont.EM;
            }
        }
        var built=b.endNullable();if(built!=null)BufferRenderer.drawWithGlobalProgram(built);labels.clear();
    }
    private void flushLayer(){flush();flushLabels();}
    private void flush(){if(buffer!=null){BufferBuilder b=buffer;buffer=null;RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);BufferRenderer.drawWithGlobalProgram(b.end());}}
    @Override public void close(){
        try{flushLayer();}finally{
            while(clipDepth>0){context.disableScissor();clipDepth--;}
            if(blend)RenderSystem.enableBlend();else RenderSystem.disableBlend();
            RenderSystem.blendFuncSeparate(srcRgb,dstRgb,srcAlpha,dstAlpha);
            if(depth)RenderSystem.enableDepthTest();else RenderSystem.disableDepthTest();
            if(cull)RenderSystem.enableCull();else RenderSystem.disableCull();
            RenderSystem.setShaderTexture(0,previousTexture);
            RenderSystem.setShaderColor(previousColor[0],previousColor[1],previousColor[2],previousColor[3]);
            if(previousShader!=null)RenderSystem.setShader(previousShader);else RenderSystem.clearShader();
        }
    }
}
