package dev.luma.client;

import dev.luma.core.ToolSafetyRules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

/** Client-side normal SWAP into an empty player-inventory slot. No throw, no cursor clicks. */
public final class ToolSafety {
    private static Object player;
    private static ItemStack pending=ItemStack.EMPTY;
    private static int pendingHotbar=-1,pendingDestination=-1,waitTicks;
    private static ItemStack rejected=ItemStack.EMPTY;
    private static int rejectedHotbar=-1;
    private static long fullNoticeAt=Long.MIN_VALUE;
    private static long ticks;
    private ToolSafety(){}
    public static boolean supported(ItemStack stack){
        // Explicitly exclude wearable equipment, even if another mod adds it to a tool tag.
        if(stack.isEmpty()||!stack.isDamageable()||stack.contains(DataComponentTypes.EQUIPPABLE)||stack.isOf(Items.ELYTRA)||stack.isOf(Items.SHIELD))return false;
        return stack.isIn(ItemTags.SWORDS)||stack.isIn(ItemTags.PICKAXES)||stack.isIn(ItemTags.AXES)
            ||stack.isIn(ItemTags.SHOVELS)||stack.isIn(ItemTags.HOES)
            ||stack.isOf(Items.SHEARS)||stack.isOf(Items.FISHING_ROD)||stack.isOf(Items.FLINT_AND_STEEL)
            ||stack.isOf(Items.BRUSH)||stack.isOf(Items.BOW)||stack.isOf(Items.CROSSBOW)
            ||stack.isOf(Items.TRIDENT)||stack.isOf(Items.MACE);
    }
    private static boolean sameTool(ItemStack a,ItemStack b){
        if(a.isEmpty()||b.isEmpty())return false;
        ItemStack x=a.copy(),y=b.copy();x.setDamage(0);y.setDamage(0);x.setCount(1);y.setCount(1);
        return ItemStack.areEqual(x,y);
    }
    private static void reset(){pending=ItemStack.EMPTY;rejected=ItemStack.EMPTY;pendingHotbar=pendingDestination=rejectedHotbar=-1;waitTicks=0;fullNoticeAt=Long.MIN_VALUE;}
    private static void notice(String message){var p=MinecraftClient.getInstance().player;if(p!=null)p.sendMessage(Text.literal("Luma · "+message),true);}
    public static void tick(){
        var c=MinecraftClient.getInstance();ticks++;
        if(player!=c.player){player=c.player;reset();}
        if(c.player==null||c.world==null||c.interactionManager==null||LumaClient.settings==null||!LumaClient.settings.toolSafety){reset();return;}
        var p=c.player;var inventory=p.getInventory();
        // Wait for the previous operation. Do not flood a server that refuses the swap.
        if(!pending.isEmpty()){
            if(++waitTicks<10)return;
            if(inventory.getStack(pendingHotbar).isEmpty()&&sameTool(inventory.getStack(pendingDestination),pending)){
                notice("Инструмент убран в инвентарь: "+pending.getName().getString());
            }else{rejected=pending.copy();rejectedHotbar=pendingHotbar;notice("Перенос не подтверждён. Остановись и убери инструмент вручную.");}
            pending=ItemStack.EMPTY;return;
        }
        ItemStack held=p.getMainHandStack();int selected=inventory.selectedSlot;
        if(!sameTool(rejected,held)||selected!=rejectedHotbar||held.getMaxDamage()-held.getDamage()>ToolSafetyRules.effectiveThreshold(held.getMaxDamage(),LumaClient.settings.toolSafetyThreshold))rejected=ItemStack.EMPTY;
        if(!rejected.isEmpty())return;
        if(!ToolSafetyRules.needsStash(supported(held),held.getMaxDamage()-held.getDamage(),held.getMaxDamage(),LumaClient.settings.toolSafetyThreshold))return;
        // Do not mutate a chest, trade, creative inventory or an active cursor transaction.
        if(c.currentScreen!=null||p.currentScreenHandler!=p.playerScreenHandler||!p.playerScreenHandler.getCursorStack().isEmpty()
            ||p.isSpectator()||p.isCreative()||p.isUsingItem()||c.isPaused())return;
        boolean[] empty=new boolean[36];for(int i=9;i<36;i++)empty[i]=inventory.getStack(i).isEmpty();
        int destination=ToolSafetyRules.emptyMainSlot(empty);
        if(destination<0){
            if(fullNoticeAt==Long.MIN_VALUE||ticks-fullNoticeAt>=100){fullNoticeAt=ticks;notice("Нет места для инструмента — освободи слот! Осталось "+(held.getMaxDamage()-held.getDamage())+" прочности.");}
            return;
        }
        // Resolve the slot through the live handler; never assume container slot numbering.
        int target=-1;for(var slot:p.playerScreenHandler.slots)if(slot.inventory==inventory&&slot.getIndex()==destination&&slot.getStack().isEmpty()&&slot.canInsert(held)){target=slot.id;break;}
        if(target<0)return;
        ItemStack snapshot=held.copy();
        if(!ItemStack.areEqual(inventory.getStack(selected),snapshot)||!inventory.getStack(destination).isEmpty())return;
        pending=snapshot;pendingHotbar=selected;pendingDestination=destination;waitTicks=0;
        notice("Порог защиты: "+ToolSafetyRules.effectiveThreshold(held.getMaxDamage(),LumaClient.settings.toolSafetyThreshold)+" ед. · осталось "+(held.getMaxDamage()-held.getDamage()));
        DropSafety.reset();
        try{c.interactionManager.cancelBlockBreaking();c.interactionManager.clickSlot(p.playerScreenHandler.syncId,target,selected,SlotActionType.SWAP,p);}
        catch(RuntimeException error){pending=ItemStack.EMPTY;rejected=snapshot;rejectedHotbar=selected;LumaClient.LOG.warn("Tool safety transfer failed",error);notice("Не удалось убрать инструмент. Убери его вручную.");}
    }
}
