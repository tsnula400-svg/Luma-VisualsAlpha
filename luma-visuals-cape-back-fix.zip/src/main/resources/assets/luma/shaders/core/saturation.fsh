#version 150
#if defined(GL_ES) || defined(MG_MOBILEGLUES)
precision highp float;
precision highp int;
#endif
uniform sampler2D Sampler0;
uniform float LumeSaturation;
in vec2 uv;
out vec4 fragColor;
void main(){
 vec4 source=texture(Sampler0,uv);vec3 rgb=clamp(source.rgb,0.0,1.0);
 float amount=clamp(LumeSaturation,0.0,1.5);
 // Display-referred Rec.709 luma, NOT linear-light physical luminance.
 // Vanilla RGBA8 framebuffer: avoid an additional gamma encode/decode.
 float luma=dot(rgb,vec3(0.2126,0.7152,0.0722));vec3 chroma=rgb-vec3(luma);
 float hi=max(chroma.r,max(chroma.g,chroma.b)),lo=min(chroma.r,min(chroma.g,chroma.b));
 // Limit along the same chroma ray: preserve hue/luma at the gamut boundary.
 float gain=min(amount,min((1.0-luma)/max(hi,0.00001),luma/max(-lo,0.00001)));
 if(abs(amount-1.0)<0.00001){fragColor=source;return;}
 fragColor=vec4(clamp(vec3(luma)+chroma*gain,0.0,1.0),source.a);
}
