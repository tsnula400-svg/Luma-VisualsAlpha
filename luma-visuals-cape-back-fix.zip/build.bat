@echo off
cd /d "%~dp0"
where gradle >nul 2>&1
if errorlevel 1 (
  echo Install Gradle 8.12 and add its bin folder to PATH.
  echo Use JDK 21. See README_RU.md.
  pause
  exit /b 1
)
call gradle --no-daemon build
if errorlevel 1 (echo Build failed. Read the error above.) else (echo Output: build\libs\luma-visuals-0.1.4.jar)
pause
