# LUME VISUALS — аудит 2026-09-08

**Статус: исправления исходников/CI переданы, но релиз НЕ подтверждён. Fabric JAR НЕ СОБРАН.**
**Minecraft + Zalith Launcher 2 + Android + MobileGlues: NOT RUN.**

## CHANGED

- Продолжен приложенный проект, без переписывания архитектуры и UI.
- Сохранены mod ID `luma`, файл `config/luma-visuals.properties`, ключи настроек, зависимости Minecraft/Fabric и ресурсы.
- Версия изменена с `0.1.5` на `0.1.6-audit.1` исключительно для различимости результата аудита.
- Добавлен `BuildInfo`: нижняя строка меню в широком и компактном режиме показывает версию и первые восемь символов SHA-256 исходников. Полные commit/source SHA записываются в журнал при инициализации. В несобранном preview указано UNBUILT, а не вымышленная версия.
- Изменён существующий `.github/workflows/build.yml`; второго workflow нет.
- Добавлены генератор происхождения сборки, проверка JAR, тесты выбора исходников и реальные UI/core-регрессии.

## FIXED

### Подтверждённый дефект выбора исходников

Прежний `build.yml` первым выбирал `LumaVisuals-0.1.5-Katana-Prism-MobileFix.zip`, распаковывал его во временную папку и игнорировал актуальную распакованную папку проекта. Только при отсутствии этого ZIP выбирались исходники из `LumaVisuals/` или корня.

Это воспроизведено запуском **исходного shell-блока workflow** на синтетическом репозитории с одновременно присутствующими новым деревом и старым ZIP-маркером: выбран ZIP. Лог: `audit/current/original-workflow-reproduction.log`. Это не копия исторического репозитория пользователя и не исследование его фактического artifact.

Исправление:
1. ZIP больше никогда не распаковывается и не используется как исходник.
2. Разрешено ровно одно дерево проекта: корень или `LumaVisuals/`. Несколько деревьев, в том числе backup с `build.gradle`, приводят к отказу.
3. При вложенном проекте корневой активный workflow должен совпадать с проверенным вложенным файлом.
4. Checkout явно использует `github.sha`; HEAD сравнивается с GITHUB_SHA.
5. Старый `build/` удаляется. Запуск: `gradle --no-daemon --no-build-cache --rerun-tasks clean build`.
6. Выбирается точный runtime JAR, а не `*-sources.jar` или первый файл wildcard.
7. Каталог artifact создаётся заново; публикация происходит только после успешной проверки JAR. Имя artifact содержит commit, run ID и attempt.

## CAUSE

| Категория | Вывод |
|---|---|
| A — исходники/реализация | Не установлена как причина старого вида. Render-подключения присутствуют; перечисленные ниже ограничения реализации сохраняются. Успешный core-тест не исключает ошибки Minecraft-адаптера или shader pass. |
| B — Gradle/Fabric | Не подтверждена и не исключена. Полная сборка здесь недоступна. В исходном Gradle нет выбора старого ZIP или явного альтернативного sourceSet. |
| C — build.yml | **Подтверждён дефект приоритета старого архива; исправлен.** Привязка к конкретному прежнему запуску ещё не доказана. |
| D — artifact/JAR | Прежний JAR не приложен; проверить его фактическое содержимое, SHA и версию невозможно. Новый JAR здесь не получен. |
| E — установка/запуск | Не исследована. Оснований обвинять пользователя или Zalith нет. |
| F — in-game поведение | Реальное применение mixin’ов и итоговое изображение на MobileGlues не проверены; остаются NOT RUN. |

**Не утверждаю, что C — единственная или окончательная причина наблюдения пользователя.** Даже если Actions checkout выбрал правильный commit, прежний workflow мог собрать старый ZIP внутри этого commit. Для исторической причинной связи нужны прежний JAR и журнал Actions либо дерево соответствующего commit. Их можно исследовать без повторного in-game теста.

Прежний архив также содержал `PACKAGE_VERIFICATION.txt` с явным `Fabric build: NOT RUN`, отсутствием JAR и неизменённым workflow. Название Final и сообщение о готовности не были достаточным основанием для передачи как проверенного результата. Это ошибка прежней проверки/передачи, а не доказательство ошибки установки.

## CODE

### Цепочки функций

В таблице FINAL OUTPUT означает отдельный игровой этап: ни одна строка не означает, что изображение на Android уже подтверждено.

| Функция | SETTING → CONFIG → RUNTIME → FUNCTION → RENDER CALL | Проверено до передачи | FINAL OUTPUT |
|---|---|---|---|
| Menu | Клавиша → `LumaClient.menuKey` → `new LumaScreen()` → `LumaScreen.render` → `Menu.render` → `MinecraftCanvas` → BufferRenderer | Точка входа и адаптер прочитаны; реальные core/input-тесты пройдены. Экран открывается в мире, не заменяет главное меню Minecraft. | NOT RUN |
| LV / LUME VISUALS | Постоянные подписи, не настройка → `Menu.sidebar/about`, `LumaScreen` title → `Canvas.text` → atlas quads в `MinecraftCanvas.flushLabels` | Подключены к игровому экрану. В компактной боковой панели намеренно только LV; текст LUME VISUALS виден в широком режиме/«О проекте». Добавлен маркер сборки снизу. | NOT RUN |
| Menu Animations | UI style/duration/intensity → поля и Properties в Settings → общий объект `LumaClient.settings` → Motion в Menu.render → Canvas.push(alpha/scale/translation) → MinecraftCanvas vertices | Пройдены UI, переходы, открытие/закрытие, математика преобразований. Off/reduced/motion учитываются. | NOT RUN |
| Menu Particles | UI style/amount/speed/size/opacity/direction/color → Settings.save/load → Menu.background → MenuParticles.render → Canvas.dot/rect → MinecraftCanvas geometry | Проверены реальный UI, ненулевое число draw-примитивов для включённых стилей и изменение координат. | NOT RUN |
| Color Picker | accentSV/Hue/customAccent → HSV Properties → Settings.accentColor/uiAccentColor → Menu/HUD colors → Canvas gradient/text/geometry | UI изменяет HSV; roundtrip сохраняет цвет; чёрные/тёмные цвета специально осветляются для читаемости UI. | NOT RUN |
| Saturation | slider → saturation + saturationEnabled → сохранённый Settings → WorldColorMixin → WorldColor.apply → uniform/shader/FBO → fullscreen triangle | UI 0/50/100/150 и persistence, статическая трассировка, отдельный GLSL ES surrogate. Подробности ниже. | NOT RUN |
| View Model | UI enabled/main/off/pose → ViewModelConfig Properties → LumaClient.settings.viewModel → HeldItemRendererMixin.renderFirstPersonItem → MatrixStack + вызов оригинального рендера | Это настоящий first-person hook по исходникам, не нарисованная preview-модель. Проверены UI значений обеих рук, независимость, сохранение и пресеты. | NOT RUN |
| Swing | UI swingStyle и Custom-параметры → ViewModelConfig → progress/strength + SwingTransform → renderFirstPersonItem/swingArm wrappers → MatrixStack → оригинальный рендер предмета | UI переключения всех стилей, математические границы/швы, чтение wrapper’ов. Не изменяет сетевой attack timer. | NOT RUN |
| Equip | UI equipStyle → ViewModelConfig → equip(equipProgress) → оригинальный renderFirstPersonItem и applyEquipOffset | UI четырёх режимов, границы функции и статическое подключение. Скорость — визуальная кривая, не ускорение смены слота на сервере. | NOT RUN |
| HUD | UI HudSettingsPanel/перетаскивание → Settings.hud/HudConfig → LumaHud.engine/tick → зарегистрированный HudLayer до CHAT → HudLayout.render → MinecraftCanvas + DrawContext.drawItem | UI-переход, core-конфигурация/layout, исходники регистрации игрового слоя. Старые HUD-тесты пройдены. | NOT RUN |

### View Model: точная область действия

- Выбор `Hand.MAIN_HAND`/`OFF_HAND` выбирает `vm.main`/`vm.off`; изменение второй руки не перезаписывает первую.
- `matrices.translate(horizontal, vertical, -distance)`: X — влево/вправо; Y — вниз/вверх; положительный distance отодвигает от камеры.
- `rotationXYZ(pitch, yaw, tilt)` в радианах, затем `scale` по трём осям. `push/pop` защищены finally.
- Пресеты Default/Compact/Large/Low/High/Custom меняют именно эти runtime-поля.
- Smooth/Fast изменяют visual progress; Wide/Compact/Custom проходят собственный swingArm; Off обнуляет swing progress. Equip управляется независимо от swing style, но общий View Model должен быть включён.
- Леворукость/праворукость игрока и видимость рук остаются в ванильном renderer; swing использует armX. Это не принудительное включение скрытой ванилью off-hand.
- **Ограничения исходной реализации:** пустая рука, карта, арбалет и `player.isUsingItem()` обходят все View Model изменения. Использование предмета в одной руке временно оставляет обе ванильными. Это сохранённый защитный guard, не поддержка всех возможных first-person путей.
- «Живой предпросмотр» сужает существующее меню и оставляет реальный мир видимым; preview swing подаёт визуальный progress в тот же hook. Никакой фальшивой 3D-модели для View Model нет. Требуются первое лицо и видимый предмет.
- Сигнатуры hook’ов сверены с Yarn 1.21.4+build.8. Это **не** применение Mixin в runtime и **не** проверка совместимости с другими модами.

### Почему часть нововведений могла быть незаметна даже в новых исходниках

Это условия, а не диагноз прежнего запуска:
- `particleStyle=0` по умолчанию означает Off; при background=false частицы не рисуются. При reduced=true движение заморожено. В efficient mode лимит 40, иначе 64.
- По умолчанию `saturationEnabled=false`, saturation=1: цветовой эффект отсутствует. На 100% pass специально отключён.
- `viewModel.enabled=false` по умолчанию; нейтральные pose дают ванильный вид.
- Существующие настройки не сбрасываются: motion=false/reduced=true/animationStyle=Off могут скрывать новые анимации.
- Архитектура/основной дизайн меню сохранены по требованию; само сходство не доказывает старый JAR. Для различения добавлен source marker.

### Saturation: UI → итоговая картинка

1. `Menu.visuals` slider задаёт `saturation=v*1.5` и включает эффект.
2. Изменение отмечается dirty, `LumaScreen` сохраняет общий Settings с задержкой; значения читаются renderer непосредственно, не из отдельной мёртвой копии.
3. Зарегистрированный required `WorldColorMixin` вызывает `WorldColor.apply()` после `GameRenderer.renderWorld` и до последующего GUI. Ratio оборачивает renderWorld и завершает свою обработку до этой точки.
4. Получается актуальная ShaderProgram через ShaderLoader; проверяется uniform `LumeSaturation`, задаётся amount. `Sampler0` указывает на отдельную копию текстуры, не на текущую draw attachment.
5. Цвет основного framebuffer копируется в отдельный color-only framebuffer. Проверяются READ/DRAW completeness, используется COLOR_BUFFER_BIT + NEAREST, depth не копируется.
6. Вывод в основной FBO полноэкранным треугольником `POSITION`. Blend/depth/cull/scissor отключаются; depthMask=false. В finally восстановлены framebuffer bindings, viewport, scissor, enable states, depth/color masks, shader/GL program, unit0 binding и active texture.
7. В shader — Rec.709 display-referred luma, chroma gain с ограничением gamut. 0% даёт серый; 50% уменьшает chroma; 100% сохраняет картинку; 150% усиливает chroma, но на границе gamut не обязано менять насыщенный цвет. Alpha сохраняется.

**MobileGlues/GLSL ES аудит:**
- Поставляемые `.vsh/.fsh` имеют `#version 150` для Minecraft desktop shader loader. MobileGlues переводит desktop GLSL в GLSL ES; менять исходник на `#version 300 es` вслепую для Minecraft нельзя.
- В обоих исходниках есть условные `precision highp float/int` для GL_ES или MG_MOBILEGLUES. Официальный README MobileGlues описывает конвертацию директив и макрос MG_MOBILEGLUES начиная с 1.2.6. Версия renderer пользователя неизвестна.
- Используются sampler2D, vec-входы/выходы, без compute/SSBO/geometry shader. Uniform amount устанавливается перед draw, texture sampler привязан явно.
- Формат промежуточной текстуры выбирает Minecraft Framebuffer; код предполагает обычный vanilla color buffer. RGBA8 проверен **только в surrogate**, не фактический MobileGlues FBO/формат/состояние sRGB/MSAA телефона.
- Размерный FBO переиспользуется, пересоздаётся при resize и освобождается при выходе из мира/отключении. Проверка framebuffer completeness не доказывает правильную картинку.
- ShaderProgram не хранится между кадрами: lookup через текущий ShaderLoader позволяет получить программу после reload; uniform назначается заново. Реальный F3+T/reload в игре не запускался. Surrogate перекомпилирует shader, но это не Minecraft resource reload.
- При RuntimeException исходный код выключает saturationEnabled, сохраняет настройку и пишет предупреждение. После такой ошибки один reload не включает эффект обратно: потребуется повторное включение. Это диагностический риск, не доказанная причина этого случая; без реального лога shader pass не переписан наугад.
- Iris/VulkanMod/OptiFabric/Canvas вызывают явный bypass. Состав модов пользователя неизвестен.
- Лог «color pass submitted» означает отправку draw, а не подтверждение конечного изображения. Восстановление GL-состояния, реальные текстурные форматы, драйверная precision и взаимодействие с последующими проходами на MobileGlues остаются непроверенными.

Публичные справочные источники:
- https://maven.fabricmc.net/docs/yarn-1.21.4+build.8/net/minecraft/client/render/item/HeldItemRenderer.html
- https://maven.fabricmc.net/docs/yarn-1.21.4+build.8/net/minecraft/client/gl/class-use/ShaderProgramKey.html
- https://github.com/MobileGL-Dev/MobileGlues-release

## BUILD

**NOT RUN — полноценная Fabric сборка заблокирована окружением.**

В этой среде есть Java 25 с compiler module (core компилирован с `--release 21`), но нет Gradle, JDK 21 или локального набора Minecraft/Fabric зависимостей. DNS для services.gradle.org и maven.fabricmc.net недоступен. Лог: `audit/current/build-environment.log`.

Java compiler module позволил выполнить core-тесты и syntax parsing 45 main Java files. Это не проверяет типы Minecraft API, обработчики аннотаций, refmap или применение Mixin. Новые Gradle task/provenance и полная цепочка workflow в GitHub ещё не выполнялись. YAML и bash-синтаксис, Python tools и выбор проекта проверены отдельно.

В исправленном workflow JDK 21 / Gradle 8.12. Фиксации Loom 1.9.2, Yarn 1.21.4+build.8, Loader 0.16.10, Fabric API 0.119.2+1.21.4 сохранены.

## JAR

**Новый устанавливаемый JAR НЕ создан и НЕ включён. Старого JAR в приложенном архиве нет.**

Ожидаемый файл после успешной CI-сборки: `luma-visuals-0.1.6-audit.1.jar`.

Добавленная проверка перед публикацией:
- mod ID/version/environment/entrypoint и Minecraft metadata;
- полный source manifest и commit, совпадение с текущим деревом/сгенерированными ресурсами;
- ресурсы, shader’ы, шрифты и mixin config (с учётом refmap, который может добавить Loom);
- наличие всех скомпилированных классов, отсутствие preview-классов, Java class major=65;
- сравнение core-классов с текущей компиляцией: точные байты либо disassembly с нормализованными constant-pool indices;
- intermediary targets/ключевые Mixin selectors в remapped классах или refmap;
- SHA-256 итогового JAR.

Ограничение: проверка не доказывает полную семантическую эквивалентность всех client-классов после remap и не запускает Minecraft. За актуальность client-байткода отвечает также чистая сборка ровно выбранного дерева. Полный успешный прогон verifier на настоящем Fabric JAR **ещё не состоялся**. Выполнены отрицательные synthetic package-тесты, а не положительный тест «готового JAR».

Будущий artifact содержит ровно выбранный runtime JAR, `JAR-VERIFICATION.json`, `SOURCE-IDENTITY.json`, `JAR-SHA256SUMS.txt`, build/core logs и IN-GAME-STATUS.txt. Никакой artifact от GitHub в этом сеансе не скачивался: это описание исправленного механизма публикации, не заявление о проверке реального удалённого artifact.

## VERIFIED

Свежие результаты лежат в `audit/current/`, не в прежнем `verification/`.

- Повторно выполнены исходные core/regression tests на отдельной неизменённой распаковке; проходят. Это показывает, что одних этих тестов недостаточно, чтобы исключить выбор старых исходников workflow.
- На исправленной версии: существующие core/UI/HUD/config тесты проходят; static/math suite проходит; syntax parsing проходит.
- Добавлено **1117 проверок** реальных UI handlers/persistence: Saturation 0/50/100/150, main/off параметры, пресеты/стили, picker, HUD route, ненулевые draw calls частиц и их движение, маркер сборки.
- **16 unit-тестов** source selection/provenance/отказа от неверного package проходят. Это synthetic filesystem/ZIP fixtures, не запуск Actions.
- Исходный workflow воспроизвёл старый ZIP при наличии нового дерева в контролируемом fixture.
- Проверено: generated properties → реальный `BuildInfo` → версия и source marker.
- Программный shader-test: WebGL2 / ANGLE / SwiftShader, исходная version directive заменена на GLSL ES 300. Пройдены 12 readback cases для 0/.5/1/1.5 (с повторными переключениями), двух размеров FBO и alpha; recompile PASS. **Не Minecraft, не MobileGlues.**
- Сохранённые проверки custom skin: 5248 recording-double assertions проходят. **Не реальный renderer Minecraft.**
- Ресурсы `src/main/resources` сравниваются с входным архивом: все сохранены побайтово; игровые render-mixin’ы и WorldColor не переписаны без доказанной причины.

## REMAINING

1. Выполнить полноценную чистую Fabric сборку там, где доступны Gradle и зависимости. До этого пакет — промежуточные исправленные исходники, а не готовый релиз.
2. Получить настоящий результат сборки, выполнить verifier на нём; при ошибке CI исследовать и исправить, а не обходить проверку или выдавать старый JAR.
3. Для установления причины прежнего результата исследовать **тот самый ранее установленный JAR** и лог/ссылку старого Actions run (либо архив соответствующего commit). Это технические входные данные для аудитора, не просьба к QA доказывать работу кода.
4. После технической проверки JAR провести отдельный финальный in-game тест на устройстве пользователя. Не переносить выводы SwiftShader на MobileGlues.
5. Проверить runtime mixin application, обе руки/леворукость, предметы и vanilla bypass, первый вид, переключения стилей, FBO resize, HUD preservation, GL state, shader/resource reload и повторное включение после ошибки.

## IN-GAME VERIFICATION

**NOT RUN**

Финальный QA — пользователь. Этот отчёт не ставит PASS за Minecraft, Zalith Launcher 2, Android, MobileGlues или драйвер телефона.

После получения действительно проверенного JAR минимальный QA-план:
- Проверить видимый маркер версии/source; не считать его доказательством работы эффектов.
- Меню: открыть/закрыть, сменить вкладки, включить анимации и каждый particle style; проверить цветовую палитру.
- Saturation: включить 0/50/100/150 на одинаковой цветной сцене; 0 — серый мир, HUD/menu сохраняют цвет; 100 — исходный мир; при 150 использовать не только уже предельно насыщенные цвета.
- View Model: непустые обычные предметы в обеих руках, первое лицо, включённый View Model; независимые X/Y/Z/scale/rotation/presets, main/off, леворукость, Swing и Equip.
- Отдельно проверить карты/арбалет/использование/пустую руку как документированные vanilla bypass, а не как реализованную поддержку VM.
- Resize/GUI scale/выход-вход в мир/reload: отсутствие чёрного кадра, повреждения HUD, зависших текстур/GL state.
