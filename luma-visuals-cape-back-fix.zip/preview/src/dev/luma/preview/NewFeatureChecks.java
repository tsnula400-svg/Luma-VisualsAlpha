package dev.luma.preview;
import dev.luma.core.*;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.nio.file.*;
import java.util.List;
public final class NewFeatureChecks {
    private static int n;
    private static void check(boolean b,String s){n++;if(!b)throw new AssertionError(s);}
    private static void near(double x,double y,String s){check(Math.abs(x-y)<.001,s);}
    private static HudLayout.Data sample(){return new HudLayout.Data(new String[]{"TradeFromScratch","144 FPS","38 ms","X -435  Y 72  Z -50","4.3 б/с","Мой сервер","18 онлайн"},List.of(new HudLayout.Equipment("head","Шлем",100,true),new HudLayout.Equipment("chest","Нагрудник",82,true),new HudLayout.Equipment("legs","Штаны",48,true),new HudLayout.Equipment("feet","Ботинки",9,true)),List.of(new HudLayout.Equipment("main","Кирка",24,true),new HudLayout.Equipment("off","Меч",62,true)));}
    static void hud(HudLayout hud,int w,int h,boolean edit,Path file)throws Exception{
        BufferedImage image=new BufferedImage(file==null?1:w,file==null?1:h,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();
        g.setPaint(new GradientPaint(0,0,new Color(0x283449),w,h,new Color(0x526971)));g.fillRect(0,0,w,h);
        try(Java2DCanvas c=new Java2DCanvas(g,Preview.font())){hud.render(c,w,h,sample(),0xFFA599FF,edit);
            // Neutral diagram markers only; Minecraft draws actual item icons at these exact bounds.
            for(HudLayout.ItemIcon i:hud.icons()){double z=i.size();c.round(i.x(),i.y(),z,z,3,0xFF728299);c.line(i.x()+z*.25,i.y()+z*.75,i.x()+z*.75,i.y()+z*.25,2,0xFFE2EBF8);}
            if(file!=null)c.text("Luma HUD · макет интерфейса, не скриншот Minecraft",14,h-34,16,0xFFD9E1EC);
        }finally{g.dispose();}if(file!=null)ImageIO.write(image,"png",file.toFile());
    }
    static void panel(HudSettingsPanel panel,int w,int h,Path file)throws Exception{
        BufferedImage img=new BufferedImage(file==null?1:w,file==null?1:h,BufferedImage.TYPE_INT_RGB);Graphics2D g=img.createGraphics();g.setColor(new Color(0x293345));g.fillRect(0,0,w,h);
        try(Java2DCanvas c=new Java2DCanvas(g,Preview.font())){panel.render(c,w,h);}finally{g.dispose();}if(file!=null)ImageIO.write(img,"png",file.toFile());
    }
    public static void main(String[] args)throws Exception{
        Path out=Path.of(args.length>0?args[0]:"preview/images");Files.createDirectories(out);
        DoublePress d=new DoublePress();check(!d.attempt(1,0,false),"first blocked");check(!d.attempt(1,20,true),"repeat blocked");check(d.attempt(2,300_000_000,true),"second confirms");check(!d.attempt(3,350_000_000,true),"no persistent unlock");check(!d.attempt(4,400_000_000,false),"new slot arms again");check(d.attempt(5,500_000_000,true),"new slot second confirms");
        check(!d.attempt(6,600_000_000,true),"rearm");check(!d.attempt(7,1_200_000_001L,true),"expired");d.clear();check(!d.attempt(8,1_210_000_000L,true),"reset protects");
        DurabilityLatch l=new DurabilityLatch();check(l.update("head","iron",9,100,10),"first low warning");check(!l.update("head","iron",8,100,10),"no repeat");check(!l.update("head","iron",12,100,10),"hysteresis");check(!l.update("head","iron",30,100,10),"repair resets");check(l.update("head","iron",10,100,10),"warn after repair");check(l.update("head","diamond",5,100,10),"different item warns");
        Path config=Files.createTempFile("luma-hud-",".properties");
        try{Settings s=new Settings();s.hud.style=2;s.hud.scale=1.4;s.hud.opacity=.6;s.hud.x[0]=.8;s.hud.visible[1]=false;s.hud.placed=true;s.dropProtection=true;s.saturationEnabled=true;s.saturation=.25;s.durabilityWarning=true;s.save(config);
            Settings v=Settings.load(config);check(v.hud.style==2&&v.hud.scale==1.4&&v.hud.opacity==.6&&v.hud.x[0]==.8&&!v.hud.visible[1]&&v.hud.placed,"HUD persists");check(v.dropProtection&&v.saturationEnabled&&v.saturation==.25&&v.durabilityWarning,"other features persist");
            v.reset();check(v.hud.style==2&&v.dropProtection&&v.saturationEnabled,"appearance reset not new features");
        }finally{Files.deleteIfExists(config);}
        for(int[] size:new int[][]{{640,360},{1280,720},{1920,1080},{3840,2160}})for(int style=0;style<3;style++)for(double scale:new double[]{.65,1,1.6}){
            HudConfig c=new HudConfig();c.style=style;c.scale=scale;HudLayout h=new HudLayout(c);hud(h,size[0],size[1],true,null);
            check(h.boxes().size()==9,"all widgets");for(HudLayout.Box b:h.boxes())check(b.x()>=0&&b.y()>=0&&b.x()+b.w()<=size[0]+.001&&b.y()+b.h()<=size[1]+.001,"bounds");
            var boxes=h.boxes();for(int i=0;i<boxes.size();i++)for(int j=i+1;j<boxes.size();j++){var a=boxes.get(i);var b=boxes.get(j);check(a.x()+a.w()<=b.x()||b.x()+b.w()<=a.x()||a.y()+a.h()<=b.y()||b.y()+b.h()<=a.y(),"default widgets do not overlap");}
            h.selectAll();check(h.allSelected(),"select all");var first=boxes.get(0);var second=boxes.get(1);double distance=second.x()-first.x(),distanceY=second.y()-first.y();check(h.click(first.x()+2,first.y()+2,false),"hit widget");h.move(10000,10000);hud(h,size[0],size[1],true,null);near(h.boxes().get(1).x()-h.boxes().get(0).x(),distance,"group relative X");near(h.boxes().get(1).y()-h.boxes().get(0).y(),distanceY,"group relative Y");h.stop();check(h.takeChanged(),"position dirty");
        }
        for(int[] wh:new int[][]{{640,360},{1280,720},{1920,1080}}){
            Settings s=new Settings();HudSettingsPanel p=new HudSettingsPanel(s);panel(p,wh[0],wh[1],null);
            for(String id:new String[]{"enabled","style1","style2","scale","opacity","nick","fps","ping","coords","speed","server","online","armor","tools","positions"}){
                p.reveal(id);panel(p,wh[0],wh[1],null);double[] xy=p.center(id);check(p.click(xy[0],xy[1],0),"HUD settings control "+id);p.release();
            }
        }
        Settings s=new Settings();s.motion=false;s.background=false;Menu m=new Menu(s);MenuChecks.render(m,Preview.font(),1280,720,null);
        double[] nav=m.controlCenter("nav5");check(m.click(nav[0],nav[1],0)&&m.takeHudRequested(),"HUD opens separate screen request");
        m.setTab(6);MenuChecks.render(m,Preview.font(),1280,720,null);for(String id:new String[]{"saturationEnabled","saturation","saturationReset"}){m.revealControl(id);MenuChecks.render(m,Preview.font(),1280,720,null);double[] xy=m.controlCenter(id);check(m.click(xy[0],xy[1],0),"visual control "+id);m.release();}
        m.setTab(2);MenuChecks.render(m,Preview.font(),1280,720,null);for(String id:new String[]{"dropProtection","toolSafety","durabilityWarning","toolSafetySettings","toolSafetyThreshold","durabilityThreshold"}){m.revealControl(id);MenuChecks.render(m,Preview.font(),1280,720,null);double[] xy=m.controlCenter(id);check(m.click(xy[0],xy[1],0),"safety control "+id);m.release();}
        for(int i=0;i<3;i++){HudConfig c=new HudConfig();c.style=i;hud(new HudLayout(c),1280,720,false,out.resolve("hud-style-"+i+".png"));}
        HudConfig small=new HudConfig();small.style=2;small.scale=1.6;hud(new HudLayout(small),640,360,true,out.resolve("hud-small.png"));
        HudSettingsPanel p=new HudSettingsPanel(new Settings());panel(p,1280,900,out.resolve("hud-settings.png"));p.reveal("armor");panel(p,1280,900,out.resolve("hud-settings-bottom.png"));panel(p,640,360,out.resolve("hud-settings-small.png"));
        s=new Settings();s.reduced=true;m=new Menu(s);m.setTab(6);MenuChecks.render(m,Preview.font(),1280,900,out.resolve("world-colour-settings.png"));
        m.setTab(2);MenuChecks.render(m,Preview.font(),1280,900,null);m.revealControl("toolSafety");MenuChecks.render(m,Preview.font(),1280,900,out.resolve("safety-settings.png"));
        System.out.println("PASS: "+n+" new HUD/safety/layout/settings assertions. No Minecraft or GL test.");
    }
}
