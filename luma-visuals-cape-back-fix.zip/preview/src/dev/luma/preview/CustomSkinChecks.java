package dev.luma.preview;

import dev.luma.core.Menu;
import dev.luma.core.Settings;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Runs the actual GUI hit regions and Settings IO, not a substitute skin/settings implementation. */
public final class CustomSkinChecks {
    private static int checks;
    private static void check(boolean value, String message) {
        checks++;
        if (!value) throw new AssertionError(message);
    }
    private static void draw(Menu menu, int w, int h, Path png) throws Exception {
        MenuChecks.render(menu, Preview.font(), w, h, png);
    }
    private static void click(Menu menu, String id) {
        double[] point = menu.controlCenter(id);
        check(menu.click(point[0], point[1], 0), "click " + id);
        menu.release();
    }
    public static void main(String[] args) throws Exception {
        Path output = Path.of(args.length > 0 ? args[0] : "preview/images");
        Files.createDirectories(output);
        Path config = Files.createTempFile("luma-custom-skin-", ".properties");
        try {
            for (int[] size : new int[][]{{640,360}, {800,600}, {1280,720}, {1920,1080}}) {
                for (double scale : new double[]{.85, 1, 1.75}) {
                    Settings settings = new Settings();
                    settings.motion = false;
                    settings.background = false;
                    settings.scale = scale;
                    settings.autoSprint = true;
                    settings.saturationEnabled = true;
                    settings.saturation = .75;
                    Menu menu = new Menu(settings);
                    draw(menu, size[0], size[1], null);
                    check(!menu.controlIds().contains("customSkinEnabled"), "not in appearance tab");
                    click(menu, "nav6");
                    draw(menu, size[0], size[1], null);
                    check(menu.tab() == 6, "existing Visuals navigation");
                    check(menu.controlIds().contains("customSkinEnabled"), "Custom Skin in Visuals");
                    check(menu.scrollOffset() == 0, "switch at top without scrolling");
                    check(!settings.customSkinEnabled, "default OFF");
                    click(menu, "customSkinEnabled");
                    check(settings.customSkinEnabled, "ON changes same Settings instance");
                    check(menu.takeChanged() && !menu.takeChanged(), "existing autosave signal consumed once");
                    settings.save(config);
                    Settings loaded = Settings.load(config);
                    check(loaded.customSkinEnabled, "ON persists after reload");
                    check(loaded.autoSprint && loaded.saturationEnabled && loaded.saturation == .75,
                        "other visual/utility settings preserved");
                    Menu reopened = new Menu(loaded);
                    reopened.setTab(6);
                    draw(reopened, size[0], size[1], null);
                    click(reopened, "customSkinEnabled");
                    check(!loaded.customSkinEnabled && reopened.takeChanged(), "OFF and autosave after reopen");
                    loaded.save(config);
                    check(!Settings.load(config).customSkinEnabled, "OFF persists after reload");
                    Properties stored = new Properties();
                    try (var reader = Files.newBufferedReader(config)) { stored.load(reader); }
                    check("false".equals(stored.getProperty("customSkinEnabled")), "same persisted key");
                    reopened.revealControl("saturationReset");
                    draw(reopened, size[0], size[1], null);
                    click(reopened, "saturationReset");
                    check(!loaded.saturationEnabled && loaded.saturation == 1, "existing reset remains reachable");
                }
            }
            Files.writeString(config, "theme=3\nautoSprint=true\n");
            Settings old = Settings.load(config);
            check(!old.customSkinEnabled && old.theme == 3 && old.autoSprint, "old configs migrate without reset");
            Files.writeString(config, "customSkinEnabled=invalid\n");
            check(!Settings.load(config).customSkinEnabled, "invalid value defaults OFF");
            Files.delete(config);
            check(!Settings.load(config).customSkinEnabled, "missing config defaults OFF");

            Settings settings = new Settings();
            settings.motion = false;
            settings.background = false;
            Menu menu = new Menu(settings);
            menu.setTab(6);
            draw(menu, 1280, 720, output.resolve("custom-skin-off.png"));
            click(menu, "customSkinEnabled");
            draw(menu, 1280, 720, output.resolve("custom-skin-on.png"));
            draw(menu, 640, 360, output.resolve("custom-skin-small.png"));
            // The existing focused-card keyboard path must toggle the same setting.
            check(menu.key(257, false, false), "Enter activates focused card");
            check(!settings.customSkinEnabled, "keyboard OFF");
            check(menu.takeChanged(), "keyboard autosave signal");
        } finally {
            Files.deleteIfExists(config);
        }
        System.out.println("PASS: " + checks + " Custom Skin GUI/config assertions. Shared Java core only; no Minecraft renderer execution.");
    }
}
