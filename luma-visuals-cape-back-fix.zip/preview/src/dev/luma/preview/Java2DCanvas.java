package dev.luma.preview;
import dev.luma.core.Canvas;
import dev.luma.core.UiFont;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.Map;

/** Software preview of the exact atlas/metrics, not a system-font approximation. */
public final class Java2DCanvas implements Canvas,AutoCloseable {
 private static final BufferedImage ATLAS=loadAtlas();
 private static final Map<Integer,BufferedImage> TINTS=new LinkedHashMap<>(16,.75f,true){protected boolean removeEldestEntry(Map.Entry<Integer,BufferedImage> e){return size()>8;}};
 private static BufferedImage loadAtlas(){try(var in=Java2DCanvas.class.getResourceAsStream("/assets/luma/textures/font/ui-atlas.png")){if(in==null)throw new IOException("UI atlas missing");return ImageIO.read(in);}catch(IOException e){throw new ExceptionInInitializerError(e);}}
 private static BufferedImage tint(int rgb){
  rgb&=0xFFFFFF;BufferedImage out=TINTS.get(rgb);if(out!=null)return out;
  out=new BufferedImage(ATLAS.getWidth(),ATLAS.getHeight(),BufferedImage.TYPE_INT_ARGB);Graphics2D gg=out.createGraphics();gg.drawImage(ATLAS,0,0,null);gg.setComposite(AlphaComposite.SrcIn);gg.setColor(new Color(rgb));gg.fillRect(0,0,out.getWidth(),out.getHeight());gg.dispose();TINTS.put(rgb,out);return out;
 }
 private Graphics2D g;private double alpha=1;
 private record Saved(Graphics2D g,double alpha){}
 private final ArrayDeque<Saved> saved=new ArrayDeque<>();
 public Java2DCanvas(Graphics2D g,Font unused){this.g=(Graphics2D)g.create();this.g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);}
 public void push(double x,double y,double s,double a){saved.push(new Saved(g,alpha));g=(Graphics2D)g.create();g.translate(x,y);g.scale(s,s);alpha*=a;}
 public void pop(){g.dispose();Saved old=saved.pop();g=old.g;alpha=old.alpha;}
 public void clip(double x,double y,double w,double h){push(0,0,1,1);g.clip(new Rectangle2D.Double(x,y,w,h));}
 public void unclip(){pop();}
 private void color(int c){g.setColor(new Color(c,true));g.setComposite(AlphaComposite.SrcOver.derive((float)Math.max(0,Math.min(1,alpha))));}
 public void rect(double x,double y,double w,double h,int col){color(col);g.fill(new Rectangle2D.Double(x,y,w,h));}
 public void gradient(double x,double y,double w,double h,int first,int last,boolean vertical){color(first);g.setPaint(new GradientPaint((float)x,(float)y,new Color(first,true),(float)(vertical?x:x+w),(float)(vertical?y+h:y),new Color(last,true)));g.fill(new Rectangle2D.Double(x,y,w,h));}
 public void round(double x,double y,double w,double h,double r,int col){color(col);g.fill(new RoundRectangle2D.Double(x,y,w,h,r*2,r*2));}
 public void line(double x,double y,double x2,double y2,double width,int col){color(col);g.setStroke(new BasicStroke((float)width,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND));g.draw(new Line2D.Double(x,y,x2,y2));}
 public void circle(double x,double y,double r,int col){color(col);g.fill(new Ellipse2D.Double(x-r,y-r,r*2,r*2));}
 public void glow(double x,double y,double r,int col,double strength){
  if(r<=0)return;float[] stops=new float[9];Color[] colors=new Color[9];
  for(int i=0;i<=8;i++){stops[i]=i/8f;colors[i]=new Color(Canvas.alpha(col,strength*.75*Math.pow(1-i/8.0,2)),true);}
  g.setComposite(AlphaComposite.SrcOver.derive((float)Math.max(0,Math.min(1,alpha))));g.setPaint(new RadialGradientPaint(new Point2D.Double(x,y),(float)r,stops,colors));g.fill(new Ellipse2D.Double(x-r,y-r,r*2,r*2));
 }
 public void text(String text,double x,double y,double size,int col){
  double cursor=x;BufferedImage atlas=tint(col);g.setComposite(AlphaComposite.SrcOver.derive((float)Math.max(0,Math.min(1,alpha*((col>>>24)/255.0)))));
  g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR);
  for(int i=0;i<text.length();){int cp=text.codePointAt(i);i+=Character.charCount(cp);UiFont.Glyph glyph=UiFont.glyph(cp,size*Math.sqrt(Math.abs(g.getTransform().getDeterminant())));double k=size/glyph.em();
   if(glyph.width()>0){BufferedImage cut=atlas.getSubimage(glyph.x(),glyph.y(),glyph.width(),glyph.height());AffineTransform tx=AffineTransform.getTranslateInstance(cursor+glyph.left()*k,y+size+glyph.top()*k);tx.scale(k,k);g.drawImage(cut,tx,null);}
   cursor+=UiFont.glyph(cp).advance()*size/UiFont.EM;
  }
 }
 public double textWidth(String text,double size){return UiFont.width(text,size);}
 public void close(){while(!saved.isEmpty())pop();g.dispose();}
}
