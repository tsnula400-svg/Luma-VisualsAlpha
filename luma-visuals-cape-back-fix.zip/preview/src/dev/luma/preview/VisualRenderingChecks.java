package dev.luma.preview;
import dev.luma.core.*;
import java.nio.file.*;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import javax.imageio.ImageIO;
/** Shared core only. No fake Fabric/Minecraft API stubs. */
public final class VisualRenderingChecks {
 private static int count;
 static void check(boolean ok,String why){count++;if(!ok)throw new AssertionError(why);}
 static void near(double a,double b,String why){check(Math.abs(a-b)<1e-7,why);}
 static class Probe implements Canvas {
  int stack,clips,primitives;
  void finite(double... v){for(double n:v)check(Double.isFinite(n),"finite geometry");}
  public void push(double x,double y,double s,double a){finite(x,y,s,a);check(s>0&&a>=0&&a<=1,"valid transform");stack++;}
  public void pop(){check(--stack>=0,"matrix scope");}public void clip(double x,double y,double w,double h){finite(x,y,w,h);check(w>=0&&h>=0,"clip size");clips++;}public void unclip(){check(--clips>=0,"scissor scope");}
  public void rect(double x,double y,double w,double h,int a){finite(x,y,w,h);primitives++;}public void round(double x,double y,double w,double h,double r,int a){finite(x,y,w,h,r);}public void line(double x,double y,double xx,double yy,double w,int a){finite(x,y,xx,yy,w);}public void circle(double x,double y,double r,int a){finite(x,y,r);}public void text(String s,double x,double y,double size,int a){finite(x,y,size);}public double textWidth(String s,double size){return UiFont.width(s,size);}
 }
 static void frame(Menu m,Probe p,int w,int h,double dt){m.render(p,w,h,-1000,-1000,dt);check(p.stack==0&&p.clips==0,"scopes restored");}
 static void click(Menu m,Probe p,String id,int w,int h){m.revealControl(id);frame(m,p,w,h,0);double[] xy=m.controlCenter(id);check(m.click(xy[0],xy[1],0),"click "+id);m.release();}
 public static void run()throws Exception{
  count=0;Settings s=new Settings();Path file=Files.createTempFile("lume-final-",".properties");
  try{s.saturation=0;s.customAccent=true;s.accentHue=.1;s.accentSaturation=.8;s.accentValue=.9;s.particleStyle=3;s.particleAmount=64;s.particleAccent=false;s.particleColor=0xAA9900;s.animationStyle=3;s.animationDuration=.5;s.viewModel.enabled=true;s.viewModel.main.preset(1);s.viewModel.off.preset(4);s.viewModel.swingStyle=5;s.viewModel.swingSpeed=1.4;s.viewModelPreview=true;s.previewSwing=true;s.save(file);Settings v=Settings.load(file);near(v.saturation,0,"zero saturation persists");check(v.accentColor()==s.accentColor(),"HSV roundtrip");check(v.particleStyle==3&&v.particleAmount==64&&!v.particleAccent&&v.particleColor==0xAA9900,"particles persist");near(v.animationDuration,.5,"duration persists");near(v.viewModel.main.scale,.75,"main pose");near(v.viewModel.off.vertical,.2,"off pose");near(v.viewModel.swingSpeed,1.4,"swing persists");check(!v.previewSwing&&!v.viewModelPreview,"runtime preview not saved");Files.writeString(file,"saturation=NaN\nanimationDuration=Infinity\nviewModel.main.scale=-5\nparticleAmount=99999\n");v=Settings.load(file);near(v.saturation,1,"invalid saturation fallback");near(v.animationDuration,.28,"duration fallback");near(v.viewModel.main.scale,.4,"scale clamped");check(v.particleAmount==64,"particle bound");}finally{Files.delete(file);}
  ViewModelConfig vm=new ViewModelConfig();SwingTransform t=new SwingTransform();for(int style=0;style<7;style++){vm.swingStyle=style;double previous=-1;for(int i=0;i<=1000;i++){double p=vm.progress(i/1000.0);check(Double.isFinite(p)&&p>=previous&&p>=0&&p<=1,"monotonic visual time");previous=p;t.evaluate(vm,p,1);check(Double.isFinite(t.pitch)&&t.scale>=1&&t.scale<=1.15,"finite swing");}near(vm.progress(0),0,"swing start");if(style!=6)near(vm.progress(1),1,"swing end");for(double p:new double[]{0,1}){t.evaluate(vm,p,-1);near(t.x,0,"position seam");near(t.roll,0,"rotation seam");near(t.scale,1,"scale seam");}}
  for(int style=0;style<4;style++){vm.equipStyle=style;near(vm.equip(0),0,"equip rest");for(int i=0;i<=100;i++)check(vm.equip(i/100.0)>=0&&vm.equip(i/100.0)<=1,"equip bounds");}
  for(int style=0;style<6;style++)for(int[] wh:new int[][]{{640,360},{1280,720},{2000,900}}){s=new Settings();s.background=false;s.animationStyle=style;Menu m=new Menu(s);Probe p=new Probe();for(int i=0;i<70;i++)frame(m,p,wh[0],wh[1],1.0/60);m.setTab(7);for(int i=0;i<70;i++)frame(m,p,wh[0],wh[1],1.0/60);for(String id:new String[]{"viewModelEnabled","viewModelHand","viewModelPreset","vmScale","vmTilt","equipStyle","previewSwing"})click(m,p,id,wh[0],wh[1]);frame(m,p,wh[0],wh[1],.02);check(s.viewModelPreview&&s.previewSwing,"preview enabled");m.requestClose();check(!s.viewModelPreview&&!s.previewSwing,"preview cleared");for(double dt:new double[]{Double.NaN,-1,Double.POSITIVE_INFINITY,0,.1})frame(m,p,wh[0],wh[1],dt);for(int i=0;i<70;i++)frame(m,p,wh[0],wh[1],1.0/60);check(m.closed(),"style closes");}
  s=new Settings();s.motion=false;Menu m=new Menu(s);Probe p=new Probe();m.setTab(4);frame(m,p,1280,720,0);click(m,p,"accentSV",1280,720);check(s.customAccent,"picker enables custom");near(s.accentSaturation,.5,"SV hit x");near(s.accentValue,.5,"SV hit y");m.key(265,false,false);check(s.accentValue>.5,"picker keyboard");m.requestClose();double before=s.accentSaturation;m.move(9999,9999);near(s.accentSaturation,before,"drag blocked on close");
  for(int style=0;style<5;style++){s=new Settings();s.particleStyle=style;s.particleAmount=64;s.efficientBackground=false;Probe q=new Probe();new MenuParticles().render(q,1280,720,s,.016,s.accentColor(),1);check(q.primitives<=(style==3?128:64),"particle primitive budget");}
  System.out.println("PASS: "+count+" visual/core assertions. NOT Minecraft, GL or MobileGlues.");
 }
 static void capture(String name,int tab,String reveal,int w,int h)throws Exception{
  Settings s=new Settings();s.theme=1;s.particleStyle=3;s.motion=false;Menu m=new Menu(s);m.setTab(tab);BufferedImage image=new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();for(int i=0;i<3;i++)try(Java2DCanvas c=new Java2DCanvas(g,Preview.font())){Preview.backdrop(g,w,h);m.render(c,w,h,-1000,-1000,.016);}if(reveal!=null)m.revealControl(reveal);try(Java2DCanvas c=new Java2DCanvas(g,Preview.font())){Preview.backdrop(g,w,h);m.render(c,w,h,-1000,-1000,.016);}g.dispose();Path dest=Path.of("verification/visual",name+".png");Files.createDirectories(dest.getParent());ImageIO.write(image,"png",dest.toFile());
 }
 public static void main(String[] args)throws Exception{run();if(args.length>0){capture("01-menu",0,null,1600,1000);capture("02-animation",0,"animationStyle",1600,1000);capture("03-particles",1,"particleStyle",1600,1000);capture("04-palette",4,"accentSV",1600,1000);capture("05-viewmodel",7,null,1600,1000);capture("06-swing",7,"swingSpeed",1600,1000);capture("07-compact",7,null,640,360);capture("08-saturation",6,null,1600,1000);}}
}
