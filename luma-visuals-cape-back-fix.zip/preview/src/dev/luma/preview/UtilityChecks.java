package dev.luma.preview;

import dev.luma.core.*;
import java.awt.Font;
import java.nio.file.*;

/** Executable pure-Java tests. Does NOT claim to validate Minecraft mixins, GL or network handling. */
public final class UtilityChecks {
    private static int checks;
    private static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    private static void near(double a,double b,String why){check(Math.abs(a-b)<.00001,why+": "+a+" vs "+b);}
    private static SmoothScroll scroll(){SmoothScroll s=new SmoothScroll();s.bounds(1000);return s;}
    private static double advance(int fps){SmoothScroll s=scroll();s.move(300,true);for(int i=0;i<fps/2;i++)s.update(1.0/fps,true);return s.value();}
    public static void main(String[] args)throws Exception{
        SmoothScroll s=scroll();s.move(54,true);check(s.value()==0&&s.target()==54,"wheel changes target, not displayed position");
        double prev=0;
        for(int i=0;i<80;i++){double v=s.update(1.0/60,true);check(v>=prev&&v<=54,"no overshoot or reverse drift");prev=v;}
        near(s.value(),54,"settles exactly");
        s.move(54,true);s.move(54,true);near(s.target(),162,"accumulate input against target");
        s.move(-1000,true);near(s.target(),0,"clamp top");s.update(.02,true);check(s.value()<54,"reverse movement");
        s.move(10000,true);near(s.target(),1000,"clamp bottom");s.bounds(20);check(s.value()<=20&&s.target()==20,"resize bounds");
        s.bounds(0);check(s.value()==0&&s.target()==0,"no overflow content");
        s=scroll();s.move(.25*54,true);near(s.target(),13.5,"fractional input");s.move(Double.NaN,true);near(s.target(),13.5,"ignore NaN input");
        s.update(Double.NaN,true);check(Double.isFinite(s.value()),"NaN time safe");
        s.move(20,false);near(s.value(),s.target(),"reduced motion immediate");
        s.move(20,true);s.update(.1,false);near(s.value(),s.target(),"disable smooth while settling");
        s.jump(0);s.move(100,true);s.update(0,true);near(s.value(),0,"zero delta time");
        s.update(-1,true);near(s.value(),0,"negative delta time");
        near(advance(30),advance(60),"30 vs 60 fps");near(advance(60),advance(144),"60 vs 144 fps");

        DragTransfer gesture=new DragTransfer();Object chest=new Object(),player=new Object();
        check(!gesture.visit(0,chest),"inactive cannot move");gesture.begin(chest);
        check(gesture.visit(0,chest),"first move");check(!gesture.visit(0,chest),"no duplicate move");
        check(!gesture.visit(1,player),"do not move items back from destination");check(gesture.visit(1,chest),"next source slot");
        check(!gesture.visit(-1,chest),"no outside click");gesture.end();check(!gesture.active()&&!gesture.visit(2,chest),"release stops");
        gesture.begin(chest);check(gesture.visit(0,chest),"new drag permits same slot");gesture.end();

        Settings settings=new Settings();settings.ratioEnabled=true;
        near(RatioPresets.desiredAspect(settings,16.0/9),4.0/3,"default 4:3");
        near(RatioPresets.projectionMultiplier(16.0/9,4.0/3),4.0/3,"wider world objects on wide screen");
        settings.aspectPreset=0;near(RatioPresets.desiredAspect(settings,20.0/9),20.0/9,"native aspect");
        settings.ratioMode=1;near(RatioPresets.desiredAspect(settings,20.0/9),20.0/9,"native aspect also in resolution mode");
        for(int i=0;i<RatioPresets.RESOLUTION_COUNT;i++){check(RatioPresets.width(i)>0&&RatioPresets.height(i)>0,"valid resolution");}
        settings.ratioEnabled=false;near(RatioPresets.desiredAspect(settings,20.0/9),20.0/9,"disabled native");
        settings.ratioEnabled=true;settings.autoSprint=true;settings.itemScroller=true;settings.smoothScroll=false;settings.ratioMode=1;settings.resolutionPreset=4;settings.aspectPreset=3;
        Path file=Files.createTempFile("luma-utilities-",".properties");
        try{
            settings.save(file);Settings loaded=Settings.load(file);
            check(loaded.ratioEnabled&&loaded.autoSprint&&loaded.itemScroller&&!loaded.smoothScroll,"utility settings round-trip");
            check(loaded.ratioMode==1&&loaded.resolutionPreset==4&&loaded.aspectPreset==3,"presets round-trip");
            loaded.reset();check(loaded.autoSprint&&loaded.itemScroller&&loaded.ratioEnabled,"reset appearance preserves utilities");
            check(loaded.smoothScroll,"appearance reset restores smooth scrolling");
            Files.writeString(file,"theme=3\nscale=1.25\n");loaded=Settings.load(file);
            check(loaded.theme==3&&loaded.scale==1.25&&loaded.smoothScroll,"old config migrates");
            check(!loaded.autoSprint&&!loaded.itemScroller&&!loaded.ratioEnabled,"new utilities opt-in");
            Files.writeString(file,"ratioMode=-4\naspectPreset=100\nresolutionPreset=999\n");loaded=Settings.load(file);
            check(loaded.ratioMode==0&&loaded.aspectPreset==RatioPresets.ASPECT_COUNT-1&&loaded.resolutionPreset==RatioPresets.RESOLUTION_COUNT-1,"invalid presets bounded");
        }finally{Files.deleteIfExists(file);}

        Font f=Preview.font();Path out=Path.of(args.length>0?args[0]:"preview/images");Files.createDirectories(out);
        int[][] windows={{640,360},{800,600},{1280,720},{1920,1080}};
        for(int[] wh:windows)for(double scale:new double[]{.85,1,1.75}){
            Settings st=new Settings();st.background=false;st.scale=scale;Menu m=new Menu(st);m.setTab(2);
            for(int i=0;i<8;i++)MenuChecks.render(m,f,wh[0],wh[1],null);
            for(String id:new String[]{"autoSprint","itemScroller","ratioEnabled","ratioMode","aspectPreset","resolutionPreset","ratioReset"}){
                m.revealControl(id);MenuChecks.render(m,f,wh[0],wh[1],null);
                double[] pos=m.controlCenter(id);check(m.click(pos[0],pos[1],0),"reachable utility "+id);m.release();
            }
            check(st.autoSprint&&st.itemScroller&&!st.ratioEnabled,"toggles and native reset");
            check(st.ratioMode==1&&st.aspectPreset==2&&st.resolutionPreset==3,"cycle selectors");
            m.setTab(0);for(int frame=0;frame<10;frame++)MenuChecks.render(m,f,wh[0],wh[1],null);
            m.key(267,false,false);check(m.scrollOffset()==0&&m.scrollTarget()>0,"PageDown animated");
            MenuChecks.render(m,f,wh[0],wh[1],null);check(m.scrollOffset()>0&&m.scrollOffset()<m.scrollTarget(),"animated intermediate frame");
            m.setTab(1);for(int frame=0;frame<10;frame++)MenuChecks.render(m,f,wh[0],wh[1],null);check(m.scrollOffset()==0&&m.scrollTarget()==0,"tab switch cancels old momentum");
            m.key(267,false,false);MenuChecks.render(m,f,wh[0],wh[1],null);
            m.key(70,true,false);m.character('я');MenuChecks.render(m,f,wh[0],wh[1],null);check(m.scrollOffset()==0,"search resets target and position");
        }
        // Click a visibly moving card using the actual rendered hit map.
        Settings st=new Settings();st.background=false;Menu m=new Menu(st);
        for(int i=0;i<8;i++)MenuChecks.render(m,f,1280,720,null);
        double[] pointer=m.controlCenter("smoothScroll");
        check(m.scroll(pointer[0],pointer[1],-1),"wheel inside viewport");
        MenuChecks.render(m,f,1280,720,null);pointer=m.controlCenter("smoothScroll");
        check(m.click(pointer[0],pointer[1],0)&&!st.smoothScroll,"hit map follows moving card");m.release();
        MenuChecks.render(m,f,1280,720,null);check(m.scrollOffset()==m.scrollTarget(),"click arrests residual movement");
        // New visual states: same shared Menu.java; these are NOT in-game screenshots.
        Settings vs=new Settings();vs.reduced=true;vs.autoSprint=vs.itemScroller=vs.ratioEnabled=true;
        Menu vm=new Menu(vs);vm.setTab(2);MenuChecks.render(vm,f,1600,1060,out.resolve("13-utilities.png"));
        vm.revealControl("ratioMode");MenuChecks.render(vm,f,1600,1060,out.resolve("14-ratio-settings.png"));
        vs.ratioMode=1;vs.resolutionPreset=2;vs.ratioStatus="Мир 1024×768 · HUD 1600×1060";
        MenuChecks.render(vm,f,1600,1060,out.resolve("15-ratio-resolution.png"));
        vs.scale=1.75;MenuChecks.render(vm,f,640,360,null);vm.revealControl("resolutionPreset");
        MenuChecks.render(vm,f,640,360,out.resolve("16-ratio-small.png"));
        System.out.println("PASS: "+checks+" utility/scroll assertions. Core/UI only, NOT Fabric/GL integration tests.");
    }
}
