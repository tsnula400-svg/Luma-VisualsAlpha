package dev.luma.preview;
import dev.luma.core.*;
import dev.luma.core.Menu;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;

/** Standalone preview of the shared menu logic, NOT a Minecraft build. */
public final class Preview extends JPanel {
    private final Menu menu;private final Font font;
    private final Path config=Path.of(System.getProperty("user.home"),".luma-preview.properties");
    private int mx=-1000,my=-1000;private long frameTime=System.nanoTime(),saveAt;
    public Preview(Settings settings,Font font){
        this.menu=new Menu(settings);this.font=font;setPreferredSize(new Dimension(1440,960));setMinimumSize(new Dimension(640,480));setFocusable(true);
        MouseAdapter pointer=new MouseAdapter(){
            public void mouseMoved(MouseEvent e){mx=e.getX();my=e.getY();menu.move(mx,my);}
            public void mouseDragged(MouseEvent e){mouseMoved(e);}
            public void mousePressed(MouseEvent e){requestFocusInWindow();menu.click(e.getX(),e.getY(),e.getButton()-1);}
            public void mouseReleased(MouseEvent e){menu.release();}
        };addMouseListener(pointer);addMouseMotionListener(pointer);
        addMouseWheelListener(e->menu.scroll(e.getX(),e.getY(),-e.getPreciseWheelRotation()));
        setFocusTraversalKeysEnabled(false);
        addKeyListener(new KeyAdapter(){
            public void keyPressed(KeyEvent e){int code=switch(e.getKeyCode()){
                case KeyEvent.VK_ESCAPE->256;case KeyEvent.VK_TAB->258;case KeyEvent.VK_ENTER->257;
                case KeyEvent.VK_PAGE_UP->266;case KeyEvent.VK_PAGE_DOWN->267;case KeyEvent.VK_BACK_SPACE->259;case KeyEvent.VK_LEFT->263;case KeyEvent.VK_RIGHT->262;default->e.getKeyCode();};
                if(e.getKeyCode()==KeyEvent.VK_SHIFT&&e.getKeyLocation()==KeyEvent.KEY_LOCATION_RIGHT)menu.requestClose();else menu.key(code,e.isControlDown(),e.isShiftDown());
            }
            public void keyTyped(KeyEvent e){if(!e.isControlDown())menu.character(e.getKeyChar());}
        });
        new javax.swing.Timer(16,e->{
            if(menu.closed()){save();Window w=SwingUtilities.getWindowAncestor(this);if(w!=null)w.dispose();((javax.swing.Timer)e.getSource()).stop();return;}
            if(menu.takeChanged())saveAt=System.currentTimeMillis()+350;
            if(saveAt>0&&System.currentTimeMillis()>saveAt){saveAt=0;save();}
            repaint();
        }).start();
    }
    void save(){try{menu.settings.save(config);menu.saved();}catch(IOException e){menu.saveError();}}
    protected void paintComponent(Graphics graphics){super.paintComponent(graphics);Graphics2D g=(Graphics2D)graphics;
        backdrop(g,getWidth(),getHeight());long now=System.nanoTime();double dt=(now-frameTime)/1e9;frameTime=now;
        try(Java2DCanvas c=new Java2DCanvas(g,font)){menu.render(c,getWidth(),getHeight(),mx,my,dt);}
    }
    static void backdrop(Graphics2D g,int w,int h){
        g.setPaint(new GradientPaint(0,0,new Color(0x242A40),w,h,new Color(0x0C1020)));g.fillRect(0,0,w,h);
    }
    static Font font() throws Exception {
        try(InputStream in=Preview.class.getResourceAsStream("/assets/luma/font/ui.ttf")){
            if(in==null)throw new IOException("Bundled font missing");return Font.createFont(Font.TRUETYPE_FONT,in);
        }
    }
    public static void main(String[] args)throws Exception{
        Font f=font();
        if(args.length>0&&args[0].equals("--render")){renderSnapshots(f,Path.of(args.length>1?args[1]:"preview-images"));return;}
        Settings settings;
        try{settings=Settings.load(Path.of(System.getProperty("user.home"),".luma-preview.properties"));}catch(Exception e){settings=new Settings();}
        Settings finalSettings=settings;
        SwingUtilities.invokeLater(()->{
            JFrame frame=new JFrame("Luma — standalone UI preview / not Minecraft");Preview p=new Preview(finalSettings,f);
            frame.setContentPane(p);frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            frame.addWindowListener(new WindowAdapter(){public void windowClosing(WindowEvent e){p.save();}});
            frame.pack();frame.setMinimumSize(new Dimension(660,520));frame.setLocationRelativeTo(null);frame.setVisible(true);p.requestFocusInWindow();
        });
    }
    static void renderSnapshots(Font f,Path dir)throws Exception{
        Files.createDirectories(dir);
        capture(f,dir.resolve("01-interface.png"),0,0,true,false,1600,1060,1);
        capture(f,dir.resolve("02-background-rose.png"),1,1,true,false,1600,1060,1);
        capture(f,dir.resolve("03-compact.png"),0,0,true,false,800,600,1.25);
    }
    static void capture(Font f,Path dest,int tab,int theme,boolean bg,boolean reduced,int w,int h,double scale)throws Exception{capture(f,dest,tab,theme,bg,reduced,w,h,scale,null);}
    static void capture(Font f,Path dest,int tab,int theme,boolean bg,boolean reduced,int w,int h,double scale,String query)throws Exception{
        Settings s=new Settings();s.theme=theme;s.background=bg;s.reduced=reduced;s.scale=scale;Menu m=new Menu(s);m.setTab(tab);
        BufferedImage img=new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);Graphics2D g=img.createGraphics();
        // Advance without rendering into the image so a clean frame is captured once.
        for(int i=0;i<15;i++)try(Java2DCanvas c=new Java2DCanvas(g,f)){backdrop(g,w,h);m.render(c,w,h,-1000,-1000,.1);}
        if(query!=null){m.key(70,true,false);for(char ch:query.toCharArray())m.character(ch);}
        double[] pointer=m.controlCenter("nav"+tab);
        backdrop(g,w,h);try(Java2DCanvas c=new Java2DCanvas(g,f)){m.render(c,w,h,pointer[0],pointer[1],1.0/60);}
        g.dispose();ImageIO.write(img,"png",dest.toFile());
    }
}
