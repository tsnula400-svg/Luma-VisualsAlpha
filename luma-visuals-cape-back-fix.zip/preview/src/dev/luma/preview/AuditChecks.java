package dev.luma.preview;
import dev.luma.core.*;
import java.nio.file.*;
import java.util.*;

/** Execute real UI hit handlers and core draw calls; NOT Minecraft or GL. */
public final class AuditChecks {
 static int checks;
 static void ok(boolean value,String label){checks++;if(!value)throw new AssertionError(label);}
 static void near(double a,double b,String label){ok(Math.abs(a-b)<1e-6,label+" got "+a+" expected "+b);}
 static final class Probe implements Canvas {
  int dots,rects; double lastX,lastY; List<String> labels=new ArrayList<>();
  public void push(double x,double y,double s,double a){} public void pop(){}
  public void clip(double x,double y,double w,double h){} public void unclip(){}
  public void rect(double x,double y,double w,double h,int c){rects++;lastX=x;lastY=y;}
  public void round(double x,double y,double w,double h,double radius,int c){}
  public void line(double x,double y,double a,double b,double w,int c){}
  public void circle(double x,double y,double radius,int c){dots++;lastX=x;lastY=y;}
  public void text(String text,double x,double y,double size,int c){labels.add(text);}
  public double textWidth(String text,double size){return UiFont.width(text,size);}
 }
 static final int W=1280,H=720;
 static void frame(Menu m,Probe p){m.render(p,W,H,-100,-100,1.0/60);}
 static void focus(Menu m,Probe p,String id){frame(m,p);m.revealControl(id);frame(m,p);}
 static void click(Menu m,Probe p,String id){focus(m,p,id);double[] xy=m.controlCenter(id);ok(m.click(xy[0],xy[1],0),"UI click "+id);m.release();}
 static void slider(Menu m,Probe p,String id,double fraction){
  click(m,p,id); // Click centre then use real keyboard handler, 2.5% per press.
  for(int i=0;i<45;i++)ok(m.key(263,false,false),"slider left "+id);
  int steps=(int)Math.round(fraction/.025);
  for(int i=0;i<steps;i++)ok(m.key(262,false,false),"slider right "+id);
 }
 public static void main(String[] args)throws Exception {
  Settings s=new Settings();s.motion=false;s.background=false;Menu m=new Menu(s);Probe p=new Probe();m.setTab(6);
  Path tmp=Files.createTempFile("luma-audit-", ".properties");
  try{
   // Exact 0/50/100/150 through drag coordinates discovered from live UI centres.
   focus(m,p,"saturation");double[] center=m.controlCenter("saturation");
   // Infer slider screen width from its real geometry via endpoint drags and centre.
   for(double amount:new double[]{0,.5,1,1.5}){
    focus(m,p,"saturation");center=m.controlCenter("saturation");
    ok(m.click(center[0],center[1],0),"saturation press");
    m.move(-10000,center[1]);near(s.saturation,0,"left clamp");
    // Binary search screen coordinate using actual on-drag value, not duplicated layout constants.
    double lo=-10000,hi=10000;
    for(int i=0;i<55;i++){double x=(lo+hi)/2;m.move(x,center[1]);if(s.saturation<amount)lo=x;else hi=x;}
    m.move((lo+hi)/2,center[1]);m.release();near(s.saturation,amount,"UI saturation "+amount);
    ok(s.saturationEnabled&&m.takeChanged(),"saturation enables and marks dirty");
    s.save(tmp);Settings saved=Settings.load(tmp);near(saved.saturation,amount,"persist saturation");ok(saved.saturationEnabled,"persist enabled");
   }
   click(m,p,"saturationReset");near(s.saturation,1,"reset 100");ok(!s.saturationEnabled,"reset bypass");
   m.setTab(7);click(m,p,"viewModelEnabled");ok(s.viewModel.enabled,"VM UI enabled");
   for(int hand=0;hand<2;hand++){
    if(hand==1)click(m,p,"viewModelHand");
    var pose=hand==0?s.viewModel.main:s.viewModel.off;
    slider(m,p,"vmHorizontal",hand==0?1:0);near(pose.horizontal,hand==0?.8:-.8,"horizontal");
    slider(m,p,"vmVertical",1);near(pose.vertical,.8,"vertical");
    slider(m,p,"vmDistance",0);near(pose.distance,-.8,"closer");
    slider(m,p,"vmScale",1);near(pose.scale,1.6,"scale");
    slider(m,p,"vmTilt",1);near(pose.tilt,90,"tilt");
    slider(m,p,"vmYaw",0);near(pose.yaw,-90,"yaw");
    slider(m,p,"vmPitch",1);near(pose.pitch,90,"pitch");
    ok(pose.preset==5,"editing selects Custom");
   }
   near(s.viewModel.main.horizontal,.8,"off edits do not overwrite main");
   s.save(tmp);Settings saved=Settings.load(tmp);
   near(saved.viewModel.main.horizontal,.8,"main persists");near(saved.viewModel.off.horizontal,-.8,"off persists");
   for(int hand=0;hand<2;hand++){
    var pose=hand==0?s.viewModel.main:s.viewModel.off;
    for(int preset=0;preset<5;preset++){pose.preset(preset);pose.validate();ok(pose.preset==preset,"preset index");}
   }
   // Swing Animation has no separate UI item any more; the system, all styles and persistence must still work.
   frame(m,p);ok(!m.controlIds().contains("swingStyle"),"swing item removed from UI");
   SwingTransform swing=new SwingTransform();
   for(int style=0;style<7;style++){s.viewModel.swingStyle=style;swing.evaluate(s.viewModel,s.viewModel.progress(.5),1);ok(Double.isFinite(swing.pitch)&&swing.scale>=1,"swing style "+style+" still evaluates");}
   s.viewModel.swingStyle=5;s.save(tmp);ok(Settings.load(tmp).viewModel.swingStyle==5,"swing style persists without UI item");
   for(int i=1;i<=4;i++){click(m,p,"equipStyle");ok(s.viewModel.equipStyle==i%4,"equip choice wired");}
   m.setTab(0);click(m,p,"animationStyle");ok(s.animationStyle==1,"animation UI");
   m.setTab(1);click(m,p,"particleStyle");ok(s.particleStyle==1,"particles UI");
   m.setTab(4);click(m,p,"accentSV");ok(s.customAccent,"picker runtime");s.save(tmp);ok(Settings.load(tmp).accentColor()==s.accentColor(),"picker persists");
   click(m,p,"nav5");ok(m.takeHudRequested(),"HUD route requested");
   p.labels.clear();frame(m,p);ok(p.labels.stream().anyMatch(x->x.startsWith("LV ")),"visible build marker");
  }finally{Files.delete(tmp);}
  // Assert nonzero draw output, not merely <= budget as in legacy particle tests.
  for(int style=0;style<5;style++){
   s=new Settings();s.particleStyle=style;s.particleAmount=24;Probe q=new Probe();MenuParticles particles=new MenuParticles();
   particles.render(q,W,H,s,.016,s.accentColor(),1);int drawn=q.dots+q.rects;
   ok(style==0?drawn==0:drawn==(style==3?48:24),"particle output count style "+style);
   double x=q.lastX,y=q.lastY;particles.render(q,W,H,s,.04,s.accentColor(),1);
   if(style!=0)ok(x!=q.lastX||y!=q.lastY,"particles actually move");
   s.reduced=true;x=q.lastX;y=q.lastY;particles.render(q,W,H,s,.04,s.accentColor(),1);
   near(q.lastX,x,"reduced particles x");near(q.lastY,y,"reduced particles y");
  }
  s=new Settings();s.background=false;m=new Menu(s);p=new Probe();frame(m,p);double opened=m.openness();frame(m,p);ok(m.openness()>opened&&m.openness()<1,"opening changes frame transform");
  s.animationStyle=5;frame(m,p);near(m.openness(),1,"Off immediate");m.requestClose();frame(m,p);ok(m.closed(),"Off close");
  System.out.println("PASS: "+checks+" audit assertions: actual UI handlers, persistence, particle draw/motion, build label. NOT Minecraft/GL/MobileGlues.");
 }
}
