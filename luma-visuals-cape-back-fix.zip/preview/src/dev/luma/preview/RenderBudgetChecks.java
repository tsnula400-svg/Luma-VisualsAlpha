package dev.luma.preview;
import dev.luma.core.*;
public final class RenderBudgetChecks {
 private static final class Counter implements Canvas {
  int dots,lines,depth,clips;
  public void push(double x,double y,double s,double a){depth++;}public void pop(){depth--;}
  public void clip(double x,double y,double w,double h){if(w<=0||h<=0)throw new AssertionError();clips++;}public void unclip(){clips--;}
  public void rect(double x,double y,double w,double h,int c){}public void round(double x,double y,double w,double h,double r,int c){}public void circle(double x,double y,double r,int c){}
  public void line(double x,double y,double a,double b,double w,int c){lines++;}public void dot(double x,double y,double r,int c){dots++;}public void glow(double x,double y,double r,int c,double s){}
  public void text(String s,double x,double y,double size,int c){}public double textWidth(String s,double size){return UiFont.width(s,size);}
 }
 private static Counter frame(Settings s,int w,int h){Counter c=new Counter();new Menu(s).render(c,w,h,0,0,.1);if(c.depth!=0||c.clips!=0)throw new AssertionError("scope leak");return c;}
 public static void main(String[] args)throws Exception {
  for(int[] wh:new int[][]{{640,360},{1280,720},{1920,1080},{3840,2160},{7680,4320}}){
   Settings s=new Settings();s.reduced=true;s.dots=s.scanlines=true;Counter a=frame(s,wh[0],wh[1]);if(a.dots>900)throw new AssertionError("lite budget");
   s.efficientBackground=false;Counter b=frame(s,wh[0],wh[1]);if(b.dots>1800||a.lines>=b.lines)throw new AssertionError("full budget");
   s.background=false;if(frame(s,wh[0],wh[1]).dots!=0)throw new AssertionError("disabled background");
  }
  for(int c=0x410;c<=0x44F;c++)if(UiFont.glyph(c)==UiFont.glyph('?'))throw new AssertionError("Cyrillic missing");
  if(UiFont.width("Тест",32)!=2*UiFont.width("Тест",16))throw new AssertionError("font scaling");
  java.nio.file.Path p=java.nio.file.Files.createTempFile("luma-check-",".properties");
  try {java.nio.file.Files.writeString(p,"scale=1.25\ntheme=3\n");Settings s=Settings.load(p);if(!s.efficientBackground||s.scale!=1.25||s.theme!=3)throw new AssertionError("migration");s.efficientBackground=false;s.save(p);if(Settings.load(p).efficientBackground)throw new AssertionError("persistence");}finally{java.nio.file.Files.deleteIfExists(p);}
  System.out.println("PASS: background budgets at 5 resolutions, font metrics, Cyrillic, config migration/persistence. Not FPS measurements.");
 }
}
