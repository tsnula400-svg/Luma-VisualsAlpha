# LUMA VISUALS — InputFix, 2026-09-08

## Изменения
Точечная правка существующего Alpha-проекта 0.1.5, без новых систем и изменений gameplay.

- Menu.java: закрытие прекращает drag и очищает фокус; keyboard/character/move не меняют закрывающееся меню.
- Menu.java: смена вкладки инвалидирует старые hit regions до следующего render.
- Menu.java: нечисловой или бесконечный frame delta заменяется нулём, чтобы не разрушать animation/transform state. Отрицательные и большие конечные значения по-прежнему ограничиваются.
- HudSettingsPanel.java: close освобождает drag, кнопка «Назад» использует тот же путь; закрытая панель игнорирует клики/движение/scroll. Scroll также игнорируется во время drag и при нечисловом значении.
- MenuChecks.java: шесть воспроизводимых регрессий встроены в существующий набор тестов. Дополнительный запуск только этих проверок: MenuChecks --input-regression.

## Реальная проверка
STATIC / OFFLINE VERIFICATION:
- Java core и все preview/src скомпилированы компилятором JDK 25 с --release 21 (не запуск на JDK 21).
- До правок все шесть новых сценариев падали; после правок проходят.
- MenuChecks: 532 assertions + 6 новых сценариев, 24 сочетания разрешения/масштаба.
- RenderBudgetChecks: существующие проверки бюджета, шрифта и конфигурации — PASS (не измерения FPS).
- UtilityChecks: 283; ToolSafetyChecks: 5013; NewFeatureChecks: 1909; RevisionChecks: 74; CustomSkinChecks: 211 — PASS.
- validate_mobilefix.py: 81693 static/math assertions — PASS.
- recording_check.py: 5248 assertions на recording doubles, 377 cuboids, 11 poses + pulse — PASS. Это НЕ проверка настоящего Minecraft API/OpenGL.
- Логи до/после и полного прогона: verification/input-fix/.

IN-GAME VERIFICATION: NOT RUN.
Fabric/Gradle build: NOT RUN — Gradle отсутствует в доступной среде; готовый mod JAR не создан.
Minecraft, shader compilation, OpenGL state, FPS, Android/Zalith/MobileGlues runtime не проверялись.

## Проверить на устройстве после сборки
1. Открыть меню, начать drag слайдера, закрыть через Escape/клавишу меню и продолжить движение: значение после запроса закрытия не должно изменяться.
2. При closing transition проверить Ctrl+0 и остальные клавиши: настройки не меняются.
3. Быстро переключать вкладки и нажимать по прежним позициям контролов: старая вкладка не реагирует.
4. Открыть HUD settings, проверить drag, release, прокрутку, «Назад», повторное открытие и сохранение настроек после перезапуска.
5. Повторить при разных GUI scale, ориентации/разрешении окна и motion/reduced settings.

## Сборка и CI
Оба исходных build.yml (workflow внутри проекта и отдельный файл рядом с проектом) НЕ изменены.
Существующий workflow отдаёт приоритет старому LumaVisuals-0.1.5-Katana-Prism-MobileFix.zip перед распакованными исходниками. Для сборки InputFix распаковать новый архив и заменить LumaVisuals/ (либо содержимое проекта в корне), а старый приоритетный MobileFix ZIP убрать из репозитория. Простая загрузка нового архива под новым именем не гарантирует сборку новых исходников.
Не добавлять второй workflow. Новый JAR нужно получить существующим CI/Gradle и затем проверить в игре.

## Полные актуальные файлы
Находятся по прежним путям в этом архиве. Изменения относительно исходного вложения: verification/input-fix/changes.diff. Исходный архив в заметке Notion сохранён отдельно.
Исторические MOBILEFIX/PRISM документы не переименованы и не выдаются за новую проверку. Актуальные результаты этого патча — здесь и в PACKAGE_VERIFICATION.txt.
