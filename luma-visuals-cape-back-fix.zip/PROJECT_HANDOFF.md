# Передача результатов аудита — НЕ финальный релиз

Актуальный отчёт: AUDIT_REPORT_RU.md. Порядок GitHub: BUILD_FROM_PHONE.md.
Исправлен прежний workflow; добавлены источник/версия сборки и проверки. Архитектура, config, ресурсы и render-пути сохранены.

Fabric JAR: NOT BUILT. Minecraft + Zalith + MobileGlues: NOT RUN.
Нет подтверждения, что C — единственная причина прежнего запуска.

Исторические отчёты/preview относятся к прежним этапам, не подтверждают текущую сборку. Свежие логи только в audit/current/; baseline — audit/baseline/.
