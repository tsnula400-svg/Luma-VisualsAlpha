#!/usr/bin/env python3
"""Static/math regressions only. Does not compile or launch Minecraft/Gradle."""
from pathlib import Path
import json, math, re, struct
R=Path(__file__).resolve().parents[1]
checks=0

def check(ok, message):
    global checks
    checks+=1
    if not ok: raise AssertionError(message)

g=json.loads((R/'tools/custom_skin_v2/geometry.json').read_text())
parts={p['name']:p for p in g['parts']}
check(len(parts)==len(g['parts']), 'unique model parts')
check(sum(len(p['boxes']) for p in parts.values())<420, 'bounded local model budget')
for p in parts.values():
    check(p['parent'] is None or p['parent'] in parts, 'parent exists')
    for b in p['boxes']:
        w,h,d=b['size'];u,v=b['uv']
        check(min(w,h,d)>0, 'positive geometry')
        check(u>=0 and v>=0 and u+2*w+2*d<=256 and v+h+d<=256, 'UV inside atlas')
check(len(g['segments'])==18, 'curved blade sections')
check(parts['katana_grip']['pivot']==[4.4,-3.0,5.8], 'original mount retained')
check(parts['katana_grip']['rot']==[0,0,.58], 'original mount angle retained')
for name in ('blade_energy','streak_grip','sparks_grip'):
    check(parts[name]['pivot']==parts['katana_grip']['pivot'], 'emission mount matches')
    check(parts[name]['rot']==parts['katana_grip']['rot'], 'emission angle matches')
check(parts['left_iris']['pivot'][0]>0 and parts['right_iris']['pivot'][0]<0, 'anatomical eye sides')
for name,size in [('custom_skin.png',(64,64)),('custom_skin_parts.png',(256,256)),('custom_skin_glow.png',(256,256))]:
    data=(R/'src/main/resources/assets/luma/textures/entity'/name).read_bytes()
    check(data[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack('>II',data[16:24])==size, 'PNG dimensions')
model=(R/'src/main/java/dev/luma/client/skin/CustomSkinModel.java').read_text()
check(set(re.findall(r'addChild\("([^"]+)"',model))==set(parts), 'Java/geometry part names match')
check(model.count('.cuboid(')==sum(len(p['boxes']) for p in parts.values()), 'Java/geometry counts match')
mixins=json.loads((R/'src/main/resources/luma.mixins.json').read_text())['client']
check('WindowMixin' not in mixins and 'MinecraftClientMixin' not in mixins, 'no partial target/dimension substitution')
for name in mixins:
    check((R/f'src/main/java/dev/luma/client/mixin/{name}.java').is_file(), 'registered mixin exists')
ratio=(R/'src/main/java/dev/luma/core/RatioPresets.java').read_text()
check('if(s.ratioMode==1)' not in ratio, 'aspect no longer overridden by resolution mode')
world=(R/'src/main/java/dev/luma/client/WorldResolution.java').read_text()
check('super(false)' in world and 'GL_DEPTH_BUFFER_BIT' not in world, 'image sampling never resizes/blits depth')
check('activeTarget' not in world, 'no target substitution')
shader=(R/'src/main/resources/assets/luma/shaders/core/saturation.fsh').read_text()
check('LumeSaturation' in shader and '0.2126,0.7152,0.0722' in shader,'luma shader uniform')
check('pow(' not in re.sub(r'//[^\n]*','',shader).split('void main()')[1],'no gamma roundtrip')
def transform(rgb,amount):
    l=sum(v*w for v,w in zip(rgb,(.2126,.7152,.0722)));c=[v-l for v in rgb]
    gain=min(amount,(1-l)/max(max(c),.00001),l/max(-min(c),.00001))
    return rgb if amount==1 else tuple(max(0,min(1,l+v*gain)) for v in c)
for r in range(0,256,17):
 for green in range(0,256,17):
  for b in range(0,256,17):
   rgb=tuple(x/255 for x in (r,green,b));previous=-1;l=sum(v*w for v,w in zip(rgb,(.2126,.7152,.0722)))
   for amount in (0,.5,1,1.5):
    out=transform(rgb,amount);chroma=max(out)-min(out)
    check(all(-1e-6<=v<=1+1e-6 for v in out),'in gamut')
    check(abs(sum(v*w for v,w in zip(out,(.2126,.7152,.0722)))-l)<1e-6,'display luma preserved')
    check(chroma>=previous-1e-6,'monotonic chroma')
    if amount==0:check(chroma<1e-6,'0% grayscale')
    if amount==1:check(out==rgb,'100% identity')
    previous=chroma
def pulse(t):
    x=max(0,((t%100)-20)/80)
    return math.sin(math.pi*x)**2 if x>0 else 0
check(pulse(0)==pulse(20)==pulse(100)==0, 'pulse quiet seam')
check(abs(pulse(60)-1)<1e-9, 'pulse peak')
for t in range(1000):
    check(abs(pulse(t)-pulse(t+100))<1e-9, 'periodic pulse')
    check(abs(pulse(t+.05)-pulse(t))<.003, 'smooth pulse')
    sweep=(t%64)/64;travel=3.55+11.65*sweep
    check(3<=travel-.4 and travel+.4<=16, 'glint within blade length')
props=(R/'gradle.properties').read_text()
check('minecraft_version=1.21.4\n' in props and 'mod_version=0.1.6-audit.1\n' in props, 'version pins retained')
print(f'PASS: {checks} static/math assertions. NOT a Java build, Minecraft run, or MobileGlues validation.')
