#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p verification/classes
mapfile -d '' sources < <(find src/main/java/dev/luma/core preview/src -name '*.java' -print0)
# Works with the compiler module even if a standalone javac launcher is absent.
java -m jdk.compiler/com.sun.tools.javac.Main --release 21 -encoding UTF-8 -d verification/classes "${sources[@]}"
cp -R src/main/resources/assets verification/classes/
python3 tools/validate_mobilefix.py | tee verification/static-checks.log
for check in MenuChecks RenderBudgetChecks UtilityChecks ToolSafetyChecks NewFeatureChecks RevisionChecks CustomSkinChecks; do
  echo "=== $check ==="
  java -Xmx512m -Djava.awt.headless=true -cp verification/classes "dev.luma.preview.$check"
done | tee verification/core-tests.log
java -Xmx512m -Djava.awt.headless=true -cp verification/classes dev.luma.preview.VisualRenderingChecks --render | tee verification/visual-tests.log
# Optional separate GL surrogate: node tools/check_shader_webgl.cjs
# This script does not build Fabric or launch Minecraft.
