#!/usr/bin/env python3
"""Synthetic filesystem tests, NOT a real GitHub Actions/Fabric build."""
from pathlib import Path
import json, shutil, subprocess, tempfile, unittest, zipfile, warnings
from select_project import select
from build_provenance import identity, generate
from verify_jar import verify
ROOT=Path(__file__).resolve().parents[1]
class Guards(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
 def tearDown(self): self.temp.cleanup()
 def project(self,where):
  for name in ['build.gradle','settings.gradle','gradle.properties','src/main/resources/fabric.mod.json','tools/verify_jar.py','.github/workflows/build.yml']:
   p=where/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('audited')
 def test_root(self):
  self.project(self.root);self.assertEqual(select(self.root),self.root)
 def test_nested(self):
  self.project(self.root/'LumaVisuals');p=self.root/'.github/workflows/build.yml';p.parent.mkdir(parents=True);p.write_text('audited');self.assertEqual(select(self.root),self.root/'LumaVisuals')
 def test_old_archive_never_selected(self):
  self.project(self.root);(self.root/'LumaVisuals-0.1.5-Katana-Prism-MobileFix.zip').write_bytes(b'old');self.assertEqual(select(self.root),self.root)
 def test_zip_only_rejected(self):
  (self.root/'LumaVisuals-0.1.5-Katana-Prism-MobileFix.zip').write_bytes(b'old')
  with self.assertRaises(ValueError):select(self.root)
 def test_two_projects_rejected(self):
  self.project(self.root);self.project(self.root/'LumaVisuals')
  with self.assertRaises(ValueError):select(self.root)
 def test_hidden_backup_project_rejected(self):
  self.project(self.root);self.project(self.root/'backup')
  with self.assertRaises(ValueError):select(self.root)
 def test_stale_root_workflow_rejected(self):
  self.project(self.root/'LumaVisuals');p=self.root/'.github/workflows/build.yml';p.parent.mkdir(parents=True);p.write_text('old')
  with self.assertRaises(ValueError):select(self.root)
 def test_missing_resource_rejected(self):
  self.project(self.root);(self.root/'src/main/resources/fabric.mod.json').unlink()
  with self.assertRaises(ValueError):select(self.root)
 def test_source_identity_changes(self):
  for folder in ['src/main','preview/src','tools']:(self.root/folder).mkdir(parents=True)
  self.project(self.root);(self.root/'gradle.properties').write_text('mod_version=test\nminecraft_version=1.21.4\n')
  first=identity(self.root,'commit');f=self.root/'src/main/probe.txt';f.write_text('new');second=identity(self.root,'commit')
  self.assertNotEqual(first['sourceSha256'],second['sourceSha256']);self.assertEqual(second,identity(self.root,'commit'))
 def test_provenance_roundtrip(self):
  data=generate(ROOT,self.root/'generated');self.assertEqual(data,json.loads((self.root/'generated/luma-build.json').read_text()))
  self.assertIn('sourceSha256='+data['sourceSha256'],(self.root/'generated/luma-build.properties').read_text())
 def minimal_package(self,version=None,provenance=None,duplicate=False):
  # JSON-only negative fixture; deliberately NOT a loadable JAR.
  expected=identity(ROOT);meta=json.loads((ROOT/'src/main/resources/fabric.mod.json').read_text())
  meta['version']=version or expected['version'];package=self.root/'negative-fixture.zip'
  with warnings.catch_warnings():
   warnings.simplefilter('ignore',UserWarning)
   with zipfile.ZipFile(package,'w') as z:
    z.writestr('fabric.mod.json',json.dumps(meta));z.writestr('luma-build.json',json.dumps(provenance or expected))
    if duplicate:z.writestr('fabric.mod.json',json.dumps(meta))
  return package
 def test_old_package_version_rejected(self):
  with self.assertRaisesRegex(AssertionError,'mod id/version mismatch'):
   verify(ROOT,self.minimal_package(version='0.1.5'))
 def test_stale_source_identity_rejected(self):
  stale=identity(ROOT);stale['sourceSha256']='0'*64
  with self.assertRaisesRegex(AssertionError,'source identity mismatch'):
   verify(ROOT,self.minimal_package(provenance=stale))
 def test_wrong_commit_rejected(self):
  with self.assertRaisesRegex(AssertionError,'source identity mismatch'):
   verify(ROOT,self.minimal_package(),commit='a'*40)
 def test_duplicate_package_entries_rejected(self):
  with self.assertRaisesRegex(ValueError,'Duplicate ZIP entries'):
   verify(ROOT,self.minimal_package(duplicate=True))
 def test_workflow_contract(self):
  workflow=(ROOT/'.github/workflows/build.yml').read_text()
  for token in ['ref: ${{ github.sha }}','--no-build-cache --rerun-tasks clean build','python3 tools/verify_jar.py','if-no-files-found: error','rm -rf build']:
   self.assertIn(token,workflow)
  self.assertNotIn('unzip ',workflow)
  self.assertEqual(len(list((ROOT/'.github/workflows').glob('*.yml'))),1)
 def test_shell_syntax(self):
  for p in (ROOT/'tools').glob('*.sh'):
   result=subprocess.run(['bash','-n',str(p)],capture_output=True,text=True);self.assertEqual(result.returncode,0,result.stderr)
if __name__=='__main__':unittest.main(verbosity=2)
