#!/usr/bin/env python3
"""Deterministic source identity embedded by processResources; no network."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess

def sha(data): return hashlib.sha256(data).hexdigest()
def properties(root):
    return dict(line.strip().split('=',1) for line in (root/'gradle.properties').read_text().splitlines()
                if '=' in line and not line.lstrip().startswith('#'))
def source_files(root):
    paths=[]
    for folder in ['src/main','preview/src','tools']:
        paths.extend(p for p in (root/folder).rglob('*') if p.is_file()
                     and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.class'))
    paths.extend(root/p for p in ['build.gradle','settings.gradle','gradle.properties','.github/workflows/build.yml'])
    return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in sorted(paths)}
def identity(root,commit=None):
    files=source_files(root)
    if commit is None:
        run=subprocess.run(['git','-C',str(root),'rev-parse','HEAD'],capture_output=True,text=True)
        commit=run.stdout.strip() if run.returncode==0 else 'UNVERSIONED'
    return {'schema':1,'modId':'luma','version':properties(root)['mod_version'],
            'minecraft':properties(root)['minecraft_version'],'commit':commit,
            'sourceSha256':sha(json.dumps(files,sort_keys=True,separators=(',',':')).encode()),'files':files}
def generate(root,out):
    data=identity(root)
    expected=os.environ.get('GITHUB_SHA')
    if expected and data['commit']!=expected: raise ValueError('HEAD != GITHUB_SHA')
    out.mkdir(parents=True,exist_ok=True)
    (out/'luma-build.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    (out/'luma-build.properties').write_text(''.join(f'{k}={data[k]}\n' for k in ['version','commit','sourceSha256']))
    return data
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();print(json.dumps(generate(a.project.resolve(),a.output),indent=2))
