#!/usr/bin/env python3
"""Verify remapped JAR against THIS build's compiled classes and inputs.
Not a Minecraft launch, Mixin application test, or GPU validation.
"""
from pathlib import Path
import argparse, difflib, json, re, struct, subprocess, zipfile
from build_provenance import identity, properties, sha

def normalize_javap(text):
    """Ignore CP layout, column padding and wide encodings, not operands.

    ldc/ldc_w and goto/goto_w encode the same operation. Wider encodings
    shift byte offsets, so branches/switches/handlers use instruction indices.
    Resolved comments (including string whitespace and #digits) stay intact.
    Unknown differences still fail closed and produce a diagnostic diff.
    """
    instruction = re.compile(r'^(\s+)(\d+):\s+([a-z][a-z0-9_]*)(.*)$')
    result = []
    for section in text.split('    Code:'):
        lines = section.splitlines()
        pcs = [int(m.group(2)) for line in lines if (m := instruction.match(line))]
        labels = {pc: 'I'+str(i) for i, pc in enumerate(pcs)}
        if pcs:
            # JVM methods normally end in a one-byte return/athrow. Only
            # recognize that end boundary when it is actually present.
            last = next(instruction.match(line) for line in reversed(lines) if instruction.match(line))
            if last.group(3) in {'return','ireturn','lreturn','freturn','dreturn','areturn','athrow'}:
                labels[pcs[-1]+1] = 'END'
        def target(number):
            return labels.get(int(number), 'OFFSET:'+number)
        in_handlers = False
        for line in lines:
            match = instruction.match(line)
            if match:
                _, pc, op, tail = match.groups()
                operands, sep, comment = tail.partition('//')
                operands = re.sub(r'#\d+', '#CP', operands)
                operands = ' '.join(operands.split())
                op = {'ldc_w':'ldc', 'goto_w':'goto', 'jsr_w':'jsr'}.get(op, op)
                if op.startswith('if') or op in {'goto','jsr'}:
                    operands = target(operands)
                normalized = labels[int(pc)]+' '+op+(' '+operands if operands else '')
                if sep:
                    normalized += ' //'+comment
                result.append(normalized)
                in_handlers = False
                continue
            switch = re.match(r'^\s*(default|-?\d+):\s*(-?\d+)\s*$', line)
            if switch:
                result.append(switch.group(1)+': '+target(switch.group(2)))
                continue
            if line.strip() == 'Exception table:':
                in_handlers = True
            handler = re.match(r'^\s*(\d+)\s+(\d+)\s+(\d+)\s+(.*)$', line) if in_handlers else None
            if handler:
                result.append('HANDLER '+' '.join(target(handler.group(i)) for i in (1,2,3))+' '+handler.group(4))
            else:
                result.append(line)
    return '\n'.join(result)

def disassemble(classpath,names):
    run=subprocess.run(['java','-m','jdk.jdeps/com.sun.tools.javap.Main','-classpath',str(classpath),
                        '-p','-c','-s','-constants',*names],capture_output=True,text=True,check=True)
    return normalize_javap(run.stdout)

def verify(root,jar,commit=None):
    expected=identity(root,commit)
    compiled=root/'build/classes/java/main'
    resources=root/'build/resources/main'
    with zipfile.ZipFile(jar) as z:
        names=z.namelist()
        if len(names)!=len(set(names)): raise ValueError('Duplicate ZIP entries')
        def read(n): return z.read(n)
        meta=json.loads(read('fabric.mod.json'))
        assert meta['id']=='luma' and meta['version']==expected['version'], 'mod id/version mismatch'
        assert meta['environment']=='client' and meta['depends']['minecraft']=='~1.21.4'
        assert meta['entrypoints']['client']==['dev.luma.client.LumaClient']
        assert json.loads(read('luma-build.json'))==expected,'Embedded source identity mismatch'
        assert read('luma-build.json')==(resources/'luma-build.json').read_bytes()
        assert read('luma-build.properties')==(resources/'luma-build.properties').read_bytes()
        for p in (root/'src/main/resources').rglob('*'):
            if not p.is_file(): continue
            name=p.relative_to(root/'src/main/resources').as_posix()
            if name=='fabric.mod.json':
                assert read(name)==(resources/name).read_bytes(),'Processed metadata differs'
            elif name=='luma.mixins.json':
                shipped=json.loads(read(name));source=json.loads(p.read_text())
                # Loom may add its generated refmap name; all user configuration must match.
                shipped.pop('refmap',None);source.pop('refmap',None)
                assert shipped==source,'Mixin configuration differs'
            else: assert read(name)==p.read_bytes(),f'Resource differs: {name}'
        # Core has no Minecraft references. Prefer exact bytes; tolerate only CP-index
        # reserialization if javap still reports the same signatures and instruction operands.
        core=list((compiled/'dev/luma/core').glob('*.class'))
        assert core,'Missing compiled core classes'
        exact=0;different=[]
        for p in core:
            name=p.relative_to(compiled).as_posix()
            if read(name)==p.read_bytes(): exact+=1
            else: different.append(name[:-6].replace('/','.'))
        if different:
            left=disassemble(compiled,different);right=disassemble(jar,different)
            if left != right:
                report=root/'build/verification/core-bytecode.diff'
                report.parent.mkdir(parents=True,exist_ok=True)
                report.write_text(''.join(difflib.unified_diff(
                    left.splitlines(True),right.splitlines(True),
                    fromfile='compiled-core',tofile='remapped-core')))
                raise AssertionError('Core bytecode differs from current compilation; see '+str(report))
        classes=[n for n in names if n.startswith('dev/luma/') and n.endswith('.class')]
        actual={n for n in classes}
        compiled_names={p.relative_to(compiled).as_posix() for p in (compiled/'dev/luma').rglob('*.class')}
        assert actual==compiled_names,'Class inventory differs from current compilation'
        for name in classes:
            data=read(name);assert data[:4]==b'\xca\xfe\xba\xbe' and struct.unpack('>H',data[6:8])[0]==65,f'Not Java 21: {name}'
        mixins=json.loads(read('luma.mixins.json'))
        assert {'WorldColorMixin','GameRendererMixin','HeldItemRendererMixin'}<=set(mixins['client'])
        for name in mixins['client']:
            assert mixins['package'].replace('.','/')+'/'+name+'.class' in actual
        hand=read('dev/luma/client/mixin/HeldItemRendererMixin.class')
        world=read('dev/luma/client/WorldColor.class')
        # Mixin targets must be remapped, not only registered in JSON.
        assert b'class_759' in hand,'HeldItemRenderer target was not remapped'
        refmap=mixins.get('refmap')
        selectors=hand+(read(refmap) if refmap else b'')
        for token in [b'method_3228',b'method_65816']:
            assert token in selectors,f'Missing intermediary Mixin selector (class or refmap): {token}'
        assert b'net/minecraft/class_310' in world,'Not an intermediary Fabric JAR'
        assert b'LumeSaturation' in world
        assert not any(n.startswith('dev/luma/preview/') for n in names),'Preview accidentally packaged'
    return {'scope':'JAR/source/build consistency ONLY; Minecraft and MobileGlues NOT RUN',
            'jar':jar.name,'jarSha256':sha(jar.read_bytes()),'version':expected['version'],
            'commit':expected['commit'],'sourceSha256':expected['sourceSha256'],
            'classCount':len(classes),'exactCoreClassCount':exact,'disassembledCoreClassCount':len(different)}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,default=Path('.'));p.add_argument('--jar',type=Path,required=True);p.add_argument('--commit');p.add_argument('--report',type=Path)
    a=p.parse_args();result=verify(a.project.resolve(),a.jar.resolve(),a.commit);text=json.dumps(result,indent=2)+'\n'
    if a.report: a.report.write_text(text)
    print(text)
