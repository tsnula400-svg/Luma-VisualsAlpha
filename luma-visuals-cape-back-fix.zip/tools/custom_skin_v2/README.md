# Offline Custom Skin tools (refined, existing V2 directory retained)

These are developer inspection tools, not game runtime code.

- generate.py: deterministic geometry + pixel textures; Pillow. It overwrites model and textures.
- recording_check.py: compiles actual model/renderer with recording doubles; JDK 21+ and Python. Does NOT compile Fabric or execute Minecraft.
- render_preview.py: renders recorded cuboids with their UV textures; Pillow and NumPy. Vanilla base player, real GPU lighting and shaders are deliberately absent.
- geometry.json: inspection/export description generated alongside the actual Java model.

Use the project-root CUSTOM_SKIN_REFINED_RU.md for installation and honest verification limits.
