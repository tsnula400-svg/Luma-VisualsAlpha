#!/usr/bin/env python3
"""Compile the REAL model + feature renderer against recording test doubles.
NOT a Fabric build, NOT Minecraft execution, NOT verification of mapped API signatures.
Doubles implement only the transform/builder surface used here. No doubles enter src/ or JAR.
Run: python3 tools/custom_skin_v2/recording_check.py [output-directory]
Requires Java 21+ including jdk.compiler; no network or third-party Java jars.
"""
from pathlib import Path
import subprocess,tempfile,sys
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(sys.argv[1] if len(sys.argv)>1 else ROOT/'preview/custom-skin-refined').resolve();OUT.mkdir(parents=True,exist_ok=True)
S={}
S['net/minecraft/client/model/ModelTransform.java']='''package net.minecraft.client.model;
public record ModelTransform(float x,float y,float z,float pitch,float yaw,float roll) {
 public static final ModelTransform NONE=of(0,0,0,0,0,0);
 public static ModelTransform of(float x,float y,float z,float p,float a,float r){return new ModelTransform(x,y,z,p,a,r);}
}'''
S['net/minecraft/client/model/ModelPartBuilder.java']='''package net.minecraft.client.model;
import java.util.*;
public class ModelPartBuilder {
 public final List<float[]> boxes=new ArrayList<>();int u,v;
 public static ModelPartBuilder create(){return new ModelPartBuilder();}
 public ModelPartBuilder uv(int u,int v){this.u=u;this.v=v;return this;}
 public ModelPartBuilder cuboid(float x,float y,float z,float w,float h,float d){boxes.add(new float[]{x,y,z,w,h,d,u,v});return this;}
}'''
S['net/minecraft/client/model/ModelPartData.java']='''package net.minecraft.client.model;
import java.util.*;
public class ModelPartData {
 public String name; public ModelPartBuilder builder; public ModelTransform transform;
 public final Map<String,ModelPartData> children=new LinkedHashMap<>();
 public ModelPartData(String n,ModelPartBuilder b,ModelTransform t){name=n;builder=b;transform=t;}
 public ModelPartData addChild(String n,ModelPartBuilder b,ModelTransform t){var p=new ModelPartData(n,b,t);if(children.put(n,p)!=null)throw new AssertionError("duplicate part");return p;}
}'''
S['net/minecraft/client/model/ModelData.java']='''package net.minecraft.client.model;
public class ModelData { private final ModelPartData root=new ModelPartData("root",ModelPartBuilder.create(),ModelTransform.NONE); public ModelPartData getRoot(){return root;} }'''
S['net/minecraft/client/model/TexturedModelData.java']='''package net.minecraft.client.model;
public class TexturedModelData {public ModelPart root;public int width,height;
 public static TexturedModelData of(ModelData d,int w,int h){var t=new TexturedModelData();t.root=new ModelPart(d.getRoot());t.width=w;t.height=h;return t;}
 public ModelPart createModel(){return root;}
}'''
S['net/minecraft/client/util/math/MatrixStack.java']='''package net.minecraft.client.util.math;
import java.util.*;
public class MatrixStack {
 private double[] m=identity();private final Deque<double[]> stack=new ArrayDeque<>();
 public static double[] identity(){double[] m=new double[16];for(int i=0;i<4;i++)m[i*4+i]=1;return m;}
 public void push(){stack.push(m.clone());}public void pop(){m=stack.pop();}public int depth(){return stack.size();}
 public double[] current(){return m.clone();}
 public void multiply(double[] b){double[] a=m; m=new double[16];for(int r=0;r<4;r++)for(int c=0;c<4;c++)for(int k=0;k<4;k++)m[r*4+c]+=a[r*4+k]*b[k*4+c];}
 public void translate(double x,double y,double z){double[] a=identity();a[3]=x;a[7]=y;a[11]=z;multiply(a);}
 public void scale(double x,double y,double z){double[] a=identity();a[0]=x;a[5]=y;a[10]=z;multiply(a);}
 public void rotate(int axis,double angle){double[] a=identity();double c=Math.cos(angle),s=Math.sin(angle);int i=(axis+1)%3,j=(axis+2)%3;a[i*4+i]=a[j*4+j]=c;a[i*4+j]=-s;a[j*4+i]=s;multiply(a);}
}'''
S['net/minecraft/client/render/VertexConsumer.java']='''package net.minecraft.client.render;
import java.util.*;
public class VertexConsumer {
 public static final List<String> records=new ArrayList<>();public final String layer;public VertexConsumer(String l){layer=l;}
 public void record(String name,float[] box,double[] matrix,int light,int color){records.add("{\\"part\\":\\""+name+"\\",\\"layer\\":\\""+layer+"\\",\\"box\\":"+Arrays.toString(box)+",\\"matrix\\":"+Arrays.toString(matrix)+",\\"light\\":"+light+",\\"color\\":"+color+"}");}
}'''
S['net/minecraft/client/render/VertexConsumerProvider.java']='''package net.minecraft.client.render;
public class VertexConsumerProvider {public VertexConsumer getBuffer(Object layer){return new VertexConsumer(layer.toString());}}'''
S['net/minecraft/client/render/OverlayTexture.java']='''package net.minecraft.client.render;public class OverlayTexture {public static final int DEFAULT_UV=0;}'''
S['net/minecraft/client/model/ModelPart.java']='''package net.minecraft.client.model;
import java.util.*;import net.minecraft.client.util.math.MatrixStack;import net.minecraft.client.render.VertexConsumer;
public class ModelPart {
 public float pivotX,pivotY,pivotZ,pitch,yaw,roll,xScale=1,yScale=1,zScale=1;
 public final String name;public final Map<String,ModelPart> children=new LinkedHashMap<>();public final List<float[]> boxes;private final ModelTransform initial;
 public ModelPart(ModelPartData d){name=d.name;boxes=d.builder.boxes;initial=d.transform;resetTransform();d.children.forEach((n,c)->children.put(n,new ModelPart(c)));}
 public ModelPart(){this(new ModelPartData("vanilla",ModelPartBuilder.create(),ModelTransform.NONE));}
 public ModelPart getChild(String n){var p=children.get(n);if(p==null)throw new AssertionError("Missing child "+n);return p;}
 public void resetTransform(){pivotX=initial.x();pivotY=initial.y();pivotZ=initial.z();pitch=initial.pitch();yaw=initial.yaw();roll=initial.roll();xScale=yScale=zScale=1;}
 public void copyTransform(ModelPart p){pivotX=p.pivotX;pivotY=p.pivotY;pivotZ=p.pivotZ;pitch=p.pitch;yaw=p.yaw;roll=p.roll;xScale=p.xScale;yScale=p.yScale;zScale=p.zScale;}
 public void rotate(MatrixStack m){m.translate(pivotX,pivotY,pivotZ);m.rotate(2,roll);m.rotate(1,yaw);m.rotate(0,pitch);m.scale(xScale,yScale,zScale);}
 public void render(MatrixStack m,VertexConsumer c,int light,int overlay,int color){m.push();rotate(m);for(var b:boxes)c.record(name,b,m.current(),light,color);for(var p:children.values())p.render(m,c,light,overlay,color);m.pop();}
}'''
S['net/minecraft/client/render/entity/model/PlayerEntityModel.java']='''package net.minecraft.client.render.entity.model;
import net.minecraft.client.model.ModelPart;
public class PlayerEntityModel {public ModelPart head=new ModelPart(),body=new ModelPart(),rightArm=new ModelPart(),leftArm=new ModelPart(),rightLeg=new ModelPart(),leftLeg=new ModelPart();}'''
S['net/minecraft/client/render/entity/state/PlayerEntityRenderState.java']='''package net.minecraft.client.render.entity.state;
public class PlayerEntityRenderState {public boolean invisible;public float age,limbAmplitudeMultiplier,limbFrequency;}'''
S['net/minecraft/client/render/entity/feature/FeatureRendererContext.java']='''package net.minecraft.client.render.entity.feature;
public interface FeatureRendererContext<S,M> {M getModel();}'''
S['net/minecraft/client/render/entity/feature/FeatureRenderer.java']='''package net.minecraft.client.render.entity.feature;
import net.minecraft.client.util.math.MatrixStack;import net.minecraft.client.render.VertexConsumerProvider;
public abstract class FeatureRenderer<S,M> {private final FeatureRendererContext<S,M> context;public FeatureRenderer(FeatureRendererContext<S,M> c){context=c;}public M getContextModel(){return context.getModel();}public abstract void render(MatrixStack m,VertexConsumerProvider c,int l,S s,float y,float p);}'''
S['dev/luma/client/skin/CustomSkinManager.java']='''package dev.luma.client.skin;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
/** Test-only gate, not the real manager. */
public class CustomSkinManager {public static boolean enabled=true;public static final String MAIN_LAYER="main",GLOW_LAYER="glow";public static boolean isEnabledFor(PlayerEntityRenderState s){return enabled;}}'''
S['Check.java']='''import java.nio.file.*;import java.util.*;
import dev.luma.client.skin.*;import net.minecraft.client.model.*;import net.minecraft.client.render.*;import net.minecraft.client.render.entity.model.*;import net.minecraft.client.render.entity.state.*;import net.minecraft.client.util.math.*;
public class Check {
 static int checks=0;static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 static void same(ModelPart a,ModelPart b){check(a.pivotX==b.pivotX&&a.pivotY==b.pivotY&&a.pivotZ==b.pivotZ&&a.pitch==b.pitch&&a.yaw==b.yaw&&a.roll==b.roll&&a.xScale==b.xScale&&a.yScale==b.yScale&&a.zScale==b.zScale,"root transform lost");}
 static List<ModelPart> all(ModelPart p){var a=new ArrayList<ModelPart>();a.add(p);for(var c:p.children.values())a.addAll(all(c));return a;}
 static void pose(PlayerEntityModel m,String n){
  for(var p:List.of(m.head,m.body,m.rightArm,m.leftArm,m.rightLeg,m.leftLeg))p.resetTransform();
  m.rightArm.pivotX=-5;m.leftArm.pivotX=5;m.rightArm.pivotY=m.leftArm.pivotY=n.equals("slim")?2.5f:2;
  m.rightLeg.pivotX=-1.9f;m.leftLeg.pivotX=1.9f;m.rightLeg.pivotY=m.leftLeg.pivotY=12;
  if(n.equals("walk")||n.equals("run")){float p=n.equals("run")?.95f:.5f;m.rightArm.pitch=-p;m.leftArm.pitch=p;m.rightLeg.pitch=p;m.leftLeg.pitch=-p;}
  if(n.equals("look")){m.head.yaw=.8f;m.head.pitch=-.35f;}
  if(n.equals("crouch")){m.body.pitch=.5f;m.head.pivotY=4;m.body.pivotY=3.2f;m.rightArm.pivotY=m.leftArm.pivotY=5.2f;m.rightArm.pitch=m.leftArm.pitch=.3f;m.rightLeg.pivotY=m.leftLeg.pivotY=12.2f;m.rightLeg.pivotZ=m.leftLeg.pivotZ=4;}
  if(n.equals("attack")){m.body.yaw=.2f;m.rightArm.pitch=-1.6f;m.rightArm.yaw=-.25f;m.rightArm.roll=.1f;}
  if(n.equals("swim")){m.rightArm.pitch=-2.6f;m.leftArm.pitch=-2.4f;m.rightLeg.pitch=.15f;m.leftLeg.pitch=-.15f;}
  if(n.equals("jump")){m.rightArm.pitch=-.4f;m.leftArm.pitch=.4f;m.rightLeg.pitch=.3f;m.leftLeg.pitch=-.3f;}
  if(n.equals("turn")){m.body.yaw=.7f;m.body.roll=.08f;m.head.yaw=-.6f;}
  if(n.equals("scaled")){for(var p:List.of(m.head,m.body,m.rightArm,m.leftArm,m.rightLeg,m.leftLeg)){p.xScale=.8f;p.yScale=1.1f;p.zScale=.9f;}}
 }
 public static void main(String[] args)throws Exception {
  var data=CustomSkinModel.getTexturedModelData();var root=data.createModel();
  check(data.width==256&&data.height==256,"atlas dimensions");int cubes=0;
  for(var p:all(root))for(var b:p.boxes){cubes++;check(b[3]>0&&b[4]>0&&b[5]>0,"positive cuboid");check(b[6]>=0&&b[7]>=0&&b[6]+2*b[3]+2*b[5]<=256&&b[7]+b[4]+b[5]<=256,"UV in atlas");}
  check(cubes<420,"local cosmetic geometry budget");
  ModelPart mount=root.getChild("katana").getChild("katana_grip");
  for(var p:List.of(root.getChild("blade_glow").getChild("blade_energy"),root.getChild("blade_streak").getChild("streak_grip"),root.getChild("sparks").getChild("sparks_grip")))same(mount,p);
  var model=new PlayerEntityModel();var renderer=new CustomSkinFeatureRenderer(()->model,root);var state=new PlayerEntityRenderState();var matrices=new MatrixStack();var consumers=new VertexConsumerProvider();
  for(String n:List.of("idle","walk","run","look","crouch","attack","swim","slim","scaled","jump","turn")){
   pose(model,n);state.age=41.25f;state.limbFrequency=2.3f;state.limbAmplitudeMultiplier=n.equals("run")?1:n.equals("walk")?.55f:0;
   VertexConsumer.records.clear();renderer.render(matrices,consumers,0x900090,state,0,0);
   check(VertexConsumer.records.size()==cubes,"all accents have bounded idle emission "+n);check(matrices.depth()==0,"balanced matrix stack");
   same(root.getChild("hood"),model.head);same(root.getChild("eyes"),model.head);same(root.getChild("right_eye"),model.head);same(root.getChild("ribs"),model.body);same(root.getChild("cloak"),model.body);
   for(String s:List.of("katana","blade_glow","blade_streak","sparks"))same(root.getChild(s),model.body);
   same(root.getChild("sleeve_right"),model.rightArm);
   same(root.getChild("sleeve_left"),model.leftArm);same(root.getChild("leg_left"),model.leftLeg);same(root.getChild("leg_right"),model.rightLeg);
   check(root.getChild("cloak").getChild("cloak_left").pivotY==9.6f,"waist pivot not erased");
   var old=List.copyOf(VertexConsumer.records);VertexConsumer.records.clear();renderer.render(matrices,consumers,0x900090,state,0,0);check(old.equals(VertexConsumer.records),"no transform accumulation "+n);
   Files.writeString(Path.of(args[0],n+".json"),"["+String.join(",",old)+"]");
  }
  // Dominant animated left eye (+X), smaller independently dimmed right eye.
  var iris=root.getChild("eyes").getChild("left_iris");
  check(iris.pivotX>0 && root.getChild("eyes").children.size()==1,"left eye root contains its iris");
  check(iris.xScale>=.175f && iris.xScale<=.191f && iris.xScale==iris.yScale,"bounded iris breathing, not head scaling");
  var rightIris=root.getChild("right_eye").getChild("right_iris");
  check(rightIris.pivotX<0 && rightIris.xScale<iris.xScale,"right eye remains smaller");
  check(mount.pivotZ==5.8f && mount.pitch==0 && mount.roll==.58f,"diagonal back mount");
  for(var b:mount.boxes){
   // Retainer straps intentionally reach the cloak. Actual weapon stays behind it.
   if(b[2]>-1.1f)check(mount.pivotZ+b[2]>4.7f,"weapon outside back and hood at rest");
  }
  // All luminous layers have the same baked body-local attachment after every render.
  for(var child:List.of(root.getChild("blade_glow").getChild("blade_energy"),root.getChild("blade_streak").getChild("streak_grip"),root.getChild("sparks").getChild("sparks_grip")))same(mount,child);
  var pulse=CustomSkinFeatureRenderer.class.getDeclaredMethod("pulseEnvelope",float.class);pulse.setAccessible(true);
  check((float)pulse.invoke(null,0f)==0 && (float)pulse.invoke(null,19f)==0,"one-second calm interval");
  check(Math.abs((float)pulse.invoke(null,60f)-1)<.00001f,"peak at 3 seconds");
  check((float)pulse.invoke(null,100f)==0,"cycle wraps without flash");
  for(int i=0;i<100;i++)check(Math.abs((float)pulse.invoke(null,(float)i)-(float)pulse.invoke(null,(float)i+100))<.00001f,"5 second periodicity");
  float prev=0;
  for(int i=20;i<=60;i++){float v=(float)pulse.invoke(null,(float)i);check(v>=prev,"smooth rise");prev=v;}
  for(int i=61;i<=100;i++){float v=(float)pulse.invoke(null,(float)i);check(v<=prev,"smooth fall");prev=v;}
  pose(model,"idle");state.age=60;state.limbAmplitudeMultiplier=0;
  VertexConsumer.records.clear();renderer.render(matrices,consumers,0x900090,state,0,0);
  check(VertexConsumer.records.size()==cubes,"pulse draws all bounded energy accents");
  Files.writeString(Path.of(args[0],"pulse.json"),"["+String.join(",",VertexConsumer.records)+"]");
  // Long sampling crosses several cycles and must not accumulate transforms.
  for(int t=0;t<1200;t++){
   state.age=t;VertexConsumer.records.clear();renderer.render(matrices,consumers,0,state,0,0);
   check(VertexConsumer.records.size()<=cubes,"bounded render budget");
   same(root.getChild("katana"),model.body);
   check(matrices.depth()==0,"balanced stack during pulse");
  }
  state.invisible=true;VertexConsumer.records.clear();renderer.render(matrices,consumers,0,state,0,0);check(VertexConsumer.records.isEmpty(),"invisible returns before drawing");state.invisible=false;
  CustomSkinManager.enabled=false;VertexConsumer.records.clear();renderer.render(matrices,consumers,0,state,0,0);check(VertexConsumer.records.isEmpty(),"OFF gate returns before drawing");CustomSkinManager.enabled=true;
  for(int i=0;i<240;i++) {state.age=i*.37f;VertexConsumer.records.clear();renderer.render(matrices,consumers,0,state,0,0);var g=root.getChild("blade_streak").getChild("streak_grip").getChild("glint");check(g.pivotY>=3&&g.pivotY+.65f<=16,"glint on blade");check(Float.isFinite(g.pivotX),"finite glint");}
  System.out.println("PASS: "+checks+" recording-double assertions; "+cubes+" cuboids; 11 poses + pulse. NOT a Fabric build or in-game test.");
 }
}'''
with tempfile.TemporaryDirectory(prefix='luma-recording-') as tmp:
    tmp=Path(tmp);src=tmp/'src';classes=tmp/'classes';classes.mkdir()
    for path,content in S.items():
        f=src/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(content)
    actual=[ROOT/'src/main/java/dev/luma/client/skin'/n for n in ['CustomSkinModel.java','CustomSkinFeatureRenderer.java']]
    cmd=['java','-m','jdk.compiler/com.sun.tools.javac.Main','--release','21','-encoding','UTF-8','-d',str(classes)]+[str(f) for f in src.rglob('*.java')]+list(map(str,actual))
    subprocess.run(cmd,check=True)
    subprocess.run(['java','-cp',str(classes),'Check',str(OUT)],check=True)
