#!/usr/bin/env python3
"""Software inspection of cuboids recorded from real Java model/renderer using test doubles.
No Minecraft execution, no shader/bloom simulation. Requires numpy + Pillow.
Usage: python3 render_preview.py POSES_DIR OUTPUT_DIR
"""
from pathlib import Path
import json,sys,math
import numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[2]
POSES=Path(sys.argv[1]);OUT=Path(sys.argv[2]);OUT.mkdir(parents=True,exist_ok=True)
AT=np.array(Image.open(ROOT/'src/main/resources/assets/luma/textures/entity/custom_skin_parts.png').convert('RGB'))
GL=np.array(Image.open(ROOT/'src/main/resources/assets/luma/textures/entity/custom_skin_glow.png').convert('RGB'))
W,H=1100,1050
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
try:font=ImageFont.truetype('Arial.ttf',23);small=ImageFont.truetype('Arial.ttf',17)
except:font=ImageFont.load_default(size=23);small=ImageFont.load_default(size=17)

def render(name,angle,filename,label):
    records=json.loads((POSES/(name+'.json')).read_text())
    # Camera y is down like Minecraft; front is negative Z. Orthographic inspection.
    yaw=math.radians(angle);elev=math.radians(9)
    R=np.array([[math.cos(yaw),0,-math.sin(yaw)],[0,1,0],[math.sin(yaw),0,math.cos(yaw)]])
    E=np.array([[1,0,0],[0,math.cos(elev),math.sin(elev)],[0,-math.sin(elev),math.cos(elev)]])
    R=E@R
    canvas=np.zeros((H,W,3),dtype=float);canvas[:]=[34,40,48]
    depth=np.full((H,W),np.inf)
    scale=22.0;center=np.array([W/2,390.0])
    # Face corners in cuboid local coordinates. UVs mimic Minecraft box UV unfolding.
    indices=[[0,4,6,2],[5,1,3,7],[0,1,5,4],[2,6,7,3],[1,0,2,3],[4,5,7,6]]
    def triangle(pts,uv,tex,shade,color,emission):
        xmin=max(0,int(np.floor(pts[:,0].min())));xmax=min(W-1,int(np.ceil(pts[:,0].max())))
        ymin=max(0,int(np.floor(pts[:,1].min())));ymax=min(H-1,int(np.ceil(pts[:,1].max())))
        if xmin>xmax or ymin>ymax:return
        a,b,c=pts;den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
        if abs(den)<1e-6:return
        xx,yy=np.meshgrid(np.arange(xmin,xmax+1)+.5,np.arange(ymin,ymax+1)+.5)
        v0=((b[1]-c[1])*(xx-c[0])+(c[0]-b[0])*(yy-c[1]))/den
        v1=((c[1]-a[1])*(xx-c[0])+(a[0]-c[0])*(yy-c[1]))/den;v2=1-v0-v1
        z=v0*a[2]+v1*b[2]+v2*c[2]
        sub=depth[ymin:ymax+1,xmin:xmax+1]
        mask=(v0>=-1e-6)&(v1>=-1e-6)&(v2>=-1e-6)&(z<sub+1e-5)
        if not mask.any():return
        U=np.clip((v0*uv[0,0]+v1*uv[1,0]+v2*uv[2,0]).astype(int),0,255)
        V=np.clip((v0*uv[0,1]+v1*uv[1,1]+v2*uv[2,1]).astype(int),0,255)
        rgb=tex[V,U]*shade*color
        dst=canvas[ymin:ymax+1,xmin:xmax+1]
        if emission:
            dst[mask]=np.minimum(255,dst[mask]+rgb[mask])
        else:dst[mask]=rgb[mask];sub[mask]=z[mask]
    for rec in records:
        x,y,z,w,h,d,u,v=rec['box'];mat=np.array(rec['matrix']).reshape(4,4)
        points=np.array([[x+(i&1)*w,y+((i>>1)&1)*h,z+((i>>2)&1)*d,1] for i in range(8)])
        world=(points@mat.T)[:,:3];view=world@R.T
        projected=np.c_[view[:,:2]*scale+center,view[:,2]]
        rects=[(u,v+d,u+d,v+d+h),(u+d+w,v+d,u+2*d+w,v+d+h),(u+d,v,u+d+w,v+d),(u+d+w,v,u+d+2*w,v+d),(u+d,v+d,u+d+w,v+d+h),(u+2*d+w,v+d,u+2*d+2*w,v+d+h)]
        # Some tiny fractional cuboids have fractional UV extents in the engine too.
        for face,rect in zip(indices,rects):
            P=projected[face];Q=world[face]
            normal=np.cross(Q[1]-Q[0],Q[2]-Q[0]);normal/=max(np.linalg.norm(normal),1e-8)
            # Emission drawn only on camera-facing facets to avoid doubling additive backs.
            viewNormal=R@normal
            if viewNormal[2]>0:continue
            shade=.72+.28*max(0,np.dot(normal,np.array([-.35,-.65,-.67])))
            a,b,c,e=rect;UV=np.array([[a,b],[c,b],[c,e],[a,e]])
            emission=rec['layer']=='glow'
            color=((rec['color']>>16)&255)/255
            for tri in ([0,1,2],[0,2,3]):triangle(P[tri],UV[tri],GL if emission else AT,1 if emission else shade,color,emission)
    im=Image.fromarray(np.uint8(np.clip(canvas,0,255)))
    dr=ImageDraw.Draw(im)
    dr.text((36,26),'LUMA VISUALS / PRISM MOBILE FIX',font=font,fill='#e7ebec')
    dr.text((36,64),label,font=small,fill='#aab8bf')
    dr.text((36,H-58),'OFFLINE GEOMETRY INSPECTION - not a Minecraft screenshot',font=small,fill='#b4c2c9')
    dr.text((36,H-32),'Offline geometry + UV textures. See pose provenance; no Minecraft or shader bloom.',font=small,fill='#87979f')
    im.save(OUT/filename)
for args in [('idle',-23,'01-front.png','Front / sculpted skull, ribs, split cloth and left eye; body-mounted back blade'),('idle',151,'02-back.png','Back / layered yoke and waist-pivot cloth'),('run',-30,'03-run.png','Synthetic run pose / inherited arm and leg transforms'),('attack',-28,'04-attack.png','Synthetic raised-arm pose / body-mounted sword stays independent of the arm'),('crouch',-30,'05-crouch.png','Synthetic crouch pose / body and limb pivots'),('look',-20,'06-look.png','Synthetic head turn / skull, cowl and left eye follow the head'),('pulse',151,'07-pulse-back.png','Rare pulse peak / bounded edge emission; no shader bloom'),('idle',90,'08-side.png','Side / back-mount clearance and layered skull relief')]:
    render(*args)
print('Rendered 8 offline inspection views.')
