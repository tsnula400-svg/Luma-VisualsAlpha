#!/usr/bin/env python3
"""Approximate Python pose inspection from geometry.json; NO Java compilation.
Not Minecraft, not a render of the compiled mod. Pillow + NumPy required.
"""
from pathlib import Path
import json, math, sys
import numpy as np
R=Path(__file__).resolve().parents[2]
OUT=Path(sys.argv[1]) if len(sys.argv)>1 else R/'preview/mobilefix-offline'
OUT.mkdir(parents=True,exist_ok=True)
POSES=OUT/'poses';POSES.mkdir(exist_ok=True)
g=json.loads((Path(__file__).parent/'geometry.json').read_text())

def pose(age):
    mats={};records=[]
    pulse=math.sin(math.pi*max(0,((age%100)-20)/80))**2
    breath=.5-.5*math.cos(age*2*math.pi/76)
    colors={'eyes':.12+.78*breath+.10*pulse,'right_eye':.07+.24*(.5-.5*math.cos(age*2*math.pi/88+.6)),
            'blade_glow':.22+.68*pulse,'blade_streak':math.sin(math.pi*(age%64)/64)**2*(.72+.28*pulse),'sparks':.12+.78*pulse}
    roots={}
    for p in g['parts']:
        name=p['name'];xyz=list(p['pivot']);rot=list(p['rot']);scale=[1.,1.,1.]
        if p['parent'] is None:
            if name=='sleeve_right':xyz=[-5,2,0]
            if name=='sleeve_left':xyz=[5,2,0]
            if name=='leg_right':xyz=[-1.9,12,0]
            if name=='leg_left':xyz=[1.9,12,0]
        if name=='left_iris':scale=[.175+.015*breath]*3
        if name=='right_iris':scale=[.115]*3
        if name in ('cloak_left','cloak_right'):rot[0]=.10
        if name=='glint':
            travel=3.55+11.65*(age%64)/64;t=(travel-3)/13
            xyz=[-1.35*t*t,travel,0];rot[2]=math.atan(2.7*t/13)
            scale[0]=(1-.22*t)*(max(.025,(1-t)/.2) if t>.8 else 1)
        if name.startswith('spark_'):
            i=int(name.split('_')[1]);a=age*.055+i*1.256637;y=3.6+i*2.25+.4*math.sin(a*1.7);t=(y-3)/13
            xyz=[-1.35*t*t+(.65+.35*pulse)*math.cos(a),y,.7*math.sin(a)]
            scale=[(.70+.35*pulse)*(.65+.35*math.sin(a*1.3))]*3
        local=np.eye(4);local[:3,3]=xyz
        for axis in (2,1,0):
            a=rot[axis];m=np.eye(4);i=(axis+1)%3;j=(axis+2)%3
            m[i,i]=m[j,j]=math.cos(a);m[i,j]=-math.sin(a);m[j,i]=math.sin(a);local=local@m
        local=local@np.diag(scale+[1]);mat=mats[p['parent']]@local if p['parent'] else local;mats[name]=mat
        root=roots[p['parent']] if p['parent'] else name;roots[name]=root
        level=colors.get(root,1);v=round(255*max(0,min(1,level)));color=(255<<24)|(v<<16)|(v<<8)|v
        for b in p['boxes']:
            records.append(dict(part=name,layer=p['layer'],box=b['xyz']+b['size']+b['uv'],matrix=mat.flatten().tolist(),light=0xF000F0,color=color))
    records.sort(key=lambda r:r['layer']=='glow')
    return records
for name,age in [('idle',38),('pulse',60)]:
    (POSES/(name+'.json')).write_text(json.dumps(pose(age)))
(POSES/'PROVENANCE.txt').write_text('Approximate Python transforms from geometry.json, not recorded Java and not Minecraft.\n')
# Load only rendering functions, not the legacy eight-view entrypoint.
source=(Path(__file__).parent/'render_preview.py').read_text().split('for args in ')[0]
old_argv=sys.argv;sys.argv=['render_preview.py',str(POSES),str(OUT)]
ns={'__file__':str(Path(__file__).parent/'render_preview.py')};exec(compile(source,'render_preview.py','exec'),ns);sys.argv=old_argv
ns['render']('idle',-23,'01-front.png','Approximate Python pose / left eye at bright phase; smaller right eye')
ns['render']('idle',151,'02-back.png','Approximate Python pose / curved steel, polished bevel and moving accent')
ns['render']('pulse',151,'03-pulse.png','Approximate Python pose / edge pulse peak; bounded back-local sparks')
print('Wrote three offline inspection views; no build or game execution.')
