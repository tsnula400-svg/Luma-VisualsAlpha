#!/usr/bin/env python3
"""Select checked-out sources only. Never extract or build an archive."""
from pathlib import Path
import os, sys

def select(root):
    root=Path(root).resolve()
    excluded={'.git','.gradle','build','node_modules','preview-build','verification'}
    found=[]
    for here, dirs, files in os.walk(root):
        dirs[:]=[d for d in dirs if d not in excluded]
        if 'build.gradle' in files or 'build.gradle.kts' in files:
            found.append(Path(here).resolve())
    if len(found)!=1 or found[0] not in (root,root/'LumaVisuals'):
        raise ValueError(f'Expected exactly one project at root or LumaVisuals/; found {found}')
    project=found[0]
    for name in ['settings.gradle','gradle.properties','src/main/resources/fabric.mod.json','tools/verify_jar.py']:
        if not (project/name).is_file(): raise ValueError(f'Missing {name}')
    workflow=root/'.github/workflows/build.yml'
    if not workflow.is_file(): raise ValueError('Missing active root .github/workflows/build.yml')
    if project!=root and workflow.read_bytes()!=(project/'.github/workflows/build.yml').read_bytes():
        raise ValueError('Root build.yml differs from the audited project workflow; replace the existing root file')
    for archive in root.glob('*.zip'):
        print(f'IGNORED ARCHIVE: {archive.name}',file=sys.stderr)
    return project

if __name__=='__main__':
    try: print(select(sys.argv[1]))
    except ValueError as e: sys.exit(str(e))
