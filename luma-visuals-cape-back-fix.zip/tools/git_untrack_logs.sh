#!/usr/bin/env bash
# Убирает логи среды/сборки из индекса Git, НЕ удаляя файлы на диске.
# Запускать из корня репозитория (там, где лежит .git).
set -euo pipefail

PATTERNS=(build-environment.log build-guards.log build-marker.log recording.log core.log)

for name in "${PATTERNS[@]}"; do
  # только файлы, реально находящиеся в индексе
  mapfile -t tracked < <(git ls-files -- "*/${name}" "${name}")
  for f in "${tracked[@]:-}"; do
    [ -n "$f" ] || continue
    git rm --cached --quiet -- "$f"
    echo "untracked: $f"
  done
done

echo
echo 'Готово. Файлы остались на диске, но больше не индексируются (*.log в .gitignore).'
echo 'Проверка: git status --short'
