#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v gradle >/dev/null || { echo 'Install Gradle 8.12. See README_RU.md.' >&2; exit 1; }
exec gradle --no-daemon build
